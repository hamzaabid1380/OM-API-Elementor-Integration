# Overnight Mountings Catalog Integration

Pulls live product and pricing data from the Overnight Mountings Product Catalog API
and displays it on the WordPress site — no WooCommerce, no cart, no ordering.
Just clean listing pages and single product pages, styled to your brand.

## Install

1. Zip the `om-catalog-integration` folder (or use the zip as provided).
2. In WordPress admin: **Plugins > Add New > Upload Plugin**, select the zip, install, activate.

## Set up credentials

Go to **Settings > OM Catalog** and enter:
- **Client ID** (your account number, e.g. `R01203`)
- **Client Secret** (from Overnight Mountings)

Nothing needs to be edited in code. The plugin handles getting and refreshing
the access token automatically behind the scenes.

## IMPORTANT: Set your pricing markup before going live

The API returns **wholesale** prices. Until you set a markup, the site would show
raw wholesale pricing — you'll see a warning banner in wp-admin as a reminder.

Go to **Settings > OM Catalog > Pricing Markup** and choose either:
- **Percentage** — e.g. `120` means retail = wholesale × 2.2
- **Multiplier** — e.g. `2.2` means the same thing, entered directly

Until a markup is set, the site shows **"Call for pricing"** (or your own
text/buttons, see below) instead of any price — wholesale numbers are never
exposed to visitors. Logged-in admins see a small note on product pages
explaining why no price is shown.

**Not seeing prices?** Go to **Settings > OM Catalog > Tools** and click
**Test connection & pricing**. It logs in, reads the product lines, loads a
product and prices it, and tells you exactly which step fails.

## Set your brand colors and fonts

Same settings page, under **Brand Colors & Fonts**. The defaults already match
the live wulfdiamondjewelers.com design (Arapey headings, Inter body,
near-black `#00111C` primary, flat square styling) — only change them if the
site's branding changes.

**Style source** "Follow the Elementor kit" (the default) uses the colours and
fonts set in Elementor's Site Settings. Elementor's starting values (the blue
`#6EC1E4` and Roboto of a kit nobody has styled) are skipped: the catalog then
uses these settings, or the Wulf Elementor Kit's ink and fonts when that plugin
is active, so product pages and pop-ups always match the site. Developers can
adjust the result with the `om_catalog_style_tokens` filter.

## Adding pages

**Listing/catalog pages** (e.g. Engagement Rings, Wedding Bands):
Create a normal WordPress page, edit with Elementor, and either:
- Drag in the **"OM Product Catalog"** widget (appears in the Elementor widget
  panel once this plugin is active), and set the product line, columns, and
  items-per-page in the widget's settings panel, OR
- Use Elementor's built-in **Shortcode** widget with:
  `[om_catalog line="engagement-rings" columns="3" per_page="12"]`

Available `line` values: `engagement-rings`, `wedding-bands`, `bracelets`,
`earrings`, `fashion-rings`, `necklaces`, `pendants`, `in-stock`.

**Single product pages** are generated automatically — no page-building needed.
Every product card links to:
`yoursite.com/catalog/{product-line}/{style-number}/`

This page uses your theme's normal header and footer, styled with the colors/fonts
from the settings page.

**Design product pages in Elementor:** create a page, edit it with Elementor,
drop in the **OM Single Product** widget (it previews a real product while you
design; Content tab picks the preview and toggles each section — gallery,
title, price, options, stone details, variants — and the Style tab holds
colors/typography). Add anything else around the widget: banners, trust
badges, a contact section. Then choose that page under
**Settings > OM Catalog > Product Page Layout** — every `/catalog/...` URL
now renders through your design, with live pricing and the gallery working
as before.

Alternatively, for a code-level custom layout, copy
`templates/single-product.php` into your (child) theme as
`om-catalog/single-product.php` — the plugin uses the theme copy when it
exists, so your edits survive plugin updates. Developers can also swap the
template via the `om_single_product_template` filter.

## Notes on scope

- No WooCommerce dependency, no cart/checkout — this is display-only, matching
  what was requested.
- Prices are fetched live (identical configurations are reused for up to 5
  minutes), since Overnight Mountings' pricing includes a daily metal-market
  snapshot.
- Product listings are cached briefly (default 15 minutes, adjustable in settings)
  to reduce API calls.
- If a product's style number changes or is discontinued on Overnight Mountings'
  side, the single product page will show a clear "not found" message rather than
  a broken page (and sends a real HTTP 404, so search engines drop it).
- Valid product pages send HTTP 200 with the product's name as the page title
  plus meta description and OpenGraph tags — safe to use as ad landing pages.
- Listing pagination uses an `?om_page=N` query parameter, which works reliably
  on Elementor-built pages (WordPress's pretty `/page/2/` URLs get redirected
  away on static pages).

## Visitor filters: top bar, dropdowns or sidebar

In the **OM Product Catalog** widget (Content tab > Visitor filters):

- **Collection filter**, **Shape filter**, **Metal colour filter** — switch on
  the ones shoppers should see.
- **Filter position** — *Top bar* (pills/tabs above the grid), *Dropdowns*
  (compact selects above the grid), *Sidebar — left* or *Sidebar — right*.
  On phones the sidebar folds into a "Filters" button.
- **Show result count** — "Showing 1–12 of 318" above the grid, with the
  active filters as removable chips.

The Style tab's **Sidebar & Dropdown Filters** section sets the sidebar
width, spacing, sticky behaviour, colours and typography. Shortcode
equivalent: `[om_catalog show_filters="yes" filter_shapes="yes"
filter_metals="yes" filter_position="left"]`.

Filtering updates the grid in place. Only the options the widget offers are
accepted, so visitors can't make the site run arbitrary catalog queries.

### Filter groups: order, headings, open or closed

Under **Filter groups** in the same section:

- **Order (drag to reorder)**: one row per filter, e.g. Product type,
  Collections, Shape, Metal colour. Drag the rows to reorder them; this
  applies to the sidebar, top bar and dropdowns. *One collection group, by
  name* moves a single group (e.g. "Peg Heads") on its own, and
  *Collections* stands for every group not listed separately. Each row can
  also set its own **Heading**, **Start closed** or **Hide this filter**.
- **Groups open and close**: each sidebar heading opens and closes its
  group. What a visitor opens or closes, and any "Show more" they expand,
  is remembered while they browse. A closed group shows the current pick
  beside its heading (**Show the pick on closed groups**).
- **Shapes look**: tiles with drawings, or a list with small drawings.
- **Metals look**: a row of colour swatches, or a list.
- **Options before "Show more"**: how many options long lists show before
  "Show 16 more".

Shortcode equivalent: `filter_order="shape,metal,peg-heads,collections,line"
filter_hide="line" filter_collapsed="metal"
filter_labels="shape=Diamond shape|metal=Metal colour" filter_accordion="yes"
filter_shape_look="tiles" filter_metal_look="swatches" filter_visible="6"`.
A collection group is named by its heading in lower case with dashes
(e.g. `peg-heads`).

## Price & buttons on product pages

In the **OM Single Product** widget (Content tab > Price & Buttons):

- **Price** — show the live price when available, or never show prices.
- **When no price is shown** — show text ("Call for pricing", optionally
  linked), show the buttons in the price's place, or show nothing.
- **Buttons** — any number, each with text, link, icon, style (solid,
  outline, text link), its own colours, and a rule: show always, only when
  there's no price, or only with a price.
- **Buttons position / Arrangement / Alignment** — under the price, after
  the description or after the options; side by side or stacked; left,
  centre, right or full width.

The Style tab's **Buttons** section covers typography, padding, height,
width, corner radius, border, icon size/spacing and normal/hover colours.

Right under the buttons, other plugins can add a line of proof through the
`om_product_assurance` filter (markup; it receives the product line and
style number). The Wulf Elementor Kit (1.25 or later) uses it for the shop's
Google rating, a short review about that kind of jewelry and its promises
(Wulf Kit > Settings > Reviews and promises by the Book buttons). Without
buttons it follows the price; quick views leave it out.

## Search, sorting and card prices

Every catalog grid has a **search box** (names, style numbers and carat
names of the active line, with suggestions as you type) and a **Sort by**
dropdown (Featured, Newest, Style number). Overnight Mountings' API has no
keyword search, so the plugin keeps its own small index per product line,
rebuilt every 12 hours (a few API calls, 500 products each).

Turn on **"From $X" price on cards** to show each design's starting price.
Prices load just after the page (so it never waits on them), are cached for
12 hours, and only appear once a markup is set.

## Loose diamonds

Drop the **OM Diamond Search** widget (or `[om_diamonds]`) on a page:
shape picker, carat and price ranges, lab-grown/natural, colour, clarity and
cut, sorting, and an expandable detail panel per stone (photo or 360° view,
specs, certificate link, "Select this diamond", "Ask about this diamond").
Diamonds use their own markup (**Settings > OM Catalog > Loose Diamonds**),
falling back to the jewelry markup.

## Ring builder

1. Create a page (e.g. "Design Your Ring") with the **OM Ring Builder**
   widget or `[om_ring_builder]`. The Wulf kit's "Ring Builder" page
   template already has it.
2. **Settings > OM Catalog > Ring Builder > Builder page** starts on
   **Find it automatically** (1.45.3): the published page with the builder
   on it is used (one at /ring-builder/ first), and the line under the menu
   says which. Choose a page to pin it, or **Off** for no builder buttons.
   A chosen page that's no longer published (a rebuilt or copied site)
   falls back to finding one. Also set which product lines count as
   settings (engagement rings by default).

Customers pick a setting and a diamond in either order, then see both with
the total price and a "Request this ring" form. The design lives in the page
URL, so it can be bookmarked or shared. Engagement-ring product pages get a
**Select this setting** button; the diamond search gets **Select this
diamond**.

### The guided flow (1.24)

- **Start screen**: "Start with a setting" or "Start with a diamond" (each
  can be switched off and reworded), a "Welcome back — continue your …"
  link for returning visitors, and up to four short promises.
- **Every step** says "Step 2 of 3", its title and one line of guidance
  ({setting} / {diamond} fill in what was chosen), with a progress line
  that links back to finished steps. Diamond-first flips the order.
- **Settings**: the grid looks like your catalog widget (see "Choose a
  setting" looks like), each card has **Choose this setting**, and after a
  diamond only settings in its shape show.
- **Diamonds that fit**: after a setting, the diamond search opens on its
  shape and carat range (strict, loose or shape only). When both are
  chosen, the setting's **head size is matched to the stone** (each carat is
  its own style number at Overnight Mountings) and the review says so.
- **"Your ring" bar**: the setting and diamond so far, the total when prices
  show, **Questions? Ask us** (a short inquiry pop-up, or your own link)
  and the next step. On phones it floats at the bottom.
- **Review**: metal and colour choices, price breakdown (only while prices
  show), **Book a viewing** (opens the form with that subject, or goes to a
  booking link), the request form with ring size and engraving (added only
  when your form doesn't already ask), **Share this design**, **Email it to
  me** (the visitor gets a link; you get a copy) and an optional "What
  happens next" list — off until you enter your steps.

**True size** (1.25): every diamond in the search and the builder review
has **See true size**. It draws the stone at its real size on a finger
(from the diamond's own measurements), with a ring band, and compares it
with typical 0.5, 1, 1.5 and 2 ct stones of the same shape. Visitors can
switch to a 3× close-up and change the ring size. Until the one-time
**screen check** is done (hold a bank card to the screen and match the
outline, saved per device), the size is labelled "about real size".

Switching it off:
- **Site-wide**: Settings > OM Catalog > Ring Builder > **True size** —
  untick the "See true size" line to remove the button everywhere, or
  untick "Screen check and the 'About real size' note" to keep the
  feature but hide the note and the card check.
- **Per page**: the **See true size** switch in the OM Diamond Search
  widget, and **True size on diamonds** in the OM Ring Builder widget
  (Settings & diamonds).

**Journey polish** (1.34):
- **One strip at the bottom**: on builder steps the AI assistant's button
  sits inside the "Your ring" bar instead of floating (OM Ring Builder ›
  "Your ring" bar › **AI assistant button in the bar**). The bar is hidden
  on the review step (**Also on the review step** brings it back), and
  until a step is done it says what to do ("Pick a diamond below").
  Elsewhere the floating button shrinks to its icon once visitors scroll
  (Settings › AI assistant › Button position).
- **Review**: the photo names the stone and metal; the request form has
  no "What is it about?" choices (requests arrive as "Ring request";
  switch the choices back under Review & request), ring size and
  engraving sit before the message, and a reassuring line shows under
  the button (**Line under the button**).
- **After sending**: a thank-you panel with the ring, the total and
  "What happens next" replaces the form (**After sending** title, text,
  steps; a booking link shows there too).
- **Diamonds**: a photo in each row when the feed has one, and
  **Compare** — tick up to 4 and see them side by side, with "Only show
  differences" (OM Diamond Search › **"Compare" diamonds**; OM Ring
  Builder › Settings & diamonds).
- **Product pages**: "Select this setting" is the first button under the
  price (OM Product › Ring Builder & Inquiry › **Button position**).
- **Follow-up email** (off by default): Settings › Emails › **Ring
  design — gentle follow-up** — once, a few days after a visitor emails
  themselves a design, only if no request has come from them since.

**Continue without a diamond** (1.33): the diamond step has a "Continue
without a diamond — choose it with us, or use your own stone" link, so a
setting alone can be requested. The review and the request then say the
diamond is still to be chosen (with you, or the customer's own stone), with
a **Choose a diamond now** link back. Switch it off or reword it in the OM
Ring Builder widget (Settings & diamonds > **"Continue without a
diamond"**).

**Help me choose** (1.26): a third way in on the start screen and a link
on the diamond step. Three questions — a budget (while prices show) or a
size (while they are hidden), what matters most (value, balance or
sparkle) and lab-grown or natural — then the three best real diamonds from
the live list, each with a tag and a plain-words reason ("Near-colourless
(G) — looks white in a ring"). Answers update the picks at once; **Choose**
takes the stone into the builder. After a setting, only diamonds that fit
it are suggested. Set it in the widget's **Help me choose** section: mode
(automatic, budget, size or off), texts, budget range and the start card.

The answers go with the visitor's request (and a "Questions? Ask us"
message): the inquiry email and the **Inquiries** list show e.g. "Budget
$5,250 · Oval · Most important: Sparkle · Lab-grown — chose our 'Top
sparkle' suggestion" (or "then picked a different diamond"). The visitor
sees a short note above the send button saying so; the copy they receive
leaves it out. Switch it off with **Send the answers with requests** in the
widget's Help me choose section.

Every text is in the widget's Content tab (Start screen, Steps & guidance,
Settings & diamonds, Help me choose, "Your ring" bar, Review & request); colours and corners
in Style › Builder.

## Saved designs

A heart on every card (catalog, "You might also like", the builder's
settings), beside the title on product pages and in the quick view.
Visitors keep up to 24 designs — on their device, no account needed — and
the **Saved** panel lists them with:

- **Compare** (the first four, in the compare table),
- **Share list** (a link that adds those designs to whoever opens it),
- **Email me my list** (photos and links to their inbox, with a button that
  reopens the list). You get a copy, saved under **Inquiries** as "Saved
  designs", so it doubles as a lead,
- **Clear list**, with Undo (removing one design has Undo too).

Where visitors find their list:
- the **"View saved"** button in the message after each save,
- a **heart with the count** in the catalog's slim toolbar (and in the
  phone's Filter · Sort pill),
- a floating **Saved** button (bottom left) on pages without a Saved
  button of your own — it disappears once you add one,
- your header: the **OM Saved Designs** widget (a heart with the count),
  the `[om_saved_button]` shortcode, or any menu link to `#om-saved`.

**How long it lasts**: the list is kept in the visitor's browser, with a
backup copy of the style numbers in a cookie (`om_saved`, up to a year, no
personal details) that your site sets. Safari and iPhone browsers wipe
what a page stores after 7 days without a visit; the list is then restored
from the cookie. It doesn't follow visitors to another device or survive
private browsing — "Email me my list" covers that. If your privacy or
cookie policy lists cookies, add `om_saved` (functional: remembers saved
designs).

Settings > OM Catalog > Look & feel > **Saved designs** turns the feature
(and "Email me my list") on or off site-wide. Each catalog / related widget
can hide the heart on its cards (Quick View, Compare & Save section), and
the product widget has a **"Save" (heart) button** switch under Sections.
Insights shows the **most saved** designs and how many became inquiries.

### One list with the Wulf kit (1.46)

With the Wulf Elementor Kit 1.16 or later, the kit's hearts (product row,
Spotlight, ring designer) and its quiz save into this same list, so a
visitor has one list across the homepage and the catalog. The kit's header
button opens the Saved panel and shows the count, and the floating Saved
button stays away. The panel then also has **Book to see them in person**,
which opens the kit's booking window with the saved designs. Designs saved
from the kit keep the **gold colour** that was on screen ("Yellow gold ·
Style 51157-E-6X4"), in the panel, in "Email me my list" (and your copy)
and in "Drop a hint".

For developers: `window.omSaved` offers `enabled()`, `list()`, `key(item)`,
`toggle({ l, s, t, i, u, c })` (saves or unsaves one design, with the usual
message), `add(items)` (adds without a message) and `open()`. An `om:saved`
event fires on `document` whenever the list changes.

## Drop a hint (1.39)

A small **Drop a hint** link (with an envelope) lets a visitor send a
design to a partner or friend. It shows:

- on product pages, under the buttons (and in the quick view),
- in the **Saved** panel, to send up to 6 saved designs at once,
- with the Wulf Elementor Kit 1.9.1 or later: on the Spotlight ring and
  on the ring style quiz results.

The visitor fills in a short form: the other person's name and email,
their own name and email, an optional note (up to 300 characters, with
three ready-made ideas to tap), their ring size (taken from the product
page when they already picked one), **Leave the prices out** (ticked to
start with) and **Send me a copy**.

**What the other person gets**

- An email ("Sam has dropped you a hint") with the photos, the note, the
  ring size and a button to a **private page**.
- The private page shows the designs in the chosen metal, the note and
  size, **Book a viewing** and **Ask about it**, and your promise line
  ("Free, no obligation, and we will keep it between us."). With the Wulf
  Kit, Book a viewing opens its booking popup with the design already
  filled in; otherwise it opens your inquiry form.
- The page has a private address that search engines are told to skip,
  isn't cached, and works for a year. Anything they send from it is marked
  "From a hint" in your inquiry email.

**What you get**

- A copy of every hint by email (reply to reach the sender), also kept
  under **Inquiries** as "Drop a hint: ...".
- A short email the **first time** the hint page is opened, so you can
  expect their call. Opens by the sender, by you (from your email) or by
  anyone logged in to WordPress don't count.
- The sender goes to your CRM (tag *drop a hint*). The person they sent it
  to is **never** added anywhere: their address is used for this one email
  and only appears in your copy.

**Settings**: Settings > OM Catalog > Look & feel > **Drop a hint** turns it
on or off site-wide, and sets the link text and the promise line on the
hint page. The four emails (to the other person, the sender's copy, your
copy and "opened") are under **Emails**; your two can be switched off. The
OM Single Product widget has a **"Drop a hint" link** switch under
Sections. Insights counts **Hints sent** and **Hints opened**.

**Spam protection**: the emails only carry designs from the catalog (the
form can't send anything else), notes and names can't contain web links,
and there are limits per connection (5 an hour), per sender (6 a day) and
per recipient (2 a day), plus the same hidden checks as the inquiry form.

For developers: `window.omHint.open({ items: [{ l: line, s: style, c:
'Yellow' }], from: 'my-button' })` opens the form for any designs, the
`om_hint_sent` action runs after a hint is sent, and a theme can replace
the page with `om-catalog/hint.php`.

## Insights (1.40; Insights 2.0 in 1.44)

Your own visitor analytics, built into the site and kept in your own
database. **Insights** (in the WordPress menu, under Dashboard) shows what
visitors do for any period (today, yesterday, the last 7, 30 or 90 days,
this month, last month, the last 12 months or your own dates), compared
with the period just before or with **the same time last year** (choose
under the period menu, **Compare with**).

It works like an app: sections, periods, filters and visits load in place
without reloading the page, and Back, Forward and bookmarks work as usual.
It wears the brand: ivory, ink and gold, the Fraunces and Manrope fonts,
and the colours set in the Wulf Elementor Kit.

**The overview, results first (1.44).**

- **Results**: a dark band at the top with the numbers that matter most:
  leads, visit requests (the leads closest to a sale), **calls and texts**
  (taps on the phone number or the Text button, with the split under the
  number, 1.48), the lead rate and the **value asked about** (the listed
  prices of the designs people asked about, requested or emailed
  themselves). Each shows its change and what it was. Under them, **what
  the leads were**: visit requests, inquiries and hints, designs emailed
  and newsletter sign-ups, as one bar.
- **This month's goals**: set a monthly goal for leads and visit requests
  (Settings) and the band shows how the month is pacing: "50 of 140, on
  pace for 110".
- **Visits and interest**: visitors, visits, engaged visits (more than a
  glance: more than one page, more than 10 seconds, a design opened, a
  lead, or a tap to call, text, email or get directions), designs viewed,
  saved, and directions and emails (taps to get directions or on the
  email address), each with its change and a small trend line.
- **What stood out**: plain sentences ranked by how much they matter,
  each with a **next step** and a link to the numbers behind it. For
  example "Google Maps & Business Profile: 23% fewer visits" (with about
  how many leads that cost and what to check), "Visit requests: 30%
  fewer", "Phones lag behind computers", "Best leads come from Email",
  "90 searches found nothing", "Halo Cushion Ring 2: much looked at, never
  asked about", "Pages are slow on phones", "Missing pages were opened 28
  times", "Many buyers take their time". See **No false alarms** below.
- **The chart**: pick any measure from the menu above it, or click a tile.
  Point at it (or tab to it and use the arrow keys) for each day, the same
  day in the period compared with, and the change. A day, week or month
  that isn't over (or that the period cuts short) shows as a hollow dot
  marked "so far" instead of a fall in the line. "Show as table" lists the
  same numbers.
- Where leads came from (the visit they got in touch on, or their first
  visit), designs (most viewed, rising, asked about, saved), pages,
  searches, who visited, the busiest hours and the latest leads.

The sections:

- **Leads**: leads by kind over time (stacked columns, visit requests at
  the bottom); kinds of lead; **where leads began** (the source of each
  lead's first visit, of the visit they got in touch on, and the visits
  that helped along the way, plus **Not linked to a visit** for leads sent
  with no visit recorded, so the rows add up to every lead); how long they
  took and how many visits; and every lead with the listed price of the
  design they asked about.
- **Sources**: each source with its share, engaged visits, lead rate (a
  small bar; an asterisk when fewer than 30 visits make it shaky) and the
  leads that began there; websites (l.facebook.com counts as
  facebook.com); campaigns; the first page of each visit.
- **Audience** (new): first-time and returning visitors and how each did,
  how often people came, devices with their lead rate, browsers and
  systems, where visitors are, the languages their browsers are set to,
  and the busiest days and hours.
- **Designs**: interest by price (share of views against share of leads
  for each price range), rising and cooling designs, every design with its
  price, designs viewed in the same visit, popular designs nobody asked
  about, product lines, options people pick, designs compared, story
  reels.
- **Pages**: **page speed** measured in visitors' own browsers (Google's
  Core Web Vitals: when the main picture showed, how fast taps answered,
  whether the page jumped, how fast the server answered), each rated
  good, needs work or poor, for phones and computers; the slowest pages;
  **missing pages** (addresses that showed "page not found" and where
  people came from, so you can add a redirect); every page.
- **Actions** (1.48 adds): taps on the Text button (and where they were),
  the kit's "Welcome back" bar shown, brand films played and watched to
  the end, and the booking calendar opened. Calls, texts and directions
  show where on the site they were tapped, by the name the kit's widgets
  have in Elementor ("Call to action", "Booking bar (in the page)").
- **Searches**, **Journeys**, **Live**: as before.
- **Funnels**: each step with the period compared with beside it.
- **Settings**: see below.

Everything also works with JavaScript switched off (each link is an
ordinary page), by keyboard, with a screen reader and on phones. Click
any source, website, campaign, page, design, search, place, device,
browser or system to see only those visits everywhere. Visits open in a
side panel. **Refresh** (the round arrow) gets the newest numbers; results
are otherwise kept for 3 minutes. Keys for periods: **T** today, **Y**
yesterday, **W** last 7 days, **M** last 30 days, **Q** last 90 days, **L**
last 12 months.

A small "Insights: last 7 days" box shows on the WordPress Dashboard (with
visit requests and calls and texts since 1.48).

**Counting it right (1.48).**

- **Phone apps credited to the right source.** Android tells a site which
  app a visitor came from, not a website, and those visits used to land
  in "Other websites" or "Direct". Now the Gmail, Outlook, Yahoo Mail and
  Samsung Email apps count as **Email**; the Google app and Google Go as
  **Search**; the Google Maps app as **Google Maps & Business Profile**;
  Facebook, Messenger, Instagram, Threads, Pinterest, TikTok, X, Reddit,
  LinkedIn, Snapchat, WhatsApp, Nextdoor and YouTube as **Social media**;
  ChatGPT, Perplexity, Claude, Gemini and Copilot as **AI assistants**.
  Other apps count as other websites, never as search.
- **Facebook and Instagram without a website.** Their apps often open
  links in their own browser and send no website. A visit like that, or
  one carrying Facebook's click ID (`fbclid`), now counts as **Social
  media** instead of Direct. A Facebook or Instagram ad looks the same, so
  tag ads with `utm_medium=paid_social` (or `cpc`) to see them under
  **Paid ads**. Links tagged with "maps" (for example
  `utm_source=google_maps`) count as Maps.
- **Calls, texts, emails and directions are engagement.** A visit that
  only tapped the phone number has done the most useful thing a visit can
  do; it no longer counts as a quick exit.
- **Every lead** counts only the visits up to the one they got in touch on.
  **Designs** are counted in full (they stopped at 400 before).
- **Not linked to a visit**: leads sent from a browser that asks not to be
  tracked, with tracking blocked, or a calendar booking that couldn't be
  matched to its visit now show under that name in where leads came from,
  so the sources add up to every lead.
- **The Back button**: a page shown again from the browser's memory (Back
  or Forward on phones) now counts as a page view, and starts a new visit
  when the old one ran out.
- **The kit's "Welcome back" bar and brand films** (played, watched to the
  end, moments and chapters chosen) are recorded, under Actions.
- **Bookings made in the SimplyBook calendar** count as visit requests (see
  **Bookings in the calendar** under Settings below).

Visits recorded before 1.48 are sorted again by the same rules once, when
the plugin updates (only the visits these rules change).

**No false alarms (1.48).** A small shop's numbers move by chance from
week to week, so **What stood out** now checks each change before it says
anything:

- A change is shown only when it is bigger than chance would usually
  make, and big enough to matter: leads need at least 10 across the two
  periods and a change of 10% or more, visit requests 8 and 15%, calls and
  texts 20 and 15%. A drop in leads or
  visit requests that is likely but not yet certain still shows, with "it
  could still be chance: worth keeping an eye on".
- **Sources** are compared both by visits and by their share of all
  visits, allowing for the number of sources checked at once, and a move
  must be at least 15 visits (or 2% of all visits) and 15%. The biggest
  losses come first, with about how many leads they cost at that source's
  usual lead rate and what to check ("Check your Google Business Profile:
  the website link, your hours, photos and recent posts"). A source that
  sent visits before and none now is named ("Email: no visits this
  period").
- "Best leads come from", "Phones lag behind computers", "Returning visitors
  are your best prospects", rising designs and "never asked about" need
  enough visits to tell. "Never asked about" needs a design viewed often
  enough that about 3 leads would have been usual.
- **Too early to compare**: when the period compared with starts before
  Insights began recording, changes aren't shown against it (they used to
  read "911% more").

**PDF report.** **Report** (next to the period menu) downloads Insights for
the period, comparison and filters chosen as one branded PDF, results
first:

- a cover with the results (leads, visit requests, lead rate, value
  asked about), what the leads were, the month's goals, visits and
  interest, the first things that stood out, and the contents;
- **What stood out**: every finding with its next step;
- **Leads**: by kind over time, where leads began, how long they took;
- visits over time, where visitors came from, who visited, when they
  visit, designs (with prices, interest by price, rising and cooling,
  viewed together), pages and speed (with missing pages), searches, what
  visitors did, and the funnels against the period compared with;
- at the back, every lead (the newest 100, with the listed price), the
  numbers for each day (or hour, week or month) and what each number
  means.

**One-page summary (1.48).** **Report** also offers a single page for a
meeting or the fridge: the results, what the leads were, visits and
interest, the first things that stood out with their next steps, where
leads came from (top 5) and the most viewed designs (top 5). The file is
named `…-insights-summary-…pdf`. The full report is the second link.

The full report opens with bookmarks for each part and takes a few
seconds; nothing is sent anywhere. Untick **Include the names of people who got in touch** for
a copy you can share outside the business. The file is named after the
site and the dates, for example
`wulf-diamond-jewelers-insights-2026-09-13-to-2026-10-12.pdf`.

**The visit behind each lead.** Each inquiry in wp-admin gets a **Their
visit** box (where they came from, visits so far, pages, designs looked at
and saved, options chosen, searches, and the whole visit step by step) and
the inquiries list gets a **Came from** column. The emails you get for
inquiries, hints, saved lists and ring designs, and with the Wulf Elementor
Kit 1.9.3 its visit requests, quiz matches and newsletter sign-ups, end
with the same **Their visit** summary. Customers never see it.

**Privacy.** Insights uses two first-party cookies with random IDs: om_sid
for the visit (30 minutes) and om_vid to recognise a returning visitor (up
to 400 days, can be switched off). No IP address is stored and nothing is
sent to other companies. A name or email is kept only when someone sends a
form, with that lead. Logged-in staff, bots and (by default) browsers set
to Do Not Track or Global Privacy Control are left out. Data is kept for 13
months (3 to 37 under Settings) and older visits are deleted every night.
You can download visits and actions as CSV, or delete everything. The
Settings tab suggests a line for your privacy policy.

**Settings** (Insights > Settings): collect on or off, leave out logged-in
staff, recognise returning visitors, respect Do Not Track, show the visit
behind each inquiry, measure page speed, how long to keep data, and the
**monthly goals** for leads and visit requests (0: no goal). Each change is
saved the moment you make it (a tick and "Saved" show). **Delete
everything** asks you to type DELETE first.

**Bookings in the calendar (1.48).** The SimplyBook calendar runs on
SimplyBook's own site, so the page can't see a booking finish. To count
each booking as a visit request:

1. In Insights > Settings, under **Bookings in the calendar**, click **Copy
   address** (it ends in a private key, so keep it to yourself).
2. In SimplyBook, open **Custom features**, switch on **API**, then its
   **Settings**, and paste the address as the **Callback URL** (keep the
   slash at the end).
3. Switch on the trigger for **new bookings** and save.

The card then shows when the last booking arrived. SimplyBook sends only
the booking's number, so these visit requests have no name ("Booked in
the calendar"); one is tied to its visit when exactly one visit had the
calendar open in the half hour before. Each booking counts once;
cancellations, changes and bookings for another SimplyBook company are
left out. Bookings your team adds in SimplyBook themselves (from a phone
call, say) may arrive this way too; they show as not linked to a visit.
The card shows only when a SimplyBook calendar is set up.

**Tips**

- Where visitors are: if the site uses Cloudflare, switch on "Add visitor
  location headers" (Rules > Managed Transforms) to see countries, states
  and cities. Without it, Insights shows time zones.
- Google Maps & Business Profile: tag the website link on your Business
  Profile, for example `https://yoursite.com/?utm_source=gbp&utm_medium=organic`,
  so those visits count as Maps rather than Google search.
- To see your own visit, open the site in a private window (logged-in
  staff are left out).

For developers: the `om_insights_rate_limit` filter (reports per minute
from one connection, default 120), the `om_email_details` filter (the
automatic block of every real email) and the Wulf Kit's
`wk_mail_after_rows` filter. Visits and actions live in two tables,
`{prefix}om_ins_sessions` and `{prefix}om_ins_events`. The PDF report is
`admin-post.php?action=om_ins_report` (same period and filter parameters
as the page, plus `cmp=year`, `names=0|1` and `one=1` for the one-page
summary; `manage_options` and the `om_ins_report` nonce), drawn by `OM_Insights_Pdf` with tFPDF 1.34 (LGPL
2.1, in `lib/tfpdf`) and the fonts in `lib/fonts` (SIL Open Font License).
It needs PHP's mbstring extension. Page speed is stored per page view in
the actions table (`lcp`, `inp`, `ttfb` in milliseconds, `cls` x1000 + 1;
database version 3, added on update) and a "page not found" view has
`meta = '404'`. Database version 4 (1.48) adds `contacts` to the visits
table (taps to call, text, email or get directions in that visit) and an
index on the actions table (`type, day, item, sid`) that makes reports
faster, the full PDF report most of all. SimplyBook's callback is
`POST /wp-json/om-catalog/v1/calendar-booking/{key}/` (JSON or form data
with `booking_id`, `company` and `notification_type`; a wrong key gets a
403). Phone apps are mapped to sources by `OM_Insights::app_channels()`.

## Analytics

What visitors do is sent to the tracking already on your site — Google
Analytics 4 (gtag, e.g. Site Kit), Google Tag Manager (dataLayer) and the
Meta pixel. Nothing is added or sent anywhere else, and nothing happens if
none is installed.

| Event (GA4 / GTM) | When | Meta pixel |
| --- | --- | --- |
| `view_item` (`view_method`: product_page / quick_view) | a design is viewed | ViewContent |
| `add_to_wishlist` | the heart | AddToWishlist |
| `compare_designs` | the compare table opens | CompareDesigns |
| `share` (`content_type`: product, compare, saved_list, ring_design) | a share link | Share |
| `search` | a catalog search | Search |
| `generate_lead` (`form_type`: inquiry, saved_list_email, ring_design_email, drop_a_hint) | a form is sent | Lead (+ Schedule for viewings) |
| `ring_builder_step` | each builder step | RingBuilderStep |
| `diamond_guide`, `diamond_guide_choose` | Help me choose answers / a suggestion chosen | DiamondGuide… |
| `book_viewing_click` | Book a viewing | BookViewingClick |
| `true_size` | See true size | TrueSize |
| `hint_open`, `hint_sent` | the Drop a hint form opens / a hint is sent | (Lead, via `generate_lead`) |
| `hint_view`, `hint_cta` (`cta`: book, ask) | the hint page is opened / a button on it | |

Items carry the style number, name, line and (when shown) the price. In GA4,
mark `generate_lead` as a key event to count inquiries as conversions.
Turn it off (or just Meta) in Settings > OM Catalog > Analytics. Admins can
watch the events in the browser console with `?om_debug_events=1`.
Developers can listen for the `om:track` event on `document`
(`detail: { name, params }`); the currency is filterable with
`om_analytics_currency` (default USD).

## AI assistant ("Ask our jeweller")

A friendly chat that answers jewellery questions and suggests real designs,
then hands over to your team. Off until you switch it on in **Settings >
OM Catalog > AI assistant**.

**What it answers from** (1.35, each switchable under *What it knows*):
- **Your catalog** — real designs, shown as photo cards (always on).
- **Product details from Overnight Mountings** — metals, colours, carat
  sizes, stones and how each suggested design is sold.
- **Live diamonds** — when visitors ask about stones, it reads shape,
  carat, lab-grown/natural and budget from the question, looks up real
  diamonds (widening the search when nothing matches exactly) and can show
  two as cards that open the ring builder with that stone.
- **Your website's pages** — your own pages (and optionally blog posts)
  for shop facts: services, policies, FAQs, your story. It links the page
  it used. Only published, public pages; leave any out by ID.
- **Prices** — the prices your site shows ("from $1,188", diamond prices),
  never wholesale, and only while prices are on.

**Branding** (*Look*): your logo or monogram (round, in the chat header and
optionally on the button), main and accent colours, and the line under its
name. A theme or kit can give the chat the shop's own mark, name and button
text with the `om_assistant_brand` filter (`mark`: SVG in one colour, `name`,
`launcher`); the Wulf Elementor Kit 1.30 does (the logo's diamond W, the
business name and "Ask our jeweler"). *Button icon* then offers **Your brand
mark** (the default), **Sparkle** or **Your logo**, and anything filled in
under *Name & texts* still wins (1.50).

- **Providers:** OpenRouter (free models work — list several and each is
  tried in turn if one is busy), Google Gemini, or Anthropic Claude
  (Opus 5.5 by default; Sonnet 5.5 or Haiku 4.5 selectable). Keys stay on
  your server and are never shown again after saving.
- **It can't invent pieces or prices:** the plugin finds the matching designs
  in your catalog (shape, style, carat, product type, the page being viewed)
  and gives the AI only those; the AI writes the reply and picks designs,
  which appear as photo cards with Save hearts. Prices, discounts, stock and
  timings are always left to your team.
- **Your shop facts:** fill in "About your shop" (hours, services, policies);
  it uses nothing else about the shop.
- **Hand-over:** "Talk to our team" opens your inquiry form inside the chat,
  with the whole conversation attached to the email and the Inquiries entry.
- **Never broken:** with no key, a provider down, or a limit reached,
  visitors still get matching designs and the contact form.
- **Limits:** off by default; optionally messages per visitor per hour and
  AI answers per day. Today's count and the last problem (if any) show in
  Settings; admins also see the reason in the chat when an answer fails.
- **Position:** bottom right or left, distances in px; it moves up only while
  a bar (compare tray, phone filter pill, product bar, or any element marked
  `data-om-ai-lift`, like the Wulf Kit's phone bar and booking bar) sits
  under it.
- **Where it shows** (1.38): catalog pages, catalog pages and the homepage,
  or every page. On the homepage an optional **starter question** appears as
  a small bubble beside the button after a few seconds (or once the visitor
  scrolls a third of the page), once per visit, with two suggested questions
  to tap. Set its words and delay, or leave it empty to turn it off. Themes
  and plugins can add pages with the `om_assistant_show_here` filter and say
  which page counts as the homepage with `om_assistant_is_home`.
- **Test** it from Settings with one click. The conversation follows the
  visitor across pages; any link to `#om-ai` opens it. Analytics:
  `assistant_open`, `assistant_message`, and `generate_lead` with
  `form_location: assistant`.

## Emails

**Settings > OM Catalog > Emails** sets up every email the plugin sends:

| Email | To | Can be switched off |
| --- | --- | --- |
| New inquiry | you (To / Cc / Bcc) | — |
| Inquiry confirmation | the customer | yes |
| Saved designs | the visitor who asked | (the feature itself, under Look & feel) |
| Saved designs — your copy | you | yes |
| Ring design | the visitor who asked | — |
| Ring design — your copy | you | yes |
| Drop a hint | the person they send it to | (the feature itself, under Look & feel) |
| Drop a hint: their copy | the visitor who sent it, if they ask | (the feature itself) |
| Drop a hint: your copy | you | yes |
| Drop a hint: opened | you, the first time the hint page is opened | yes |

For each: recipients (emails to you), subject, heading, the message in the
WordPress visual editor (formatting, lists, links, images), button text, and
placeholders such as `{customer_name}`, `{piece}`, `{price}`, `{link}` —
click one to insert it. `{details}` places the automatic block (the piece
with its options and price, the saved designs, the customer's answers).
**Preview** and **Send a test** use what's on screen, before saving.

**Email design** applies to all of them: logo (from the media library),
brand, accent and background colours, sender name and address, and a footer
(address, hours, links). Use a sender address on your own domain with an
SMTP plugin so emails reach inboxes.

## Inquiries

Product pages, diamonds and the builder review have an inquiry form. Each
inquiry is emailed to the address in **Settings > OM Catalog > Inquiries**
(default: the site admin email) and saved under **Inquiries** in wp-admin,
with the piece, chosen options, price shown and page link. Spam is filtered
with a hidden field, a minimum fill time and a per-visitor hourly limit.

**Never only an email (1.49).** Everything people send from the site is kept
under **Inquiries** before it's emailed: catalog inquiries, hints, saved
lists, ring designs from "Email it to me" (kept even when the email to the
visitor fails, so you can follow up), and, with the Wulf Elementor Kit 1.29,
its visit requests, ring style quiz matches and newsletter sign-ups, each
with **Their visit**. An inquiry whose email to the shop didn't go is marked
**Not emailed** in the list, with the reason when you open it.

**Cached pages (1.49).** The form needs no security token, and its signed
time stamp no longer expires, so a page a cache keeps for weeks still sends.
If the site's security keys change while a page sits in a cache, the form
gets a fresh stamp and sends again by itself (it used to drop the inquiry
while telling the visitor it was sent).

**When emails fail (1.49).** When WordPress can't send an email (no mail
server on the host, a wrong SMTP password), admins see a notice in wp-admin:
how many failed in the last 7 days, the last one and why, and buttons for
**See inquiries**, **Send a test email** (to the inquiry address) and
**Dismiss** (it comes back with the next failure). Once an email goes again
it reads "may be fixed". The usual fix is an SMTP plugin, such as WP Mail
SMTP, connected to the shop's Google or Microsoft email account. Only
failures WordPress itself sees are counted: an email the host accepts and
then drops, or one that lands in spam, looks sent from here, so send a test
after any change.

**Edit the fields** under **Settings > OM Catalog > Inquiry form fields**:
add, remove and reorder fields (text, email, phone, paragraph, dropdown,
radio buttons, checkboxes, single checkbox, date, number), each with its own
label, placeholder, choices, width (half/full) and required flag. That form
is used everywhere; an OM Single Product widget can instead use its own field
list (**Ring Builder & Inquiry > Form fields > Custom fields for this
widget**). Optionally the customer gets a confirmation email.

The widget also sets the title, intro and button text, and its Style tab has
an **Inquiry Form** section. Or choose **My own form
(shortcode)** to use an Elementor Pro form (via `[elementor-template id=".."]`),
Contact Form 7, Gravity Forms or WPForms: give the form hidden fields with
the IDs/names `om_product`, `om_style`, `om_price`, `om_options`, `om_url`
(the page with the chosen options), `om_image` (and `om_diamond`) and they
are filled with the piece being viewed. Those
leads then land wherever that form sends them (e.g. Elementor > Submissions).

## Booking calendar: SimplyBook (1.45)

Wherever the site offers to get in touch, visitors can see the inquiry form
(as before), your SimplyBook.me booking calendar, or **both as two tabs**
("Book an appointment" and "Send a message"). Choose in **Settings > OM
Catalog > Inquiries > Inquiry form or booking calendar**:

- **Show visitors**: the choice for every place. It starts on **Inquiry
  form**, so nothing changes until you pick something else.
- **Place by place**: a place can have its own choice, or follow the one
  above ("Same as above"):

| Place | What it covers |
| --- | --- |
| Product pages | the inquiry box on every product page (its sticky button says "Book now" when only the calendar shows) |
| Ring builder: the last step | "Request this ring" on the review step |
| "Ask us" pop-ups | the ring builder's questions, and "Haven't found the one?" after the last design in a listing |
| Diamond search | "Ask about this diamond" |
| Hint pages | what the person who got the hint sees ("Book a viewing" opens the calendar tab) |
| AI assistant | "Talk to our team". Starts on the form, so the chat so far goes with the message |
| Wulf kit | the kit's "Book a free consultation" panel and its visit form (listed when the Wulf Elementor Kit is active) |

- **SimplyBook calendar**: the calendar from the old site
  (aalanddiamond.simplybook.me) is already set up. To change it, open
  **Change the calendar** and paste the widget code SimplyBook gives for its
  calendar (iframe) widget, or just your SimplyBook address
  (`https://yourname.simplybook.me`). The page shows which calendar is set
  up rather than the code, so an empty box keeps it; **Remove the calendar**
  sends every place back to the form. Anything that isn't a SimplyBook
  widget code or address is refused with a note, and the calendar stays as
  it was.
- **With both**: the names of the two tabs and which one is open first.
  The ring builder's form tab is called "Send the request".
- **Line above the calendar**: one short line (empty for none).
- **On product pages** (1.45.1): the form or calendar box sits **right
  under the buttons** (such as "Call us"), before the metal and size
  choices, or **at the end of the product details** (where it was before
  1.45.1).

An **OM Single Product** widget can choose for its own page: **Ring Builder
& Inquiry > Show visitors** (form, calendar or both) and **Where on the
page** ("As in Settings › Inquiries" follows the settings). The kit's
**Visit** widget has the same calendar choice under **Booking form**.

Good to know:

- **What is used from the code**: only the widget's settings (your
  address, colours and calendar layout), read and checked. The pasted text
  is never printed on the site. The calendar always shows in the page, even
  if the code was for SimplyBook's button or pop-up widget.
- **Speed**: the calendar itself (SimplyBook's booking page) loads only
  when it comes into view or its box, tab, pop-up or panel opens, so pages
  without one load nothing extra. On pages with a calendar, the connections
  to SimplyBook open while the page loads, and SimplyBook's script is
  fetched once the page has finished loading (or as soon as a visitor
  points at or taps a "Book" toggle, tab or link). Opening the calendar
  then only waits for SimplyBook's own page.
- **If it can't load** (a blocker, a slow connection, SimplyBook down), the
  box offers **Open the booking page** instead, and every calendar has
  "Calendar not showing? Book on our booking page" under it. Without
  JavaScript both parts show, one above the other.
- **Colours**: the calendar is SimplyBook's own page shown in a frame, so
  your site's styles can't reach inside it. Its colours come from the
  `theme_settings` in the widget code or SimplyBook's design settings. A
  `<style>` that came with the old embed (like `.sb-available-date`) isn't
  needed.
- **Bookings live in SimplyBook**, not under Inquiries, and SimplyBook sends
  its own confirmations. The calendar can't carry the piece being looked
  at, so on product pages and diamonds a line above it says "Coming in to
  see this piece? Mention style 85121-2 when you book." Where the details
  matter most (the ring builder, the assistant), "Both" keeps the form one
  tap away.
- **Links**: `#om-inquiry?tab=book` opens the calendar tab and
  `#om-inquiry?tab=form` the form tab, e.g.
  `#om-inquiry?subject=Book%20a%20viewing&tab=book`. A subject about
  booking, a viewing, an appointment or a visit opens the calendar tab by
  itself.
- **Anywhere else**: `[om_booking_calendar]` puts the calendar on any page
  (optional `heading="…"` and `intro="…"`).
- **Analytics** (with measuring on): `booking_calendar_view` when a
  calendar has loaded, with `form_location` (product_page, ring_builder,
  diamond, hint_page, assistant, quick_view or page) and the style number.
- **Insights** (1.48): each booking made in the calendar can count as a
  visit request. Paste the address from Insights > Settings > **Bookings
  in the calendar** into SimplyBook's API callback (steps under Insights
  above).

## Related & recently viewed products

The **OM Related Products** widget (or `[om_related source="related|recent|picked"]`)
shows a grid or swipeable carousel below the product:
- **You might also like** — same line, same collection or centre shape where
  known, never the product itself or its size variants;
- **Recently viewed** — remembered in the visitor's own browser; hidden until
  they have viewed other pieces;
- **Hand-picked** style numbers.

The built-in product page shows "You might also like" and "Recently viewed"
automatically (toggle under Settings > OM Catalog > Built-in product page rows).

## Filtering & curating what shows (Elementor or shortcode)

The widget's Content tab (and matching shortcode attributes) control what
appears:

- **Product line** — engagement rings, wedding bands, etc. (`line=`)
- **Collections dropdown** (Elementor) — a grouped multi-select of the line's
  real categories and subcategories, pulled live from Overnight Mountings'
  taxonomy (cached 12 hours). Pick one or more; leave empty for all. A
  free-text **custom collection filter** (`style=`) and independent
  **set filter** (`set=`) sit alongside it for anything unusual.
- **Center-stone shape** — e.g. "Round,Oval" (`shape=`)
- **In-stock only** toggle (`in_stock="yes"`)
- **Show ONLY these style numbers** — comma-separated list that turns the
  widget into a hand-picked showcase (`include=`)
- **Hide these style numbers** — removes specific products from the grid
  (`exclude=`). Hidden products are filtered out after fetching (the API has
  no exclusion parameter), so a page can show slightly fewer items than
  "Products per page" — fine for curating out a handful of pieces.

## Styling the catalog per page (Elementor)

The **OM Product Catalog** widget is fully editable in the Elementor editor.
The Content tab picks what to show (product line, collection/set filters,
products per page, responsive columns, show/hide the carat line and
pagination). The Style tab exposes the whole look with live preview: grid
gaps and margins, card background/border/padding/alignment, image aspect
ratio, background and hover zoom, title and carat-line colors + full
typography, and pagination colors, alignment and typography. Anything left
untouched inherits the site-wide defaults from Settings > OM Catalog, so
per-widget styling is opt-in.

## Product page layout (1.6)

The product page is organised as: title and price, options, the main
button(s), then collapsible **Description**, **Stone details** and
**Specifications** sections and the inquiry form. In the OM Single Product
widget (**Layout & Options**), or under Settings > OM Catalog > Product page
for the built-in page:

- **Options display** — Swatches (colour circles for metal colour, pills for
  the rest), Pills, or Dropdowns. Style them under **Options (Swatches &
  Pills)**.
- **Description & details** — collapsible sections or always open.
- **Ring size picker** + **size guide** pop-up (how to measure, US size chart,
  printable true-size sizer). Shown on the product lines listed in Settings;
  the chosen size is priced (OM's fingerSize) and included in inquiries.
- **Gallery stays in view** while the details scroll (desktop/tablet).
- **Sticky price bar on phones** — price + main button pinned to the bottom
  once the visitor scrolls past them.

Listing grids add **Quick view** (photos, price and options in a pop-up),
**badges** (your own per style number, automatic "New", centre shape) and
shimmering **placeholder cards** while filters load.

**Background refresh** (Settings > OM Catalog > Caching) re-fetches the
catalog pages visitors use, the product lines, collections and search index
every 10 minutes via WP-Cron, so visitors are served from cache. For exact
timing, set a real server cron to call wp-cron.php.

## Product videos (1.7)

Most OM products carry a video, and the plugin makes it the centrepiece:

- **Video first** (default) — the product page opens on the video, playing
  silently on a loop like a live showcase, with a sound toggle and a full
  screen button. Photos follow in the thumbnails; the first thumbnail is the
  labelled **Video** tile. Switching to a photo shows a **Watch video**
  button to come back.
- **Photos first** — the photo leads, with the **Watch video** button on it.
  Pick either under Settings > OM Catalog > Product page (built-in page) or
  the OM Single Product widget's **Product videos** control.
- **Full screen** — the lightbox mixes videos and photos, with player
  controls and sound.
- **Listing cards** — a small play badge marks products with a video. On
  desktop the video plays over the photo while the card is hovered; on
  phones, the card nearest the middle of the screen plays as the visitor
  scrolls (one at a time). Turn off with the catalog widget's **Video previews on
  cards** switch or `card_video="no"`.
- **Quick view** opens on the video too.
- Considerate by default: autoplay is always muted (browsers require it),
  videos pause when scrolled away, nothing loads for card previews until
  needed, and visitors with *reduced motion* or *data saver* get a paused
  player with controls instead. A file a browser can't play falls back to
  the photos. Card previews need direct video files (.mp4/.webm/.mov);
  YouTube/Vimeo links play on the product page only.

Settings > OM Catalog > Tools > Test connection reports how many products in
a line have videos.

## Widget controls for quick view, videos and the gallery (1.8)

**OM Product Catalog** and **OM Related Products** widgets:

- **Content › Quick View** — on/off, button text, look (bar across the
  photo, centred button, or eye icon), show on phones & tablets, what the
  pop-up shows (price, options, description, carat & style number, ring
  builder button), whether it opens on the video or the photo, and the
  "full details" link text.
- **Content › Videos on Cards** — video badge (play icon, play icon + text,
  or none), its text and corner, and video previews on/off.
- **Style › Quick View Button / Quick View Pop-up / Video Badge** — colours
  (normal + hover), borders, radius, padding, sizes; pop-up background,
  page overlay, width, radius, spacing and close button, plus **Photo
  column width** (the share of the pop-up the photo takes).
- **Pop-up thumbnails** (Content › Quick View): beside the photo, under it
  (the photo column narrows to 44% so the details get more room), or
  hidden.
- Catalog widget also gets **Style › Card Price** and **Style › Search &
  Sort**.

**OM Single Product** widget, **Content › Gallery & Video**: video first or
photos first, autoplay, sound button, full screen button, "Watch video"
button and its text, video thumbnail label, thumbnails left / under / hidden,
zoom on hover, click to open full screen, and photos following the metal
colour. **Style › Gallery** (photo background and radius, thumbnail size,
spacing, radius, borders) and **Style › Video Buttons**.

**OM Diamond Search** widget: lab-grown/natural switch, shape selected at
first, and **Style › Filters / Results** (chips, selected state, table
headings, rows, hover, price, buttons).

Shortcode equivalents on `[om_catalog]` and `[om_related]`: `quick_view`,
`qv_text`, `qv_style` (bar|button|icon), `qv_mobile`, `qv_parts`
(price,options,description,meta,builder), `qv_video` (first|thumb),
`qv_thumbs` (left|bottom|none), `qv_link_text`, `video_badge` (icon|label|none), `video_badge_text`,
`video_badge_pos` (tr|tl|br|bl), `card_video` (yes|no).

## Photos that follow the selected options (1.8)

- **Metal colour:** picking a colour switches the gallery to that colour's
  photos (and video, when videos are per colour) and brings the first one
  up; Platinum shows the white photos. Photos that aren't colour-specific
  stay in every colour. This works when Overnight Mountings' data tells the
  photos apart: a colour on each image, images grouped by colour, or file
  names such as `…-YG-1.jpg` / `…_rose_…`. Settings › OM Catalog › Tools ›
  Test connection reports whether your catalog does. Turn it off under
  Settings › OM Catalog › Product page or in the widget.
- **Listings filtered by a metal colour** show each card in that colour and
  open the product in it.
- **Carat sizes** are separate designs (their own style numbers and photos)
  in OM's catalog, so choosing one opens that design's page — now keeping
  the metal, colour, setting, quality and ring size already picked. The same
  goes for "View full details" in quick view. Links can do this too:
  `?om_metal=18 KT&om_color=Rose&om_size=7`.

## Inquiry emails (1.9)

The built-in form sends an HTML email (with a plain-text copy for mail apps
that prefer it):

- **Subject:** `New inquiry: {title} (Style {style number}) — {name}`
  (change it with the `om_inquiry_subject` filter).
- **Product card:** photo (in the metal colour chosen), title, style number,
  options, price shown, a **View this piece** button and the page URL. The
  link reopens the exact configuration (`?om_metal=…&om_color=…`).
- **Their answers** from the form, and a footer reminding you that
  replying goes straight to the customer (Reply-To).
- The title, style number, photo and page come from Overnight Mountings'
  own data (a cached lookup), not from the browser, so spam can't inject
  its own text or links.
- The optional customer auto-reply shows the same product card.
- **Inquiries** in wp-admin lists each lead with the photo, title, style
  number and a link to the configured piece.

## Consistent hover states (1.9)

Themes such as Hello Elementor, and Elementor's global kit, restyle every
button and link (a pink or kit-coloured hover background, purple link hover,
16px text, 3px corners). Every plugin button and link now sets its own
colours for rest, hover and focus, and its own size and shape, strongly
enough to beat the theme but not the widgets' style controls. One hover
language throughout: solid buttons invert, outline buttons fill, text links
fade, icon buttons tint, and keyboard focus shows a ring in your brand
colour.

## Look & feel (1.11)

Settings > OM Catalog > **Look & feel** keeps every OM widget and page
consistent:

- **Corner radius** for buttons, pills and fields, and a second one for
  photos, cards and pop-ups (0 = square, the default).
- **Spacing**: compact, comfortable or airy — the rhythm of the product
  page, toolbar and rows.
- **Card hover**: lift (card rises with a soft shadow, name underlined —
  default), zoom (slow photo zoom) or none. Second photos fade in slowly.
- **Trust line** under the price, e.g. `Free resizing | Certified diamonds
  | Made to order` (empty = hidden). The Single Product widget can use it,
  set its own, or hide it, and style it under Style > Price.
- **Text sizes on phones** for product names, card names and body text.
  Long names are balanced over two lines.

## Search (1.11)

- **Grouped search across lines.** The catalog widget's *Suggestions
  search* setting: the line being browsed, all lines in the widget, or
  every product line — each line gets a heading, its best matches and "See
  all (n) in {line}".
- **Stand-alone search box** for a header: the **OM Search** widget or
  `[om_search]` (`lines="engagement-rings,wedding-bands"`, empty = all;
  `results_page="ID"`; `placeholder`; `button="no"`). "See all" and Enter
  open the **Search results page** (Settings > OM Catalog > Search) — a page
  with an OM Product Catalog widget showing those lines.
- **Recent and popular searches** appear when a visitor clicks into an
  empty search box. Recent ones stay in the visitor's browser; popular ones
  are your list (Settings > Search), topped up with what visitors search
  most (can be turned off).
- **Empty and error states**: "Nothing found for …" with *Clear search* /
  *Clear all filters*, one-click "Without {filter}" chips, lines where the
  search does match ("Found in"), and popular searches; errors get a *Try
  again* button that reloads just the grid.

## Diamond results (1.11)

Colour, clarity and cut appear as small badges (top grades — D–F, FL–VVS2,
Ideal/Excellent — highlighted), the report shows the lab and Lab-grown /
Natural, and the column headings stay in view while scrolling.

## Inquiry subjects (1.13)

Settings > OM Catalog > Inquiries:

- **Subjects** — one per line (default: General question, Price request,
  Book a viewing, Custom design, Ring sizing). Visitors pick one as pills
  at the top of the form; it heads the email and its subject line.
- **Email subject line** template with `{subject}` `{piece}` `{title}`
  `{style}` `{name}` `{email}` `{phone}` `{price}` `{site}` — default
  `{subject}: {piece} — {name}`, e.g. "Book a viewing: Halo Ring (Style
  80285-04) — Jane". The customer's copy says "We received your inquiry:
  Book a viewing".
- **Preselect from any button**: link it to `#om-inquiry?subject=Book a
  viewing` — the form opens, scrolls into view with that subject chosen.
- The OM Single Product widget can show/hide the choice, use its own list,
  preselect one and use its own subject template (Inquiry section).
- Only listed subjects are accepted (the list is signed); anything else
  falls back to the first.

## Browsing extras (1.14)

- **Zoom** — on product pages open the photo viewer, then double-click /
  double-tap, scroll-wheel or pinch to zoom, drag to pan; the + / − / 0 keys
  and the on-screen buttons work too.
- **Quick filters from badges** — shape and "Popular" badges on cards are
  links: tapping "Oval" filters the listing to ovals, "Popular" sorts by most
  viewed (widget > Cards: Clickable badges).
- **Show more / infinite scroll** — widget > Pagination style: Page numbers,
  "Show more" button, or Infinite scroll. The address remembers how far the
  visitor got (`om_upto`), so Back from a product returns to the same spot.
- **Compare** — a "Compare" toggle on each card collects up to 4 designs
  (from any line) in a tray at the bottom of the page; "Compare now" opens a
  side-by-side table (photo, starting price, carat, centre stone, stones,
  metals, colours, settings, video). The tray persists across pages.
  Shortcode `compare="no"` or the widget switch turns it off.
- **Most viewed** — a sort option ordered by real product page views
  (counted once per visitor session; rate-limited). The 12 most viewed
  designs per line (5+ views) get a "Popular" badge; "New" badges still
  come from the API.
- **Smooth page transitions** — the clicked card photo glides into the
  product page (Chrome, Edge, Safari 18+). Settings > OM Catalog > Look &
  feel to turn off.
- **Accessibility** — keyboard support throughout (Escape closes the filter
  sheet, dialogs trap and return focus), results changes are announced to
  screen readers, suggestion lists expose the active item, and small grey
  text was darkened to meet WCAG AA contrast (checked with axe: 0 issues).

## Complete the set (1.15)

A "Complete the set" row pairs a ring with matching wedding bands (and a
band with the engagement rings it suits).

- **Where** — on the built-in product page it sits above "You might also
  like" (Settings > OM Catalog > Built-in product page rows). In an
  Elementor product layout add **OM Related Products** and set
  *Show: Complete the set*. Shortcode: `[om_related source="set"]`.
- **Which designs** — Overnight Mountings has no "matching band" field, so
  the row takes, in order:
  1. pairs listed in Settings > OM Catalog > Complete the set, one per
     line: `80285-04 = 12345-01, 12345-02` (works both ways);
  2. designs of the same family (same style-number root) in the other line;
  3. the same style (Halo, Solitaire…) in the metal colour picked;
  4. the other line's most viewed designs, then its own order.
- **Follows the metal** — pick Yellow on the ring and the bands' photos
  switch to yellow, and their links open in the same metal and colour.
- **Set price** — each card shows the band's "From" price and "Set from"
  (ring + band), when card prices are on.
- **Ask about this set** — opens the page's inquiry form with the subject
  "Bridal set" and the band attached ("Together with…", removable). The
  email shows both pieces with photos and links, and the subject reads
  "Bridal set: Halo Ring (Style 80285-04) + Band (Style 12345-01) — Jane".
  The `{pair}` token is available in the subject template.
- **Widget options** — Pair with line (automatic or a specific line), line
  under the title, "Set from" price and "Ask about this set" switches, plus
  all the usual card, quick view and style controls.

## Recently viewed in search (1.16)

Clicking into an empty search box opens a "Recently viewed" strip above
the recent and popular searches: the last designs this visitor looked at
(newest first, the one on screen left out), each with its photo, name,
style number and "From" price. The same strip appears when a search finds
nothing, so the visitor can go straight back to a piece they liked.

- Arrow keys move through the cards like any suggestion; Enter opens one.
- "Clear" forgets the history (it's kept only in the visitor's browser —
  the same list as the "Recently viewed" product row).
- How many cards: **OM Catalog** widget > Search > *Recently viewed in
  search*, **OM Search** widget > *Recently viewed in search* (0 = off,
  up to 8; default 4). Shortcodes: `suggest_viewed="4"` on `[om_catalog]`
  and `[om_search]`.
- Prices follow the *Prices in suggestions* switch.

## Quiet page intro & catalog heading (1.17)

The first time a visitor lands on a listing, the page settles in: the
heading eases into place (its letter spacing gently tightens, the rule
draws in), then the filters and toolbar, then the cards one after another.
Filtering or paging afterwards is instant, and visitors who prefer reduced
motion never see it.

Everything is in the **OM Catalog** widget:

- **Content > Page intro** — on/off; *Play*: first visit to the page,
  once per visit, or every load; *Motion*: rise, fade, blur to sharp,
  settle (zoom); duration; delay between cards; rise distance; how many
  cards take part (0 = none); whether the filters & toolbar take part;
  whether the page's own H1 (e.g. an Elementor Heading) joins in — the site
  header and logo are never touched. In the editor it always replays so
  changes can be previewed.
- **Content > Heading** — an optional heading above the catalog: eyebrow,
  title (`{line}` = the product line shown), HTML tag, thin rule, text,
  responsive alignment.
- **Style > Heading** — colours and typography for eyebrow, title and
  text, text width, rule colour/width/thickness, space below.

Shortcode: `[om_catalog intro="yes" intro_when="first" intro_style="rise"
intro_speed="700" intro_stagger="70" intro_cards="8" intro_toolbar="yes"
intro_page_title="" head="yes" head_eyebrow="" head_title="{line}"
head_text="" head_rule="yes" head_tag="h2" head_align="center"]`
(the intro is off by default in shortcodes, on by default in the widget).

## End-of-results card (1.18)

When a visitor reaches the last design (last page, or when "Show more" /
infinite scroll runs out), a closing card offers a next step instead of a
dead end: "You've seen them all — Haven't found the one?".

- **Main button** — opens the built-in inquiry form in a pop-up (subject
  "Custom design" preselected; the email notes the listing they were on),
  or goes to a link (e.g. a booking page), or none.
- **Second button** — *Smart*: "See all designs" (clears the filters, in
  place) when the listing is filtered, otherwise "Back to top"; or a link,
  or none.
- **Layout** — a card in the grid, or a full-width banner. **Look** — soft
  tint, outline, dark (brand colour) or a photo background with overlay.
- Eyebrow, title and text are editable; `{count}` and `{line}` fill in,
  e.g. "All {count} {line}, seen."

All of it is in the **OM Catalog** widget (Content > End of results, Style
> End of results: colours, typography, alignment, padding, minimum height,
corner radii). Shortcode: `end_card="yes|no" end_layout="cell|banner"
end_theme="soft|outline|dark|image" end_image="" end_eyebrow="" end_title=""
end_text="" end_primary="inquiry|link|none" end_primary_text=""
end_primary_url="" end_subject="Custom design"
end_secondary="auto|top|link|none" end_secondary_text=""
end_secondary_url=""`.

## Story reels (1.19)

A new **OM Story Reels** widget (shortcode `[om_reels]`): a row of round
bubbles (or tall reel cards), each a design with a video. Tapping one opens
a full-screen player, stories-style: progress bars, tap right/left (or
arrow keys), hold to pause, swipe sideways for the next, swipe down or
Escape to close, sound button, the design's name, style number and "From"
price, and a "View this design" button. Watched stories get a grey ring;
the next video preloads while one plays. Only designs with a video appear.

Widget: designs (line with optional collection/shape, most viewed, or
hand-picked), count, heading, bubble shape, label (name, shape, carat,
none), show on (all / phones / desktop), alignment, button text, price,
style number, auto-advance, start with sound, longest play time, embed
length; styles for size, spacing, ring colours (and watched), ring
thickness, label and heading, and the player's backdrop and button.

**Label above the stories** (1.45.2): a small line with a play icon over
the bubbles, "Video highlights · Tap to watch" unless changed (empty for
none), so visitors know what the circles are. It's the same label the OM
Catalog widget's heading has, and it follows the row's alignment. The
Wulf kit's shop pages use this widget for their stories, so they show it
too.

Shortcode: `[om_reels source="line|popular|picked" line="engagement-rings"
style="" shape="" styles="" count="8" bubble="circle|card"
label="title|shape|variant|none" show_on="all|mobile|desktop" heading=""
label_above="" show_price="yes" show_style="yes" button_text=""
duration="8" max_length="15" sound="" auto_next="yes"]` (the shortcode
shows no label above unless `label_above` is given).

## Browsing polish (1.19)

- **Compare fly-in** — ticking "Compare" sends the card's photo flying into
  its slot in the compare tray, which "catches" it with a small pop.
- **← Back to results** — on a product page opened from a listing, a slim
  link returns to the same spot with the same filters ("Back to Engagement
  Rings · Oval"). Straight from the listing it uses the browser's own Back
  (exact restore); after wandering through related designs it reopens the
  listing and scrolls to where they were. OM Single Product widget: on/off,
  own text, show filters, colour/typography/spacing; built-in product page:
  Settings > OM Catalog > Built-in product page rows.
- **Slim sticky toolbar** — once the visitor scrolls past the search and
  sort, a frosted bar stays at the top with Filters (opens the bottom sheet
  on phones), Search, the result count, active filters, Sort and Back to
  top. OM Catalog widget > Sticky toolbar: on/off, devices, which parts,
  distance from the top (for sticky site headers); Style: colours, height,
  width, shadow. Shortcode: `sticky_tools="yes|no" sticky_on="all|mobile|desktop"
  sticky_parts="filters,search,count,chips,sort,top"`.

## Earlier catalog counts (1.20)

Replaced by **Insights** in 1.40. The simple daily counts below are still
kept for 120 days and open from Insights > Settings > "Earlier catalog
counts", so the history from before Insights can still be read. They show
what visitors did for the last 7, 30 or 90 days, with the change against
the period before:

- Headline numbers: product views, searches, searches with no results,
  inquiries, reel views and reel taps to the product.
- Daily charts of product views and inquiries (hover for the day's
  number, or "Show as table").
- **Most viewed designs** — with their inquiries and inquiry rate.
- **Searches with no results** — what people look for and don't find,
  with a "Try it" link (ideas for designs to add or words for titles).
- **Top searches**, **designs that get inquiries** (and the subjects
  chosen), **most compared pairs**, and **story reels** (views, taps, tap
  rate).
- **Download CSV**, **Pause counting** and **Reset data**.

Only anonymous counts are kept (no visitor, IP or personal data), in daily
buckets for 120 days.

## Reels: metal colours & "More like this" (1.20)

- **Metal colour dots** in the story player (Yellow / White / Rose): the
  story switches to that metal — its own video where there is one, else
  its photo — the choice carries on to the next stories, and "View this
  design" opens the design in that metal. Widget: Player > Metal colour
  dots (`colors="yes"`).
- **After the last story** the player shows "More like this": 4 more
  designs with prices, **Watch again** and **Browse all** (to your link, or
  the search results page for the line). Widget: After the last story —
  on/off, title, button text and link (`end_screen`, `more_title`,
  `browse_text`, `browse_url`).

## Refined design (1.21)

A calmer, more consistent look — the design approved on the mock-up canvas —
applied across the catalog, product page, related rows, reels, quick view
and compare. It is the new default ("Refined", in Settings > OM Catalog >
Look & feel and in each widget's Page design); Modern and Classic remain.

- **One visual language**: five text sizes (headings in your brand serif,
  Arapey by default; text in Inter), capitals only for eyebrows and
  buttons, one button family (pill / soft / square — *Button shape*),
  your navy (#00111C), text grey (#464646) and your site's gold
  (#F4DC9C fills, #B8925A thin lines), one motion curve.
- **Calm cards**: photo corners have fixed jobs — top-left one badge
  (Popular in gold), top-right the compare tick (on hover on desktop,
  always on phones), bottom-left a small video mark (fades while the
  video plays), bottom-centre Quick view on hover. Extra badges and the
  carat move under the name as one quiet line ("2 ct · Staff pick").
  Photos sit on one tone and white backgrounds blend into it, so the grid
  looks like one photoshoot (*Photo background*).
- **Listing**: pill search and sort, sentence-case counts, filter
  sections in sentence case with **shape tiles** (line drawings) and
  larger metal dots, gold progress line, brand-tone loading cards and a
  friendlier empty state. The catalog heading can show **story reels**
  under it (OM Catalog > Heading > Story reels under the heading).
- **Product page**: large gallery (7/5 split), serif title with a gold
  eyebrow, sentence-case options, larger metal swatches, the promises as
  three tiles, details open with the specifications as a two-column list
  and a clean stone table. Buttons gain a **Gold** style (your site's
  gold button) in the OM Single Product widget.
- **Phones**: a one/two-per-row switch above the grid (remembered), and
  the slim sticky toolbar becomes a floating **Filter · Sort** pill at the
  bottom of the screen.

Settings > OM Catalog > Look & feel: Design, Button shape, Gold (fills and
lines), Photo background and Blend. Each OM widget can override them
(Style > Card Hover, Corners & Spacing / Corners & Spacing).

After updating, regenerate Elementor's CSS once (Elementor > Tools >
Regenerate Files & Data) so the widgets pick up the new styles.

## CRM (GoHighLevel and webhooks)

**Settings › OM Catalog › CRM** sends every lead to your CRM as it comes in:
inquiries from any form (product pages, diamonds, ring builder, the AI
chat's "talk to our team"), visitors who email themselves their saved
designs or ring design, visitors who drop a hint (only the sender; the
person they send it to is never added), and the Wulf Elementor Kit's visit
requests, ring style quiz and newsletter sign-ups. Choose GoHighLevel, a
webhook or both; emails and the Inquiries list carry on as before.

- **GoHighLevel (direct):** paste a Private Integration token (Settings ›
  Private Integrations; scopes View Contacts and Edit Contacts
  (contacts.readonly, contacts.write), View Custom Fields and Edit Custom
  Fields (locations/customFields.readonly, locations/customFields.write),
  and for opportunities Edit Opportunities (opportunities.write)) and your
  Location ID. Each lead creates or updates the contact (matched by email
  or phone, so no duplicates), fills in its **contact fields** (below),
  adds tags, and attaches a note titled after the request ("Book a
  viewing: Hidden Halo Oval Ring 1") with every detail and the visit
  behind it. With a pipeline and stage ID, every inquiry and visit request
  also opens an opportunity named after the design and the customer and
  valued at the price shown (newsletter sign-ups don't).
- **Contact fields (1.43):** so the design, price and page show right on
  the contact, in lists and filters, and in workflows, emails and texts
  (`{{contact.website_design}}`), each lead fills in 15 fields the plugin
  makes in GoHighLevel the first time (or finds, if you made them with the
  same names): Website request, Website design, Website style number,
  Website product line, Website price shown, Website page, Website photo,
  Website options chosen, Website diamond, Website ring builder, Website
  message, Website details, Website came from, Website visits and Website
  designs viewed. They always hold the latest lead's details (the design
  ones only change when a lead is about a design, so a later newsletter
  sign-up doesn't wipe them); every lead keeps its own note. The settings
  show whether the fields are ready, with a **Set up the fields now**
  button, and say exactly which permission to tick if the token can't
  make them. Switch it off to keep the details in the note only.
- **Webhook:** any URL (a GHL *Inbound Webhook* workflow trigger, Zapier,
  Make…) receives the lead as JSON; optionally signed (`X-OM-Signature`).
  Besides the full lead it carries the same details as simple keys named
  like the contact fields (`website_design`, `website_price_shown`,
  `website_page`, `website_came_from`…) and the visit line by line, so a
  GHL workflow's *Create/Update Contact* step can map each one to a field.
- **What a lead carries:** name (first/last), email, phone, subject,
  message, the piece and style number, product line, options chosen, price
  shown, page and photo, diamond, ring builder design, "Help me choose"
  answers, the AI chat, other form fields (for visit requests: the day,
  time, best way to reach them and what they want to talk about), and the
  visit behind it when Insights shows visits behind leads (where they came
  from, visits so far, the pages and designs they looked at, saved,
  compared and searched, and a link to the visit in Insights), plus where
  the visitor first came from (UTM tags, Google/Facebook/Microsoft ad click
  IDs, referring site, landing page; kept 90 days in a first-party cookie,
  only while a CRM is on).
- **Tags:** your own plus *website inquiry*, *saved designs*, *ring design
  saved*, *ring builder*, *diamond inquiry*, *ai assistant*, *book a
  viewing*, *drop a hint*, *visit request*, *ring style quiz* and
  *newsletter sign-up* (for GHL workflows).
- **Reliable:** sent after the visitor's page answers (they never wait),
  retried after 5 min, 30 min, 2 h and 6 h if the CRM doesn't answer, and
  the last deliveries are listed with any error. "Send a test lead" checks
  the setup.

## Changelog

### 1.50.0
- **Chat questions stay readable on hover.** The starter bubble's question
  and its suggested questions kept no text colour of their own on hover,
  focus or tap, so Elementor's Site Settings (Buttons > Hover) or the
  theme turned their text white on a white bubble. They now stay dark on a
  soft cream, and ignore the site's button capitals and letter spacing, as
  the questions inside the chat do.
- **The chat wears your brand.** A theme or kit can give it the shop's mark
  (shown instead of the sparkle on the button, in the chat's header and on
  the ring builder's chat button), name over the chat and button text, with
  the `om_assistant_brand` filter. The Wulf Elementor Kit 1.30 gives the
  logo's diamond W, "Wulf Diamond Jewelers" and "Ask our jeweler". Settings
  > AI assistant > Look > Button icon: Your brand mark, Sparkle or Your
  logo; Name & texts still win when filled in. Without a brand, nothing
  changes.

### 1.49.0
- **Never only an email.** With the Wulf Elementor Kit 1.29, its visit
  requests, quiz matches and newsletter sign-ups are kept under Inquiries
  (with Their visit and an "Open the inquiry" link in Insights) before
  they're emailed. Ring designs from "Email it to me" are kept too, even
  when the email to the visitor fails.
- **Not emailed.** An inquiry, hint, saved list, ring design or kit request
  whose email to the shop failed is marked in the Inquiries list and on
  its screen, with the reason.
- **Email failure notice** for admins: how many emails failed in the last 7
  days, the last error, Send a test email, See inquiries and Dismiss.
- **Inquiry form on cached pages:** its time stamp no longer expires after
  2 days, and a stamp the site can't check any more (its keys changed)
  gets a fresh one and the form sends again by itself. Before, that
  inquiry was dropped while the visitor saw "Thank you".

### 1.48.0
- **Insights: calls and texts in Results.** A new tile in the Results band
  (and on the WordPress Dashboard box, with visit requests): taps on the
  phone number or the Text button, with the split under it. Text taps are
  recorded for the first time, with where on the site they were tapped,
  under Actions. "Contact taps" is now **Directions and emails**.
- **Insights: one-page summary.** **Report** offers a one-page PDF (results,
  the top findings with next steps, where leads came from, the most viewed
  designs) beside the full report.
- **Insights: no false alarms.** What stood out checks every change against
  chance before saying it, needs enough leads or visits to tell, allows
  for the number of sources checked at once, and says "Too early to
  compare" when the period compared with wasn't fully recorded. On flat
  test data with no real change, a 7-day period used to show "Leads
  changed" 7 times in 10 and "a source moved" 4 times in 10; now about 1
  in 8 (mostly marked "could still be chance") and none.
- **Insights: real drops come first.** New findings for visit requests and
  for calls and texts; a source that drops is ranked by about how many
  leads it cost, with what to check for that source; a source that stopped
  sending visits is named.
- **Insights: sources.** Visits from phone apps (Gmail, Outlook, the Google
  app, Google Maps, Facebook, Instagram, ChatGPT and others) count under
  the right source instead of "Other websites" or "Direct". A Facebook or
  Instagram visit with no website (their own browser, or an `fbclid`) is
  Social media. Visits recorded before are sorted again once on update.
- **Insights: engagement.** A tap to call, text, email or get directions
  makes a visit engaged.
- **Insights: counting fixes.** Every lead counts only the visits up to
  the one they got in touch on; designs are counted in full (they stopped
  at 400); leads with no visit recorded show as **Not linked to a visit**
  so sources add up; pages shown again with Back or Forward count; the
  kit's Welcome back bar and brand films are recorded.
- **Insights: SimplyBook bookings** count as visit requests through
  SimplyBook's API callback (Insights > Settings > Bookings in the
  calendar).
- **Insights: places by name.** Calls, texts and buttons tapped in the
  kit's widgets show the widget's name ("Call to action", "Film chapters")
  instead of its short key.
- Tables in half-width cards fit at 1280 pixels: number headings may wrap.
- Database version 4: a `contacts` column on visits and an index on
  actions, added on update.

### 1.47.0
- **Proof under the product page buttons**: a new `om_product_assurance`
  filter lets other plugins add a line right under the buttons (or after
  the price when there are none). The Wulf kit 1.25 shows the shop's
  Google rating, a short review about that kind of jewelry and its
  promises there; when the "Trust line under the price" is filled in, the
  kit leaves its promises out so they aren't said twice.

### 1.46.1
- **Accessibility**: product pages and the "Drop a hint" page now have a
  "main" region around their content, so screen readers can jump to it and
  "Skip to content" lands on it (the `om_main_landmark` filter turns it off
  for a theme that adds its own).
- Product page detail headings (Description, Stone details, Specifications)
  are one level higher, so headings no longer skip a level. They look the
  same in all three designs.
- The row of pictures and videos on a product page is a labelled group.
- Catalog pages have a hidden "Designs" heading before the results, for
  screen readers; the grid doesn't move.

### 1.46.0
- **One saved list for the whole site**: the Wulf kit's hearts and quiz now
  save into the catalog's Saved designs (needs kit 1.16). Its header button
  opens the Saved panel; the floating Saved button stays away when a page
  has a button like that.
- **Book to see them in person** in the Saved panel when the Wulf kit's
  booking window is on the site.
- Designs saved from the kit keep their **gold colour**, shown in the panel,
  "Email me my list", your copy of it, and "Drop a hint". Your copy also
  lists each design's size or carat when it has one.
- **"Ask our jeweller"** shows only on the pages set under AI assistant >
  Show on. Pages that load the catalog's script for another plugin (the kit
  loads it on every page for the saved list) don't count as catalog pages.
- `window.omSaved` and the `om:saved` event, for other plugins.

### 1.45.3
- **"Select this setting" on rebuilt sites**: the button (and "Select this
  diamond") only showed once Settings › Ring Builder › Builder page named a
  published page, so the Wulf kit redesign, whose "Ring Builder" page is
  new, had none. The setting now starts on **Find it automatically** and
  uses the published page with the ring builder on it (/ring-builder/
  first); a chosen page that isn't published any more falls back the same
  way. **Off** turns the builder buttons off on purpose.
- Admins see a short note where the button would be when no published page
  has the ring builder.

### 1.45.2
- **OM Story Reels widget: "Label above the stories"**, the same small
  "Video highlights · Tap to watch" line the catalog heading has. The
  Wulf kit's shop pages put their stories in this widget (not the catalog
  heading), which is why the label didn't show there; it now shows by
  default. Change or clear it under Bubbles › Label above the stories.
- Story Reels set to **Center**: on phones, where the row is wider than
  the screen, it now starts at the first story instead of cutting the
  first ones off.

### 1.45.1
- **Product pages: the booking box moved up**, right under the buttons
  (such as "Call us"), before the metal and size choices. Settings > OM
  Catalog > Inquiries > **On product pages** puts it back at the end of
  the details; an OM Single Product widget can choose too (**Where on the
  page**).
- **The calendar opens faster**: the connections to SimplyBook open while
  the page loads, and its script is fetched once the page has loaded (or
  when a visitor reaches for a "Book" toggle, tab or link), so opening a
  calendar only waits for SimplyBook's own page. In tests with realistic
  delays it was ready about 0.8 seconds sooner.

### 1.45.0
- **Inquiry form or booking calendar**: every place that offers to get in
  touch can show the inquiry form, your SimplyBook.me calendar, or both as
  two tabs ("Book an appointment" and "Send a message"). One choice for
  the whole site, and place by place: product pages, the ring builder's
  last step, the "Ask us" pop-ups, diamond search, hint pages, the AI
  assistant and the Wulf kit's booking panel and visit form. Everything
  starts on the form, so nothing changes until you switch.
- The calendar from the old site's code is set up already; paste new
  widget code, or just a SimplyBook address, to change it. Only its
  settings are used, never the pasted text, and saving never resends the
  code (some firewalls block that).
- The calendar loads only when it comes into view, and offers the booking
  page if it can't load. The tabs work with a keyboard and screen readers,
  and links can open a tab (`#om-inquiry?tab=book`).
- An OM Single Product widget can choose for its own page; new shortcode
  `[om_booking_calendar]`; new event `booking_calendar_view`.

### 1.44.1
- **Updating keeps everything**: replacing the plugin with a new version
  keeps every visit, lead, inquiry and setting. The Insights tables only
  gain the four page speed columns: they are added once, by one request,
  and checked before Insights uses them. If the database refuses (rare
  hosting limits), visits are still recorded as before, without page
  speed, and the update is tried again an hour later.

### 1.44.0
- **Insights 2.0, results first.** The overview opens with a dark results
  band: leads, visit requests, lead rate and the **value asked about**
  (the listed prices of the designs people asked about), what the leads
  were (visit requests, inquiries and hints, designs emailed, sign-ups),
  and this month's pace against your **goals**. Six tiles follow for
  visits and interest, including engaged visits and contact taps.
- **What stood out**: ranked findings in plain words, each with a next
  step and a link (sources that moved, the best and weakest source,
  phones against computers, slow pages, missing pages, searches that found
  nothing, popular designs nobody asks about, rising designs, buyers who
  take their time, returning visitors, the busiest time, goals).
- **Compare with the same time last year** (jewellery is seasonal), or the
  period just before.
- **Where leads began**: the source of each lead's first visit, the visit
  they got in touch on and the visits that helped; how long leads took and
  how many visits.
- New **Audience** tab (new and returning compared, how often people come,
  devices with lead rates, browsers, systems, places, languages, busy
  hours).
- **Page speed** (Core Web Vitals from visitors' browsers, phones and
  computers) and **missing pages** (with where people came from) under
  Pages; **interest by price**, rising and cooling designs and designs
  viewed together under Designs; funnels against the period compared
  with; sources with engaged share and lead-rate bars.
- The chart: a menu for any measure (value in dollars too); unfinished
  days, weeks and months are a hollow "so far" point, not a fall.
- A new look in the Wulf brand: ivory, ink and gold, Fraunces and Manrope,
  the kit's colours.
- **PDF report**: results first on the cover, a "What stood out" part with
  next steps, Leads second, the new parts (audience, speed, missing pages,
  prices, rising designs), the lead list and day by day at the back, and
  the comparison chosen (period before or last year).
- Settings: monthly goals for leads and visit requests; measure page speed
  on or off.

### 1.43.0
- **GoHighLevel contact fields**: each lead now fills in fields on the
  contact (Website design, Website style number, Website price shown,
  Website page, Website photo, Website options chosen, Website diamond,
  Website message, Website came from, Website designs viewed and more, 15
  in all), so the details show on the contact itself and can be used in
  workflows, lists, emails and texts. The plugin makes the fields in
  GoHighLevel the first time (or uses ones with the same names), and the
  CRM settings show whether they're ready, with a **Set up the fields
  now** button. Needs the token's View and Edit Custom Fields scopes.
- The note on the contact has a title ("Book a viewing: Hidden Halo Oval
  Ring 1"), the product line and photo, and the visit behind the lead
  (where they came from, visits so far, what they looked at, saved and
  searched, and a link to it in Insights), like the shop's emails.
- Webhooks also get the details as simple keys named like the fields
  (`website_design`, `website_price_shown`, `website_page`…), ready to map
  in a GoHighLevel workflow, and the visit line by line.
- Visit requests from the Wulf Elementor Kit 1.10.1 arrive with the day,
  time and best way to reach them as their own details, and their note as
  the message; newsletter sign-ups no longer open an opportunity; new tags
  *visit request*, *ring style quiz* and *newsletter sign-up*.
- If GoHighLevel refuses a field (deleted there, for example), the contact
  is still saved and the fields are looked up again with the next lead.

### 1.42.0
- **PDF report**: a **Report** button next to the period menu in Insights
  downloads a branded PDF of every section for the period and filters
  chosen: a cover with the headline numbers, what stood out and the
  contents (each line links to its page), charts of visits and leads, every
  list with its numbers, every lead and a day by day (or hour, week or
  month) table, all compared with the period before. Bookmarks for each
  part show in the PDF viewer.
- The names of people who got in touch can be left out (the choice is
  remembered).
- Made on the site in a few seconds with the brand colours from the Wulf
  Elementor Kit and its Fraunces and Manrope fonts; nothing is sent
  anywhere. Bundles tFPDF 1.34 (LGPL 2.1) and the two fonts (SIL Open Font
  License) in `lib/`.
- Insights: blue buttons are a little deeper, so their white text is easier
  to read.

### 1.41.0
- **Insights redesign**: a cleaner, app-like dashboard. Sections, periods,
  filters and visits load in place (no page reloads); Back, Forward and
  bookmarks keep working.
- **Click to filter**: any source, website, campaign, page, design, search,
  place, device, browser or system narrows every section to those visits.
  Filters show at the top and come off with ×.
- **Headline numbers** choose what the chart shows, each with a small trend
  line. The chart compares with the period before (grey line, **Compare**
  switch), gives exact numbers on hover or with the arrow keys, shows today
  dashed while it is still going, and switches between hours, days, weeks
  and months.
- **Period menu** with your own dates and one-key shortcuts (T, Y, W, M, Q,
  L).
- **Visits open in a side panel**; Journeys adds more visits in place.
- **Settings save instantly** (no Save button); deleting all data asks you
  to type DELETE.
- Live updates every 10 seconds, the count at the top every 30 seconds.
- "Visitors & sources" is now **Sources** and "Visitor journeys" is
  **Journeys**; old Insights links still open the right section.
- Works without JavaScript, by keyboard and with screen readers, and fits
  phones.

### 1.40.0
- **Insights**: the site's own visitor analytics, in the WordPress menu.
  Overview, visitors and sources, pages, designs, searches, actions,
  funnels, visitor journeys (every visit, step by step), leads and a live
  view, for any period, with the change against the period before. Charts
  with tooltips and tables, sortable lists with Find and Show all, CSV
  downloads.
- What it records: page views with time on the page and how far people
  scroll, designs viewed (with price), saved, compared and shared, options
  picked, searches and filters, the ring builder, diamond tools, ring
  designer, assistant, quiz, booking window, Drop a hint, story reels,
  button clicks, calls (which number), directions and links to other
  sites, and every lead from this plugin and the Wulf Elementor Kit.
- Where visits come from: search, Google Maps & Business Profile, direct,
  social media, paid ads (click IDs and paid campaign tags), email, AI
  assistants and other websites, plus campaigns (utm links).
- The visit behind each lead: a **Their visit** box on each inquiry, a
  **Came from** column in the inquiries list, and a **Their visit** summary
  at the end of the shop's inquiry, hint, saved list and ring design emails
  (and the Wulf Kit 1.9.3's visit request, quiz and newsletter emails).
- Privacy: two first-party cookies with random IDs, no IP addresses, nothing
  sent elsewhere; staff, bots and Do Not Track / Global Privacy Control left
  out; kept 13 months by default (3 to 37), CSV download and delete all.
- Insights replaces Dashboard > Catalog insights. Its daily counts stay
  available under Insights > Settings > "Earlier catalog counts", and the
  old address opens Insights. The WordPress Dashboard box now shows the
  last 7 days from Insights.
- The visit script sends what it has collected when a form is sent, so the
  emails tell the whole visit.
- New filters: `om_email_details` and `om_insights_rate_limit`.

### 1.39.1
- Brand colours and fonts: when the catalog follows the Elementor kit, the
  kit's starting values (blue #6EC1E4, green #61CE70, grey #7A7A7A and
  Roboto) no longer count as your brand. The catalog's own colours and fonts
  are used instead, or the Wulf Elementor Kit's. This fixes the light blue
  and Roboto in the "Drop a hint" pop-up (and anywhere else they showed) on
  sites whose Elementor global colours were never set.
- New `om_catalog_style_tokens` filter for themes and plugins to supply the
  catalog's colours and fonts.
- The catalog's own Arapey and Inter fonts load whenever they are in use.

### 1.39.0
- **Drop a hint**: a link on product pages, the quick view and the Saved
  panel sends one or more designs to a partner or friend, with a note,
  ring size and the option to leave prices out. They get a branded email
  and a private page (photos, note, Book a viewing, Ask about it) that
  works for a year and is hidden from search engines.
- You get a copy (also under Inquiries) and a short email the first time
  the hint is opened. Inquiries sent from the hint page say "From a hint".
- Only the sender goes to the CRM (new event and tag *drop a hint*); the
  person they send it to is never added.
- Settings > Look & feel > Drop a hint: on/off, link text and the promise
  line on the hint page. Four new emails under Emails. The OM Single
  Product widget has a "Drop a hint" link switch. Insights counts hints
  sent and opened.
- Spam protection: catalog designs only, no web links in notes or names,
  hourly and daily limits, plus the inquiry form's hidden checks.
- `window.omHint.open()` for other plugins (the Wulf Elementor Kit 1.9.1
  uses it on the Spotlight ring and the ring style quiz).
- Phones: the sideways scrolling filter pills no longer push the page a few
  pixels wider when the theme's side margin is under 16px.

### 1.38.0
- "Ask our jeweller" can show on the homepage as well as the catalog
  (Settings > AI assistant > Show on > "Catalog pages and the homepage").
- Starter question on the homepage: a small bubble beside the button after
  a few seconds (default 8) or a third of the way down the page, once per
  visit, with two suggested questions that open the chat and ask. It stays
  away while the chat or a booking window is open. Its words and delay are
  in the same settings; empty turns it off.
- The button moves up above any bar marked `data-om-ai-lift` (the Wulf Kit
  phone bar and the booking bar on computers).
- New filters for themes and plugins: `om_assistant_show_here` and
  `om_assistant_is_home`.

### 1.37.0
- Settings save without reloading the page: "Save Settings" (or Ctrl/⌘+S)
  saves in the background through WordPress's own settings save — same
  checks, same cleaning of values — and you stay where you were. The
  status at the top, the "saved" lines for secrets, password hints, the
  CRM delivery log and the fields themselves (as stored) update in place;
  the bar confirms "All changes saved ✓". If anything unexpected happens,
  it saves the usual way, so nothing is lost.

### 1.36.0
- CRM: every lead (inquiries from all forms, emailed saved lists and ring
  designs) goes to GoHighLevel directly (contact upsert, tags, a detailed
  note, optional opportunity) and/or any webhook, with the visitor's
  first-touch source (UTM, ad click IDs, referrer). Sent without slowing
  the visitor, retried on failure, logged; "Send a test lead" in Settings.

### 1.35.0
- AI assistant, branded: your logo in the chat header (and optionally the
  button), your main and accent colours, and your own line under its name.
- AI assistant answers from more of your data (each can be switched off):
  details of the designs it suggests from Overnight Mountings, live
  diamonds (shown as cards linked to the ring builder), your website's own
  pages and posts (with a link to the page it used), and the prices your
  site shows while prices are on.

### 1.34.6
- Connection: no longer shows the server's own (often internal, e.g.
  127.0.0.1) address; it points to Tools › Find my server's IP, which
  shows the public address Overnight Mountings' firewall sees.

### 1.34.5
- Catalog header: a small label above the story reels ("Video highlights
  · Tap to watch", with a play icon) so visitors know what the circles
  are. Change or clear it in the OM Catalog widget › heading ›
  **Label above the stories**; it follows the heading's alignment and
  only shows when there are stories.

### 1.34.4
- Settings › Tools › **Find my server's IP**: shows the address this
  website's server uses to reach other servers (what Overnight
  Mountings' firewall sees), looked up on request. "Test connection"
  also shows it when sign-in is blocked (HTTP 403).

### 1.34.3
- Fix: Settings didn't save (any tab, including the API credentials)
  while the AI assistant's "Per visitor … messages an hour" limit was 0
  (the default since 1.32) — the browser rejected 0 and silently blocked
  the form. 0 (no limit) is accepted now, and if a field on another tab
  ever blocks saving, that tab opens and points at it.
- Connection: shows that the Client Secret is saved (length and last 4
  characters) — the box itself stays empty on purpose — and this
  server's address for Overnight Mountings' allow-list.
- Sign-in failures from a firewall include its name, request ID (e.g.
  Cloudflare Ray ID), page title and time, for Overnight Mountings'
  support. Requests identify the plugin and site in OM's logs.

### 1.34.2
- Sign-in problems explained: instead of "Unknown auth error", the
  message gives Overnight Mountings' HTTP status, their own reason and
  the usual cause (credentials rejected, server blocked by their
  firewall, their service down, rate limit).
- The catalog stays up when Overnight Mountings can't be reached:
  listings and product pages fall back to their last good copy (kept a
  week, and kept by "Clear cache"). Live prices and diamonds still need
  the API.
- API status: Settings › Tools shows whether calls are working, the last
  successful call and the last problem; the status at the top of
  Settings and a wp-admin notice (admins only) flag failures.

### 1.34.1
- Phones: the slim Filters/Search/Sort bar (and the chat, Saved and
  compare buttons) no longer cover the site's menu. While a menu or
  pop-up is open they step aside, and come back when it closes.
  Elementor menus and pop-ups and most themes are detected
  automatically; for anything else, Settings › Look & feel › **Your
  site's menu** takes a CSS selector for the open menu.

### 1.34.0
- Ring builder: the AI assistant's button docks into the "Your ring" bar;
  no bar on the review step; "Pick a setting/diamond below" hint while a
  step isn't done; no floating Saved button over the bar.
- AI assistant: the floating button shrinks to its icon after scrolling
  (setting).
- Review: stone and metal named on the photo; "Ask our jeweller" next to
  Book a viewing; request form without the topic choices (subject "Ring
  request"), ring size and engraving before the message, reassuring line
  under the button; a thank-you panel with the ring and next steps after
  sending.
- Diamonds: row photos when available; Compare up to 4 side by side.
- Product page: "Select this setting" first under the price (option).
- Setting step: filter rows left-aligned with the step; the page heading
  steps back on steps; "Popular" badges limited to the 6 most viewed.
- Helper lines ("Help me choose", "Continue without a diamond") look like
  links.
- New email: Ring design — gentle follow-up (off by default).

### 1.33.0
- **Continue without a diamond** in the ring builder: a setting can be
  requested on its own; the request says the diamond is to be chosen with
  you or is the customer's own. On by default, with its own switch and text
  in the OM Ring Builder widget.
- **White photo backgrounds everywhere**: Photo background now defaults to
  white, and sites still on the old beige default (#F3EFE8) are moved to
  white once. "You might also like" and the builder's setting grid follow
  it; builder panels keep a light tint so they stay visible.

### 1.32.0
- **Emails & notifications**: a new Emails section — every email (new
  inquiry, customer confirmation, saved designs and ring design, with your
  copies) gets on/off, To/Cc/Bcc, subject, heading, a visual editor body,
  button text and click-to-insert placeholders, with live Preview and Send a
  test; plus one email design (logo, colours, sender, footer).
- **AI assistant answers properly**: it now answers questions fully from
  jewellery knowledge and only suggests the team for prices, orders,
  viewings or a person. Limits are off by default. When the AI can't answer,
  admins see the actual reason in the chat and in Settings, and OpenRouter's
  current free models are looked up automatically.
- **Chat button position**: bottom right or left, with your own distances; it
  only moves up while something is actually underneath it.

### 1.31.0
- **AI assistant "Ask our jeweller"** (off by default): friendly, suggestive
  chat with real design cards, OpenRouter (free models) / Gemini / Claude,
  shop facts, hand-over to the inquiry form with the chat attached, limits,
  graceful fallback, a test button, and an "AI assistant" settings section.

### 1.30.0
- **New settings screen**: a left-hand menu of sections (Overview,
  Connection & cache, Pricing, Product pages, Look & feel, Ring builder &
  diamonds, Inquiries, Search & analytics, Tools), clean cards, switches
  instead of tick boxes, live colour swatches, a status overview (connection,
  prices, ring builder, inquiries this week, analytics), a settings search,
  and a save bar that appears when something changed (and warns before
  leaving). Saving returns to the same section. Every setting is unchanged.

### 1.29.1
- **Carat switch without a page reload**: the carat pills load the other
  carat in place (fetched in the background as soon as a pill is hovered
  or touched), with a cross-fade, keeping the chosen metal and colour and
  the scroll position; the address, tab title and Back button follow. In
  quick view, the pop-up loads that carat.

### 1.29.0
- **Analytics events** for GA4, Google Tag Manager and the Meta pixel
  (whatever the site already has): views, saves, compare, share, search,
  leads (inquiries and emailed lists/designs), ring builder steps, Help me
  choose, Book a viewing and true size. Settings > OM Catalog > Analytics;
  `?om_debug_events=1` for admins; `om:track` for developers.

### 1.28.2
- **Saved lists last on iPhones too**: a backup cookie set by your site
  (`om_saved`, style numbers only, up to a year) restores the list when
  Safari / iPhone browsers have wiped the page's storage after 7 days
  without a visit. Clearing the list removes it.

### 1.28.1
- **Sticky site headers**: the slim toolbar, the sticky filter sidebar and
  the sticky product gallery now sit below a header that stays on screen
  (measured automatically, including headers that shrink or hide on
  scroll), instead of under it. The widget's "Distance from the top" still
  wins when set.
- **Finding saved designs**: a heart with the count in the slim toolbar and
  the phone pill, and a floating Saved button on pages without your own
  (Settings > OM Catalog > Look & feel > Saved designs).

### 1.28.0
- **Saved designs**: hearts on cards, product pages and the quick view; a
  Saved panel with Compare, Share list and Email me my list (a copy lands
  in Inquiries). OM Saved Designs header widget, `[om_saved_button]`, and
  `#om-saved` links. Insights: Most saved. Site-wide and per-widget
  switches.

### 1.27.0
- **Help me choose answers go with requests**: budget or size, shape,
  priority, lab/natural and which suggestion was chosen are added to the
  inquiry email and the Inquiries list. The visitor sees a note saying
  so. Widget switch: "Send the answers with
  requests".

### 1.26.0
- **Help me choose** in the ring builder: budget or size, priority and
  origin → the three best matching diamonds with plain-words reasons.
  Budget mode only while prices show; otherwise it guides by size and
  says "Price on request". Respects the chosen setting's carat range.
  Start-screen card and diamond-step link, all editable in the widget.
- **True size switches** in Settings > OM Catalog > Ring Builder: turn
  "See true size" off site-wide, or keep it and hide the screen check and
  the "About real size" note.

### 1.25.0
- **True size**: "See true size" on every diamond (diamond search and the
  ring builder review) shows the stone at its real size on a finger, from
  its measurements. It compares typical 0.5 / 1 / 1.5 / 2 ct stones of the
  same shape, with a 3× close-up and a ring-size choice. A one-time screen
  check (match a bank card) makes it exact on each device; until then it
  is labelled "about real size". All ten shapes are drawn, and it works on
  phones.

### 1.24.0
- Guided ring builder: a new start screen, "Step N of 3" titles with
  guidance and a progress line, and "Choose this setting" on every card.
  Diamond-first shows only settings in the stone's shape.
- The diamond step opens on the setting's shape and carat range, and the
  setting's head size is matched to the chosen stone automatically.
- "Your ring" bar on every step (chosen setting and diamond, the total when
  prices show, "Questions? Ask us" and the next step), floating on phones.
- Review: metal and colour choices, "Book a viewing" (form or link), ring
  size and engraving fields, "Share this design", "Email it to me" and an
  optional "What happens next" list.
- "Continue your ring" for returning visitors.
- All builder texts and options are editable in the widget.

### 1.23.1
- The site's global text styles no longer change the plugin's text.
  Elementor Site Settings › Typography (and theme rules like
  ".entry-content p") used to override the plugin's type: card titles came
  out at the site's H3 size (38px in the ring builder), and the
  count, Compare title and form text shifted. Inside the plugin's blocks,
  text now keeps the plugin's fonts, sizes and spacing, and every widget
  Style control still wins.
- Ring builder: the "Choose a setting" step can look exactly like your
  catalog. The new **"Choose a setting" looks like** option copies an OM
  Product Catalog widget's design, cards, fonts, filters and Style
  settings (automatically the newest catalog page showing engagement
  rings, a page you pick, or the builder's own look). Edit the catalog
  widget and the builder follows.

### 1.23.0
- Quick view: step through the designs without closing it. There are
  previous/next arrows with "3 of 12", the left/right arrow keys, and a
  sideways swipe on the details on phones. The current design stays on
  screen until the next one arrives.
- Shareable links:
  - The quick view has a **Share** button (the phone's share sheet, or
    copy on desktop). While it is open, the address is
    `…?om_qv=engagement-rings/85121-2`, and opening that link shows the
    same pop-up.
  - Compare has **Share link**
    (`…?om_compare=engagement-rings/85121-2,engagement-rings/85275-1`),
    which opens the same comparison for whoever receives it, photos and
    tray included.
- Undo: removing a filter chip or clearing all filters shows "Removed
  Oval · Undo" / "Filters cleared · Undo" for six seconds (it stays while
  hovered or focused). Clearing the compare list can be undone too.

### 1.22.4
- Compare pop-up header redesigned: a small "Compare" eyebrow and a
  title that counts the designs ("3 designs side by side") replace the
  oversized heading the site's global H2 style produced. The header stays
  in view while the table scrolls.
- **Highlight differences**: tints the rows where the designs differ,
  with a gold mark by the label. The choice is remembered.
- **Clear all** in the header empties the comparison and closes it.

### 1.22.3
- Layout no longer shifts under Elementor's global paragraph and heading
  spacing (Site Settings › Typography). That setting outranked the
  plugin's own spacing, so the result count sat above the filter chips
  and sort, and card lines, form rows, size guide and diamond details
  drifted apart. Widget Style controls still take precedence.

### 1.22.2
- The quick view now uses the product page's price text and buttons. When
  product pages use an Elementor layout (Settings › OM Catalog), the
  pop-up takes the price fallback, buttons (with their show-when rules,
  icons and Style-tab colours), trust line, option style and design from
  that layout's OM Single Product widget, so the listing no longer shows
  plain "Call for pricing" text while the page shows a button.
- Buttons that open the inquiry form (`#om-inquiry?subject=…`) take the
  visitor from the pop-up to the product page with the form open and the
  subject chosen. Arriving on any page with that link opens the form.
- No empty price strip when the buttons stand in for the price.

### 1.22.1
- Quick view: new **Pop-up thumbnails** setting, with the thumbnails beside
  the photo, under it, or hidden. Under the photo, the photo column
  narrows so the details column gets more room.
- Quick view: new **Photo column width** slider (Style › Quick View Pop-up,
  per device).

### 1.22.0
- Filter sidebar redesign: each group opens and closes from its heading
  (remembered while browsing), and a closed group shows its pick. Rows
  are taller with a clear marker and a tinted pick, and sub-categories sit
  on a guide line. "Show all (22)" is now "Show 16 more" / "Show fewer".
- Shape tiles and metal swatches in every design (Refined, Modern and
  Classic), each switchable back to a list.
- New **Filter groups** list in the catalog widget: drag to reorder the
  filters (sidebar, top bar and dropdowns), move a single collection group,
  rename headings, start groups closed, or hide a filter. Shortcode:
  `filter_order`, `filter_hide`, `filter_collapsed`, `filter_labels`.
- A sticky sidebar taller than the screen now scrolls on its own.

### 1.21.1
- Card video label keeps its own colour on hover (themes that turn links
  white made it invisible).
- No underline under the design name on hover ("Lift" now only rises).
- The hover video preview fills the photo box in the box's colour.
- Refined: the video mark's play icon is centred in every badge style;
  on framed (boxed) cards the badge and compare tick sit on the photo's
  corners.

### 1.21.0
- New default "Refined" design (catalog, product page, rows, reels,
  quick view, compare): type scale, one button family with a Button
  shape setting, brand gold accents, photo tone with background blend,
  corner rule for card overlays, quiet sub-line under card names, shape
  tiles in filters, pill search/sort, open details with a two-column
  specifications list, promise tiles, gold button style, phone grid-size
  switch and floating Filter · Sort pill, reels under the catalog heading.
- Look & feel settings: Design, Button shape, Gold (fills/lines), Photo
  background + blend; per-widget overrides.
- The carat line switch now works through a CSS variable (so layouts can
  move it); product details default to open sections.

### 1.20.0
- Catalog insights dashboard (views, searches, no-result searches,
  inquiries and subjects, compares and pairs, reel views and taps;
  charts, tables, CSV, pause/reset, Dashboard summary box). Counts only.
- Story reels: metal colour dots (video/photo per metal, carried to the
  product page) and a "More like this" end screen with Watch again and
  Browse all.

### 1.19.0
- New OM Story Reels widget / [om_reels]: video stories of designs with a
  full-screen player (progress, tap/swipe/keys, hold to pause, sound,
  price, CTA, watched rings, preloading), fully configurable.
- Compare fly-in animation into the compare tray.
- "← Back to results" link on product pages with exact return
  (widget + built-in page setting).
- Slim sticky catalog toolbar (filters, search, count, chips, sort, top)
  with widget controls.

### 1.18.0
- End-of-results card after the last design (numbers, Show more,
  infinite scroll): inquiry pop-up or link, smart "See all designs" /
  "Back to top", grid card or banner, four looks, full widget controls.
- Inquiries without a piece get a clean subject ("Custom design — Sam")
  and record the listing page they came from.
- Inquiry form without a heading no longer prints an empty heading.

### 1.17.0
- Quiet page intro for catalog pages: heading, filters/toolbar and cards
  ease in one after another (rise, fade, blur, zoom); first visit / once
  per visit / always; optional page H1; never for reduced motion; no
  flash (starts before first paint); filtering never replays it.
- Optional catalog heading (eyebrow, {line} title, rule, text) with full
  style controls.
- All intro and heading settings live in the OM Catalog widget.

### 1.16.0
- "Recently viewed" photo strip in the search panel (empty box and
  no-results), with prices, keyboard support and a Clear link; count set
  per widget / shortcode (suggest_viewed).
- Search panel semantics: a dialog holding its listbox whenever it
  contains buttons (starters, recently viewed), so screen readers get a
  valid structure.

### 1.15.0
- "Complete the set" row: matching bands on ring pages (rings on band
  pages) from listed pairs, design family, style and colour, then most
  viewed; photos and links follow the metal picked; "Set from" price.
- "Ask about this set": the paired design travels into the inquiry form
  and the email (both pieces, photos, links; {pair} subject token);
  shown in the Inquiries list.
- "Bridal set" added to the default inquiry subjects.

### 1.14.0
- Photo viewer zoom: double-click/tap, wheel, pinch, drag to pan, keys and
  buttons.
- Card badges are quick-filter links (shape → filter, Popular → Most
  viewed).
- Pagination styles: Show more button and infinite scroll, with position
  remembered in the URL.
- Compare tray (up to 4 designs, persists across pages) and comparison
  table.
- "Most viewed" sort with privacy-light view counting; automatic Popular
  badges.
- Cross-page view transitions (photo carries over into the product page).
- Accessibility pass: live announcements, Escape for the filter sheet,
  aria-selected suggestions, labelled dialogs, darker secondary text
  (#6e6e6e), readable photo labels, larger copy-style button.

### 1.13.0
- Catalog pages "Modern" design (default; widget > Page design): framed
  filter sidebar with tinted rows, sentence-case pills that scroll on
  phones, tidy toolbar, framed card photos with glassy badges, staggered
  card entrance, "You've viewed 9 of 40" progress with pill pagination,
  and on phones a bottom-sheet filter panel (stays open while filtering,
  Show results button, tap outside to close).
- Inquiry subjects: predefined choices, subject-line template, button
  preselect via #om-inquiry?subject=…, widget overrides.
- Corner defaults per design: Modern uses soft corners unless a radius is
  set in the widget or Settings.

### 1.12.0
- Photos follow the metal colour for designs whose colours are separate
  style numbers at Overnight Mountings (colour variants are looked up once
  and cached); more file-name patterns recognised (14KY, W1, 2Y…). Admins
  see a note under the gallery when a design's photos can't be matched,
  with the image and variant names OM sends. Carat links no longer repeat.
- Related carousel: hovered cards are no longer cut off at the top.
- Card hover, lift distance, photo shadow (soft / stronger / none), corner
  radii and spacing are now set per widget (Style > Card Hover, Corners &
  Spacing; Single Product > Corners & Spacing). Settings > OM Catalog only
  holds the site defaults.
- Product page "Modern" design (default; Page design control): framed
  gallery with a photo counter and swipe on phones, price row that animates
  on change, options panel with values on the right, full-width buttons
  with a sliding arrow, card-style details and inquiry, copy-style-number
  button, sections that fade in on scroll. "Classic" keeps the old look.
- Popular searches only learn from searches that found something.
- Overlay cards: price readable on the dark scrim.

### 1.11.0
- Look & feel settings: shared corner radii, spacing scale, card hover
  (lift / zoom / none), trust line under the price, phone text sizes.
- Designed empty and error states with one-click ways out, "Found in"
  other lines and popular searches; retry reloads just the grid.
- Grouped search across a widget's lines or every line; new OM Search
  widget / `[om_search]` for headers with a results page.
- Recent (per visitor) and popular searches on an empty search box;
  optional learning of popular searches.
- Diamond table: 4C badges, lab/origin tags, sticky column headings.
- Fix: listing cards' fade-in no longer blocks hover transforms.

### 1.10.0
- Search suggestions: product photo (default metal colour), carat and style
  number, and a "From $X" starting price that loads right after the list
  (cached, remembered while the visitor keeps typing). Typed words are
  highlighted; a two-line layout on phones. Catalog widget switch:
  "Prices in search suggestions" (shortcode `suggest_prices="no"`).
- The search box's clear button uses the brand colour.

### 1.9.0
- Buttons, links, pills and icon buttons keep their own colours and shape
  on hover and focus under any theme or Elementor kit (no more pink/purple
  flashes on quick view, gallery, thumbnails, close buttons, arrows,
  pagination, filters); unified hover language and focus ring.
- Inquiry emails: HTML with the product photo, title, style number,
  options, price and a link to the exact configuration; style number in
  the subject; details verified against OM's data; customer auto-reply
  with the same card; admin list shows photo, title and style.
- Custom forms also receive `om_image` and a configured `om_url`.

### 1.8.0
- Every quick view and video-badge option is now a widget control, with
  full styling (catalog and related widgets); related rows get quick view.
- Single Product widget: Gallery & Video section (autoplay, sound, full
  screen, watch button text, thumbnail position, zoom, lightbox) and
  Gallery / Video Buttons style sections.
- Photos follow the selected metal colour; colour-filtered listings show
  cards in that colour; carat switches keep the chosen options.
- Catalog widget: Card Price and Search & Sort styles. Diamond widget:
  origin switch, default shape, Filters and Results styles.
- Test connection reports whether photos are told apart by colour.

### 1.7.0
- Product video experience: video-first gallery that autoplays muted on a
  loop, sound toggle, full screen button, "Watch video" button over photos,
  labelled video thumbnail.
- Lightbox plays videos alongside photos.
- Listing and related cards: play badge, hover preview on desktop,
  centre-of-screen preview on phones.
- Quick view opens on the video.
- Reduced-motion / data-saver support; unplayable files fall back to photos.
- New settings: Product videos (video first / photos first); catalog
  widget "Video previews" switch.

### 1.6.1
- Test connection always reports video status (present / empty / no field /
  unrecognised format), shows the plugin version and the product's fields.
- Videos are read from any of videos, video, video_url(s).

### 1.6.0
- Cleaner product page: options as swatches/pills/dropdowns, collapsible
  description / stone details / specifications, sticky gallery.
- Ring size picker (priced via fingerSize) with a size guide pop-up and
  printable sizer.
- Sticky price + CTA bar on phones.
- Quick view pop-up on listing cards; card badges (custom, New, shape).
- Skeleton placeholder cards while filtering; card photos fade in.
- Background cache refresh via WP-Cron.
- Test connection reports product video coverage.

### 1.5.0
- Inquiry form builder: add/remove/reorder fields of ten types, globally in
  Settings or per Single Product widget; server-side validation of required
  fields; optional customer confirmation email.
- OM Related Products widget: card designs, title tag, hover second photo,
  carousel arrows and autoplay, peek, and full styling for section, title,
  cards, image, texts and arrows.

### 1.4.0
- Inquiry form fully customisable in the Single Product widget (texts,
  fields, labels, styling), or replaced by any form shortcode with the
  product details passed into its hidden fields.
- New OM Related Products widget / [om_related]: related designs, recently
  viewed, or hand-picked, as a grid or carousel; also on the built-in
  product page.

### 1.3.0
- Search box with as-you-type suggestions on every catalog grid; Sort by
  dropdown; optional "From $X" starting prices on cards; second product
  photo on card hover.
- Product pages: click-to-open lightbox (keyboard and swipe), hover zoom,
  product videos, schema.org Product data for search engines, "Select this
  setting" (ring builder) and an inquiry form.
- New OM Diamond Search widget / [om_diamonds] and OM Ring Builder widget /
  [om_ring_builder], with a separate diamond markup.
- Inquiries saved in wp-admin and emailed.
- Catalog colours and fonts can follow the Elementor kit (Settings > OM
  Catalog > Style source).
- Responsive pass: diamond rows become cards, builder steps stack, forms
  use 16px inputs on phones (no iOS zoom), thumbnails scroll sideways,
  full-width buttons.

### 1.2.0
- New filter layouts: sidebar (left or right, collapsing to a "Filters"
  button on phones), dropdowns, or the existing top bar. New visitor filters
  for shape and metal colour, a result count and removable filter chips.
- Product page price & buttons rebuilt: buttons can replace "Call for
  pricing", with icons, per-button colours and show rules, positions,
  stacking/alignment and full styling. Buttons no longer pick up theme link
  styles.
- Fixed: collection/filter values containing an apostrophe or "&" were
  corrupted when set in the Elementor widget.
- Fixed: the catalog widget made up to 8 taxonomy API calls on a visitor's
  page view whenever its cache expired; those now only run in wp-admin.
- Fixed: anyone could make the site query OM with arbitrary settings via
  the grid's AJAX endpoint. Grid attributes are now signed, filter values
  are checked against the offered options, and out-of-range pages no longer
  call the API.
- Fixed: WordPress treated product pages as the blog home page (wrong
  signals for themes, Elementor Pro and SEO plugins). Product pages now also
  output a canonical tag, and missing products are marked noindex.
- Fixed: the product layout page was publicly viewable; visitors are now
  redirected to the home page.
- Fixed: price updates failed on pages served from a cache older than
  12–24 hours (expired nonce). The public endpoints no longer depend on one.
- Fixed: new API credentials only took effect after the cached token
  expired; saving them now takes effect immediately.
- Fixed: the client secret could be altered on save and was printed into
  the settings page source.
- Fixed: the shortcode didn't load its CSS/JS outside page content.
- Product lines come from OM's own list when available.
- Visitors see a friendly message instead of raw API/setup errors (admins
  still see the details).
- Identical price quotes are reused for 5 minutes; dropdowns sync to the
  configuration OM actually priced (e.g. Platinum forces White).
- Settings: "Test connection & pricing" and "Clear cache" tools; default
  "no price" text and link for the built-in product page.

### 1.1.0 (tenth pass — price CTA & action buttons)
- The OM Single Product widget gained a "Price & Actions" section: custom
  "Call for pricing" text with an optional link (tel:, mailto:, a page),
  and a repeater of inline action buttons (solid / outline / text-link
  styles) under the price — e.g. Call Us, Book an Appointment. A matching
  "Action Buttons" section in the Style tab covers typography, colors,
  hover, padding and gap. Once a markup is configured, real prices replace
  the placeholder automatically; the buttons stay.

### 1.1.0 (ninth pass — Elementor product page layouts)
- New "OM Single Product" Elementor widget: design the product page
  visually with a real preview product, per-section show/hide toggles and
  style controls. Pick the designed page under Settings > OM Catalog >
  Product Page Layout and all product URLs render through it — live price
  re-quoting and the gallery keep working. HTTP statuses, titles and meta
  tags are unchanged.
- Product page template is also theme-overridable at
  {theme}/om-catalog/single-product.php, and the shared renderer keeps the
  widget and template markup identical.

### 1.1.0 (eighth pass — AJAX filtering, multi-line pages, filter designs)
- Filter pills, the line switcher and pagination now update the grid in
  place via AJAX — no page reload. Links stay real URLs (shareable,
  working without JavaScript), browser back/forward is handled, and a soft
  fade shows while loading.
- Multiple product lines on one page: pick "Additional product lines" in
  the widget and visitors get a line switcher above the grid; each line
  keeps its own Collections picker in the editor. When a line's collections
  are curated, visitors filter within that curated set.
- Four filter designs (Pills, Underline, Buttons, Minimal) plus a new
  Filter Bar section in the Style tab: alignment, typography, colors for
  text/hover/border/active, gap and margins.

### 1.1.0 (seventh pass — visitor filter bar + dropdown fix)
- Fixed the Collections dropdown showing "[object Object]" (Elementor's
  select2 can't render grouped options; the list is now flat with the
  collection name folded into each label).
- New "Category filter bar for visitors" toggle: an "All" pill plus each
  category of the line above the grid, so shoppers filter it themselves.
  Selection carries through pagination, duplicate category names are
  qualified, and an empty result keeps the bar visible.

### 1.1.0 (sixth pass — layout presets)
- New Layout picker on the widget and shortcode (`layout=`): Classic
  (centered under image), Editorial (left-aligned), Boxed (framed card),
  Overlay (title over the photo on a soft scrim). Every layout remains
  fully editable via the Style tab.

### 1.1.0 (fifth pass — collections dropdown)
- The Elementor widget's collection filter is now a grouped multi-select
  populated from the live OM taxonomy per product line (categories and
  subcategories, cached 12 hours), with the free-text filter kept as an
  additive fallback. Saved selections survive API outages.

### 1.1.0 (fourth pass — filtering & curation)
- New filters on the widget and shortcode: center-stone shape, in-stock
  only, "show only these style numbers" (hand-picked showcases, variant
  style numbers supported) and "hide these style numbers".

### 1.1.0 (third pass — Elementor editability)
- The Elementor widget now has full Style-tab controls (110 controls):
  grid, card, image, title, carat line and pagination are all editable
  per widget with live preview, on top of the site-wide defaults.
- New Content options: set filter, responsive columns per device,
  show/hide carat line and pagination, per_page up to the API max of 500.
- Plugin styles and fonts load inside the Elementor editor preview.

### 1.1.0 (second pass — live-data testing + design)
- Style numbers containing "/" (carat variants like `85121-1/2`) get a
  URL-safe slug (`85121-1~2`) — encoded slashes break most servers.
- Verified end-to-end against the live API: token, 1,906-product listing,
  space/ampersand filters ("Hidden Halo", "Clip & Ship"), quotation with
  markup, variant lookups, live price re-quote, pagination (318 pages).
- Design pass matching wulfdiamondjewelers.com: vertical filmstrip gallery
  beside the hero image with active-thumbnail state and cross-fade,
  borderless centered product cards with slow image zoom on hover,
  product-line eyebrow label, style-number meta line, current-variant chip
  highlighted, refined selects with custom chevrons, uppercase letter-spaced
  section labels, Arapey/Inter loaded wherever the catalog renders.

### 1.1.0 (first pass)
- Query parameters are now URL-encoded (filter values with spaces or `&`, e.g.
  "Hidden Halo", "Clip & Ship", previously produced corrupt requests).
- `per_page` is clamped to the API's hard limit of 500.
- Single-product lookups pass `parentsOnly=false`, so variant links
  ("Other Sizes / Carats") resolve instead of showing "Product not found".
- Product pages now send correct HTTP status codes (200 found / 404 not found),
  a real page title, meta description, and OpenGraph tags.
- Pagination fixed on static/Elementor pages via `?om_page=N`.
- Prices are fully suppressed ("Call for pricing") until a markup is configured.
- Product detail responses are cached briefly; quotes remain uncached.
- Auth failures are cached for 5 minutes to avoid hammering OM's auth endpoint.
- 503s from the pricing system are retried once, per the API guide.
- Image entries tolerate both string and object shapes.
- Assets only load on pages that render catalog output.
- Default colors/fonts and CSS synced to the live site design (Arapey/Inter,
  `#00111C`, flat square surfaces).

### 1.0.0
- Initial build.

## A note on Elementor

This plugin does not attempt to generate Elementor's internal page-JSON directly —
that format changes between Elementor versions and isn't meant to be hand-generated
by a plugin; doing so reliably isn't realistic. Instead, the catalog grid is exposed
as a genuine Elementor widget you can drag, drop, and style like any other Elementor
element, which is the standard, supported way plugins integrate with Elementor.

## For developers: stylesheet build

Edit `assets/css/om-catalog.css`, then run `python3 tools/build-css.py`
(from the repository root) to regenerate `assets/css/om-catalog.build.css`,
which is the file the plugin loads. The build raises low-specificity
selectors by `html body` so site-wide typography can't override them;
widget Style controls still take precedence.
