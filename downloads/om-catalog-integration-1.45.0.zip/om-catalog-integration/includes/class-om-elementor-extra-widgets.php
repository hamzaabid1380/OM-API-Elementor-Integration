<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

/**
 * Shared style controls for the diamond search and ring builder widgets:
 * the accent colour of selected chips/steps/buttons and the heading font.
 */
trait OM_Elementor_Common_Style {

	protected function register_common_style( $selector_accent, $selector_heading ) {
		$this->start_controls_section(
			'section_style_common',
			array(
				'label' => __( 'Colors & Fonts', 'om-catalog' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'accent_color',
			array(
				'label'       => __( 'Accent', 'om-catalog' ),
				'type'        => Controls_Manager::COLOR,
				'description' => __( 'Selected filters, steps and main buttons. Defaults to the site colours.', 'om-catalog' ),
				'selectors'   => array(
					'{{WRAPPER}}' => '--om-color-primary: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'text_color',
			array(
				'label'     => __( 'Text', 'om-catalog' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}}' => '--om-color-text: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'heading_typography',
				'label'    => __( 'Headings', 'om-catalog' ),
				'selector' => $selector_heading,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'body_typography',
				'label'    => __( 'Body text', 'om-catalog' ),
				'selector' => $selector_accent,
			)
		);

		$this->end_controls_section();
	}
}

/** "OM Diamond Search" widget: loose-diamond search with filters. */
class OM_Elementor_Diamond_Widget extends Widget_Base {
	use OM_Elementor_Common_Style;

	public function get_name() {
		return 'om_diamond_widget';
	}

	public function get_title() {
		return __( 'OM Diamond Search', 'om-catalog' );
	}

	public function get_icon() {
		return 'eicon-search';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'diamond', 'loose', 'search', 'overnight', 'mountings' );
	}

	public function get_style_depends() {
		return array( 'om-catalog-css', 'om-catalog-fonts' );
	}

	public function get_script_depends() {
		return array( 'om-catalog-js' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array( 'label' => __( 'Diamond Search', 'om-catalog' ) ) );

		$this->add_control(
			'origin',
			array(
				'label'   => __( 'Diamonds', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''        => __( 'Lab-grown and natural (visitor chooses)', 'om-catalog' ),
					'lab'     => __( 'Lab-grown only', 'om-catalog' ),
					'natural' => __( 'Natural only', 'om-catalog' ),
				),
			)
		);

		$this->add_control(
			'shapes',
			array(
				'label'       => __( 'Shapes offered', 'om-catalog' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => array_combine( OM_Diamonds::SHAPES, OM_Diamonds::SHAPES ),
				'default'     => array(),
				'label_block' => true,
				'description' => __( 'Leave empty for all shapes.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'per_page',
			array(
				'label'   => __( 'Diamonds per page', 'om-catalog' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 20,
				'min'     => 5,
				'max'     => 100,
			)
		);

		$this->add_control(
			'default_sort',
			array(
				'label'   => __( 'Default order', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'price-asc',
				'options' => array(
					'price-asc'  => __( 'Price: low to high', 'om-catalog' ),
					'price-desc' => __( 'Price: high to low', 'om-catalog' ),
					'carat-desc' => __( 'Carat: large to small', 'om-catalog' ),
					'new'        => __( 'Newest', 'om-catalog' ),
				),
			)
		);

		$this->add_control(
			'show_origin',
			array(
				'label'     => __( 'Lab-grown / natural switch', 'om-catalog' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array( 'origin' => '' ),
			)
		);

		$this->add_control(
			'default_shape',
			array(
				'label'   => __( 'Shape selected at first', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array( '' => __( 'None (all shapes)', 'om-catalog' ) ) + array_combine( OM_Diamonds::SHAPES, OM_Diamonds::SHAPES ),
			)
		);

		$this->add_control(
			'show_select',
			array(
				'label'       => __( '"Select this diamond" (ring builder)', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => __( 'Needs a ring builder page under Settings > OM Catalog.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'show_inquiry',
			array(
				'label'   => __( '"Ask about this diamond" form', 'om-catalog' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'true_size',
			array(
				'label'       => __( '"See true size"', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => __( 'Shows the stone at its real size on a finger, compared with other carats.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'compare',
			array(
				'label'       => __( '"Compare" diamonds', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => __( 'Visitors tick up to 4 diamonds and see them side by side.', 'om-catalog' ),
			)
		);

		$this->end_controls_section();

		$this->register_common_style( '{{WRAPPER}} .om-diamonds', '{{WRAPPER}} .om-dd-title, {{WRAPPER}} .om-dd-price' );

		$this->start_controls_section( 'section_style_dfilters', array( 'label' => __( 'Filters', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'df_bg', array( 'label' => __( 'Panel background', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-diamond-filters' => 'background-color: {{VALUE}};' ) ) );
		$this->add_control( 'df_label', array( 'label' => __( 'Group labels', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-df-group legend, {{WRAPPER}} .om-df-group > p, {{WRAPPER}} .om-df-group label' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'df_chip_border', array( 'label' => __( 'Shape & grade buttons border', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-df-chip, {{WRAPPER}} .om-df-shape' => 'border-color: {{VALUE}};' ) ) );
		$this->add_control( 'df_chip_active_bg', array( 'label' => __( 'Selected background', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-df-chip.is-checked, {{WRAPPER}} .om-df-shape.is-checked' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ) ) );
		$this->add_control( 'df_chip_active_text', array( 'label' => __( 'Selected text', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-df-chip.is-checked, {{WRAPPER}} .om-df-shape.is-checked' => 'color: {{VALUE}};' ) ) );
		$this->add_control(
			'df_chip_radius',
			array(
				'label'      => __( 'Button corner radius', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-df-chip, {{WRAPPER}} .om-df-shape' => 'border-radius: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section( 'section_style_dresults', array( 'label' => __( 'Results', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'dt_head_color', array( 'label' => __( 'Column headings', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-dt-head' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'dt_row_color', array( 'label' => __( 'Row text', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-dt-row' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'dt_row_border', array( 'label' => __( 'Row dividers', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-diamond, {{WRAPPER}} .om-dt-head' => 'border-color: {{VALUE}};' ) ) );
		$this->add_control( 'dt_row_hover', array( 'label' => __( 'Row hover / open background', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-dt-row:hover, {{WRAPPER}} .om-diamond[open] > .om-dt-row' => 'background-color: {{VALUE}};' ) ) );
		$this->add_control( 'dt_price_color', array( 'label' => __( 'Price', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-dt-price, {{WRAPPER}} .om-dd-price' => 'color: {{VALUE}};' ) ) );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'dt_row_typography',
				'label'    => __( 'Row text', 'om-catalog' ),
				'selector' => '{{WRAPPER}} .om-dt-row',
			)
		);
		$this->add_control( 'dd_btn_bg', array( 'label' => __( 'Main button background', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'separator' => 'before', 'selectors' => array( '{{WRAPPER}} .om-diamonds .om-btn--solid' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ) ) );
		$this->add_control( 'dd_btn_text', array( 'label' => __( 'Main button text', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-diamonds .om-btn--solid' => 'color: {{VALUE}};' ) ) );
		$this->add_control(
			'dd_btn_radius',
			array(
				'label'      => __( 'Button corner radius', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-diamonds .om-btn' => 'border-radius: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo OM_Diamonds::instance()->render( // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the renderer.
			array(
				'origin'       => (string) $s['origin'],
				'shapes'       => implode( ',', (array) $s['shapes'] ),
				'per_page'     => (int) $s['per_page'],
				'default_sort' => (string) $s['default_sort'],
				'show_select'   => (string) $s['show_select'],
				'show_inquiry'  => (string) $s['show_inquiry'],
				'true_size'     => 'yes' === ( $s['true_size'] ?? 'yes' ) ? 'yes' : 'no',
				'compare'       => 'yes' === ( $s['compare'] ?? 'yes' ) ? 'yes' : 'no',
				'show_origin'   => 'yes' === ( $s['show_origin'] ?? 'yes' ) ? 'yes' : 'no',
				'default_shape' => (string) ( $s['default_shape'] ?? '' ),
			),
			OM_Diamonds::request_from_globals()
		);
	}
}

/** "OM Ring Builder" widget: setting + diamond + review. */
class OM_Elementor_Builder_Widget extends Widget_Base {
	use OM_Elementor_Common_Style;

	public function get_name() {
		return 'om_builder_widget';
	}

	public function get_title() {
		return __( 'OM Ring Builder', 'om-catalog' );
	}

	public function get_icon() {
		return 'eicon-product-related';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'ring', 'builder', 'diamond', 'setting', 'engagement' );
	}

	public function get_style_depends() {
		return array( 'om-catalog-css', 'om-catalog-fonts' );
	}

	public function get_script_depends() {
		return array( 'om-catalog-js' );
	}

	/**
	 * The builder's content settings, section by section:
	 * [ key, type, label, extra args ]. Defaults come from
	 * OM_Ring_Builder::defaults(), so the widget and the shortcode agree.
	 */
	private static function builder_controls() {
		return array(
			'section_rb_start'  => array(
				__( 'Start screen', 'om-catalog' ),
				array(
					array( 'intro_eyebrow', 'text', __( 'Small line above the title', 'om-catalog' ) ),
					array( 'intro_title', 'text', __( 'Title', 'om-catalog' ) ),
					array( 'intro_text', 'textarea', __( 'Intro', 'om-catalog' ) ),
					array( 'start_setting', 'switch', __( 'Offer "Start with a setting"', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'setting_tag', 'text', __( 'Its tag', 'om-catalog' ), array( 'condition' => array( 'start_setting' => 'yes' ) ) ),
					array( 'setting_title', 'text', __( 'Its title', 'om-catalog' ), array( 'condition' => array( 'start_setting' => 'yes' ) ) ),
					array( 'setting_text', 'textarea', __( 'Its text', 'om-catalog' ), array( 'condition' => array( 'start_setting' => 'yes' ) ) ),
					array( 'setting_cta', 'text', __( 'Its button', 'om-catalog' ), array( 'condition' => array( 'start_setting' => 'yes' ) ) ),
					array( 'start_diamond', 'switch', __( 'Offer "Start with a diamond"', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'diamond_tag', 'text', __( 'Its tag', 'om-catalog' ), array( 'condition' => array( 'start_diamond' => 'yes' ) ) ),
					array( 'diamond_title', 'text', __( 'Its title', 'om-catalog' ), array( 'condition' => array( 'start_diamond' => 'yes' ) ) ),
					array( 'diamond_text', 'textarea', __( 'Its text', 'om-catalog' ), array( 'condition' => array( 'start_diamond' => 'yes' ) ) ),
					array( 'diamond_cta', 'text', __( 'Its button', 'om-catalog' ), array( 'condition' => array( 'start_diamond' => 'yes' ) ) ),
					array( 'start_guide', 'switch', __( 'Offer "Help me choose"', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'guide_tag', 'text', __( 'Its tag', 'om-catalog' ), array( 'condition' => array( 'start_guide' => 'yes' ) ) ),
					array( 'guide_title', 'text', __( 'Its title', 'om-catalog' ), array( 'condition' => array( 'start_guide' => 'yes' ) ) ),
					array( 'guide_text', 'textarea', __( 'Its text', 'om-catalog' ), array( 'condition' => array( 'start_guide' => 'yes' ) ) ),
					array( 'guide_cta', 'text', __( 'Its button', 'om-catalog' ), array( 'condition' => array( 'start_guide' => 'yes' ) ) ),
					array( 'continue', 'switch', __( '"Continue your ring" for returning visitors', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'promises', 'text', __( 'Promises (separate with |)', 'om-catalog' ), array( 'description' => __( 'Short lines under the options. Leave empty for none.', 'om-catalog' ) ) ),
				),
			),
			'section_rb_steps'  => array(
				__( 'Steps & guidance', 'om-catalog' ),
				array(
					array( 'heading', 'text', __( 'Heading above the steps (optional)', 'om-catalog' ) ),
					array( 'step_setting', 'text', __( 'Step name: setting', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'step_diamond', 'text', __( 'Step name: diamond', 'om-catalog' ) ),
					array( 'step_review', 'text', __( 'Step name: review', 'om-catalog' ) ),
					array( 'title_setting', 'text', __( 'Title: setting step', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'guide_setting', 'textarea', __( 'Guidance: setting first', 'om-catalog' ) ),
					array( 'guide_setting2', 'textarea', __( 'Guidance: setting after a diamond', 'om-catalog' ), array( 'description' => __( '{diamond} = the stone chosen.', 'om-catalog' ) ) ),
					array( 'tip_setting', 'textarea', __( 'Tip on the setting step', 'om-catalog' ), array( 'description' => __( 'Leave empty for none.', 'om-catalog' ) ) ),
					array( 'title_diamond', 'text', __( 'Title: diamond step', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'guide_diamond', 'textarea', __( 'Guidance: diamond after a setting', 'om-catalog' ), array( 'description' => __( '{setting} = the setting chosen.', 'om-catalog' ) ) ),
					array( 'guide_diamond1', 'textarea', __( 'Guidance: diamond first', 'om-catalog' ) ),
					array( 'title_review', 'text', __( 'Title: review step', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'guide_review', 'textarea', __( 'Guidance: review', 'om-catalog' ) ),
				),
			),
			'section_rb_grid'   => array(
				__( 'Settings & diamonds', 'om-catalog' ),
				array(
					array( 'look_page', 'look', __( '"Choose a setting" looks like', 'om-catalog' ) ),
					array( 'per_page', 'number', __( 'Settings per page', 'om-catalog' ), array( 'min' => 3, 'max' => 60 ) ),
					array( 'choose_text', 'text', __( 'Card button', 'om-catalog' ) ),
					array(
						'diamond_origin',
						'select',
						__( 'Diamonds', 'om-catalog' ),
						array(
							'separator' => 'before',
							'options'   => array(
								''        => __( 'Lab-grown and natural', 'om-catalog' ),
								'lab'     => __( 'Lab-grown only', 'om-catalog' ),
								'natural' => __( 'Natural only', 'om-catalog' ),
							),
						),
					),
					array(
						'fit_rule',
						'select',
						__( 'Diamonds that fit a setting', 'om-catalog' ),
						array(
							'options'     => array(
								'strict' => __( 'Strict: the setting’s carat sizes', 'om-catalog' ),
								'loose'  => __( 'Loose: a little either side', 'om-catalog' ),
								'off'    => __( 'Shape only', 'om-catalog' ),
							),
							'description' => __( 'Once both are chosen, the setting’s head size is matched to the stone automatically.', 'om-catalog' ),
						),
					),
					array( 'true_size', 'switch', __( '"True size" on diamonds', 'om-catalog' ), array( 'description' => __( 'Shows the stone at its real size on a finger, compared with other carats.', 'om-catalog' ) ) ),
					array( 'diamond_compare', 'switch', __( '"Compare" diamonds', 'om-catalog' ), array( 'description' => __( 'Visitors tick up to 4 diamonds and see them side by side.', 'om-catalog' ) ) ),
					array( 'skip_diamond', 'switch', __( '"Continue without a diamond"', 'om-catalog' ), array( 'description' => __( 'Lets customers finish with the setting alone and send the request — the centre stone is chosen with you, or it’s their own.', 'om-catalog' ) ) ),
					array( 'skip_text', 'text', __( 'Its text', 'om-catalog' ), array( 'condition' => array( 'skip_diamond' => 'yes' ) ) ),
				),
			),
			'section_rb_guide'  => array(
				__( 'Help me choose', 'om-catalog' ),
				array(
					array(
						'guide',
						'select',
						__( 'Guide by', 'om-catalog' ),
						array(
							'options'     => array(
								'auto'   => __( 'Automatic: budget when prices show, size while hidden', 'om-catalog' ),
								'budget' => __( 'Budget (needs diamond prices)', 'om-catalog' ),
								'size'   => __( 'Size', 'om-catalog' ),
								'off'    => __( 'Off', 'om-catalog' ),
							),
							'description' => __( 'Suggests the three best real diamonds (value, balance, sparkle) for the visitor’s answers, each with a plain-words reason.', 'om-catalog' ),
						),
					),
					array( 'guide_eyebrow', 'text', __( 'Small line above the title', 'om-catalog' ), array( 'condition' => array( 'guide!' => 'off' ) ) ),
					array( 'guide_heading', 'text', __( 'Title (by size)', 'om-catalog' ), array( 'condition' => array( 'guide!' => 'off' ) ) ),
					array( 'guide_heading_b', 'text', __( 'Title (by budget)', 'om-catalog' ), array( 'condition' => array( 'guide!' => 'off' ) ) ),
					array( 'guide_intro', 'textarea', __( 'Intro', 'om-catalog' ), array( 'condition' => array( 'guide!' => 'off' ) ) ),
					array( 'guide_link', 'text', __( 'Link on the diamond step', 'om-catalog' ), array( 'condition' => array( 'guide!' => 'off' ), 'description' => __( 'Leave empty for none.', 'om-catalog' ) ) ),
					array( 'budget_min', 'number', __( 'Budget from', 'om-catalog' ), array( 'condition' => array( 'guide!' => array( 'off', 'size' ) ) ) ),
					array( 'budget_max', 'number', __( 'Budget up to', 'om-catalog' ), array( 'condition' => array( 'guide!' => array( 'off', 'size' ) ) ) ),
					array( 'guide_send', 'switch', __( 'Send the answers with requests', 'om-catalog' ), array( 'condition' => array( 'guide!' => 'off' ), 'description' => __( 'Their budget or size, priority and lab/natural go with the request and the "Ask us" question (email and Inquiries list). The visitor sees a short note saying so.', 'om-catalog' ) ) ),
				),
			),
			'section_rb_bar'    => array(
				__( '"Your ring" bar', 'om-catalog' ),
				array(
					array( 'bar', 'switch', __( 'Show the bar', 'om-catalog' ), array( 'description' => __( 'Shows the setting and diamond chosen so far, the total (when prices show) and the next step.', 'om-catalog' ) ) ),
					array( 'bar_review', 'switch', __( 'Also on the review step', 'om-catalog' ), array( 'condition' => array( 'bar' => 'yes' ), 'description' => __( 'Off by default: the review already shows the ring and the total, and phones get the space back.', 'om-catalog' ) ) ),
					array( 'chat_in_bar', 'switch', __( 'AI assistant button in the bar', 'om-catalog' ), array( 'description' => __( 'When the AI assistant is on, its button sits in the bar (and on the review) instead of floating over the page.', 'om-catalog' ) ) ),
					array( 'ask_text', 'text', __( 'Questions link', 'om-catalog' ), array( 'description' => __( 'Leave empty for none.', 'om-catalog' ) ) ),
					array( 'ask_url', 'url', __( 'Questions link goes to', 'om-catalog' ), array( 'description' => __( 'Empty: a short inquiry form opens in a pop-up. Or a page, tel: or WhatsApp link.', 'om-catalog' ) ) ),
				),
			),
			'section_rb_review' => array(
				__( 'Review & request', 'om-catalog' ),
				array(
					array( 'request_heading', 'text', __( 'Form heading', 'om-catalog' ) ),
					array( 'request_intro', 'textarea', __( 'Form intro', 'om-catalog' ) ),
					array( 'request_button', 'text', __( 'Form button', 'om-catalog' ) ),
					array( 'reassure', 'text', __( 'Line under the button', 'om-catalog' ), array( 'description' => __( 'A reassuring note. Leave empty for none.', 'om-catalog' ) ) ),
					array( 'request_subject', 'text', __( 'Subject of requests', 'om-catalog' ), array( 'condition' => array( 'review_topics!' => 'yes' ) ) ),
					array( 'review_topics', 'switch', __( '"What is it about?" choices', 'om-catalog' ), array( 'description' => __( 'Off by default: from the builder it’s always a ring request.', 'om-catalog' ) ) ),
					array( 'hero_tag', 'switch', __( 'Name the stone and metal on the photo', 'om-catalog' ) ),
					array( 'ring_size', 'switch', __( 'Ring size field', 'om-catalog' ) ),
					array( 'engraving', 'switch', __( 'Engraving field', 'om-catalog' ) ),
					array(
						'book',
						'select',
						__( 'Book a viewing', 'om-catalog' ),
						array(
							'separator' => 'before',
							'options'   => array(
								'inquiry' => __( 'Opens the form with a subject', 'om-catalog' ),
								'url'     => __( 'Goes to a link (e.g. a booking page)', 'om-catalog' ),
								'off'     => __( 'Off', 'om-catalog' ),
							),
						),
					),
					array( 'book_text', 'text', __( 'Button text', 'om-catalog' ), array( 'condition' => array( 'book!' => 'off' ) ) ),
					array( 'book_subject', 'text', __( 'Subject chosen', 'om-catalog' ), array( 'condition' => array( 'book' => 'inquiry' ) ) ),
					array( 'book_url', 'url', __( 'Booking link', 'om-catalog' ), array( 'condition' => array( 'book' => 'url' ) ) ),
					array( 'share', 'switch', __( '"Share this design"', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'email_me', 'switch', __( '"Email it to me"', 'om-catalog' ), array( 'description' => __( 'Sends the visitor a link to their design; you get a copy.', 'om-catalog' ) ) ),
					array( 'next_title', 'text', __( '"What happens next" title', 'om-catalog' ), array( 'separator' => 'before' ) ),
					array( 'next_steps', 'textarea', __( '"What happens next" steps (separate with |)', 'om-catalog' ), array( 'description' => __( 'Up to 4 short steps. Leave empty to hide the section.', 'om-catalog' ) ) ),
					array( 'done_title', 'text', __( 'After sending: title', 'om-catalog' ), array( 'separator' => 'before', 'description' => __( 'A thank-you panel with their ring replaces the form once it is sent.', 'om-catalog' ) ) ),
					array( 'done_text', 'textarea', __( 'After sending: text', 'om-catalog' ) ),
					array( 'done_steps', 'textarea', __( 'After sending: steps (separate with |)', 'om-catalog' ), array( 'description' => __( 'Up to 4. The "Booking link" above shows as a button there too.', 'om-catalog' ) ) ),
				),
			),
		);
	}

	protected function register_controls() {
		$defaults = OM_Ring_Builder::defaults();
		$first    = true;
		foreach ( self::builder_controls() as $section => $def ) {
			$this->start_controls_section( $section, array( 'label' => $def[0] ) );
			if ( $first ) {
				$this->add_control(
					'note',
					array(
						'type'            => Controls_Manager::RAW_HTML,
						'raw'             => __( 'Choose this page as the builder page under Settings > OM Catalog > Ring Builder, so product pages and the diamond search link here.', 'om-catalog' ),
						'content_classes' => 'elementor-descriptor',
					)
				);
				$first = false;
			}
			foreach ( $def[1] as $control ) {
				list( $key, $type, $label ) = $control;
				$extra = $control[3] ?? array();
				$args  = array( 'label' => $label ) + $extra;
				switch ( $type ) {
					case 'switch':
						$args += array( 'type' => Controls_Manager::SWITCHER, 'default' => 'no' === $defaults[ $key ] ? '' : 'yes' );
						break;
					case 'textarea':
						$args += array( 'type' => Controls_Manager::TEXTAREA, 'rows' => 3, 'default' => $defaults[ $key ] );
						break;
					case 'number':
						$args += array( 'type' => Controls_Manager::NUMBER, 'default' => $defaults[ $key ] );
						break;
					case 'select':
						$args += array( 'type' => Controls_Manager::SELECT, 'default' => $defaults[ $key ] );
						break;
					case 'url':
						$args += array( 'type' => Controls_Manager::URL, 'show_external' => false, 'placeholder' => 'https://' );
						break;
					case 'look':
						$looks = array(
							''     => __( 'Automatic: same as my catalog page', 'om-catalog' ),
							'none' => __( "The builder's own look", 'om-catalog' ),
						);
						foreach ( om_elementor_pages_with( 'om_catalog_widget' ) as $page_id => $title ) {
							/* translators: %s: page title. */
							$looks[ (string) $page_id ] = sprintf( __( 'Same as: %s', 'om-catalog' ), $title );
						}
						$args += array(
							'type'        => Controls_Manager::SELECT,
							'default'     => '',
							'options'     => $looks,
							'description' => __( 'The settings grid copies an OM Product Catalog widget: its design, cards, fonts, filters and Style-tab settings. Edit that widget and the builder follows.', 'om-catalog' ),
						);
						break;
					default:
						$args += array( 'type' => Controls_Manager::TEXT, 'default' => $defaults[ $key ], 'label_block' => true );
				}
				$this->add_control( $key, $args );
			}
			$this->end_controls_section();
		}

		$this->register_common_style( '{{WRAPPER}} .om-builder', '{{WRAPPER}} .om-builder-heading, {{WRAPPER}} .om-rb-title, {{WRAPPER}} .om-rb-start-title, {{WRAPPER}} .om-rb-way-title, {{WRAPPER}} .om-review-title' );

		$this->start_controls_section(
			'section_style_rb',
			array(
				'label' => __( 'Builder', 'om-catalog' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'rb_gold',
			array(
				'label'       => __( 'Highlight (steps done, small titles)', 'om-catalog' ),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => array( '{{WRAPPER}} .om-builder' => '--om-gold: {{VALUE}};' ),
			)
		);
		$this->add_control(
			'rb_panel_bg',
			array(
				'label'     => __( 'Card & panel background', 'om-catalog' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .om-builder' => '--om-rb-panel: {{VALUE}};' ),
			)
		);
		$this->add_control(
			'rb_bar_bg',
			array(
				'label'     => __( '"Your ring" bar background', 'om-catalog' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .om-rb-bar' => '--om-rb-bar-bg: {{VALUE}};' ),
			)
		);
		$this->add_responsive_control(
			'rb_radius',
			array(
				'label'      => __( 'Card corners', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 32 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-builder' => '--om-rb-radius: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$atts = array();
		foreach ( self::builder_controls() as $def ) {
			foreach ( $def[1] as $control ) {
				list( $key, $type ) = $control;
				if ( ! array_key_exists( $key, $s ) ) {
					continue;
				}
				if ( 'switch' === $type ) {
					$atts[ $key ] = 'yes' === $s[ $key ] ? 'yes' : 'no';
				} elseif ( 'url' === $type ) {
					$atts[ $key ] = (string) ( $s[ $key ]['url'] ?? '' );
				} else {
					$atts[ $key ] = is_scalar( $s[ $key ] ) ? (string) $s[ $key ] : '';
				}
			}
		}
		echo OM_Ring_Builder::instance()->render( $atts ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the renderer.
	}
}

/** "OM Related Products" widget: related / recently viewed / hand-picked. */
class OM_Elementor_Related_Widget extends Widget_Base {
	use OM_Elementor_Card_Controls;

	public function get_name() {
		return 'om_related_widget';
	}

	public function get_title() {
		return __( 'OM Related Products', 'om-catalog' );
	}

	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'related', 'recently viewed', 'also like', 'upsell', 'products', 'carousel' );
	}

	public function get_style_depends() {
		return array( 'om-catalog-css', 'om-catalog-fonts' );
	}

	public function get_script_depends() {
		return array( 'om-catalog-js' );
	}

	/** Color control helper. */
	private function color( $id, $label, $selectors, $extra = array() ) {
		$this->add_control( $id, array( 'label' => $label, 'type' => Controls_Manager::COLOR, 'selectors' => $selectors ) + $extra );
	}

	/** Slider control helper (px, optional other units). */
	private function slider( $id, $label, $selectors, $max = 100, $units = array( 'px' ), $responsive = true, $extra = array() ) {
		$args = array(
			'label'      => $label,
			'type'       => Controls_Manager::SLIDER,
			'size_units' => $units,
			'range'      => array(
				'px' => array( 'min' => 0, 'max' => $max ),
				'%'  => array( 'min' => 0, 'max' => 100 ),
				'em' => array( 'min' => 0, 'max' => 10, 'step' => 0.1 ),
			),
			'selectors'  => $selectors,
		) + $extra;
		$responsive ? $this->add_responsive_control( $id, $args ) : $this->add_control( $id, $args );
	}

	private function dimensions( $id, $label, $selector, $property ) {
		$this->add_responsive_control(
			$id,
			array(
				'label'      => $label,
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array( $selector => $property . ': {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
	}

	protected function register_controls() {

		/* ---------- Content: products ---------- */

		$this->start_controls_section( 'section_content', array( 'label' => __( 'Products', 'om-catalog' ) ) );

		$this->add_control(
			'source',
			array(
				'label'       => __( 'Show', 'om-catalog' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'related',
				'options'     => array(
					'related' => __( 'You might also like (related designs)', 'om-catalog' ),
					'recent'  => __( 'Recently viewed by this visitor', 'om-catalog' ),
					'picked'  => __( 'Hand-picked style numbers', 'om-catalog' ),
					'set'     => __( 'Complete the set (matching bands / rings)', 'om-catalog' ),
				),
				'description' => __( 'On a product page, "related" follows the product being viewed. "Recently viewed" stays hidden until the visitor has looked at other pieces. "Complete the set" shows matching wedding bands on a ring page (and rings on a band page); exact pairs can be listed in Settings > OM Catalog.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'set_line',
			array(
				'label'       => __( 'Pair with line', 'om-catalog' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array( '' => __( 'Automatic (bands for rings, rings for bands)', 'om-catalog' ) ) + OM_Shortcodes::line_labels( is_admin() ),
				'condition'   => array( 'source' => 'set' ),
			)
		);

		$this->add_control(
			'subtitle',
			array(
				'label'       => __( 'Line under the title', 'om-catalog' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 2,
				'placeholder' => __( 'Wedding bands chosen to sit beautifully with this ring. They follow the metal you pick.', 'om-catalog' ),
				'description' => __( 'Leave empty for the default; type a single space to hide it.', 'om-catalog' ),
				'condition'   => array( 'source' => 'set' ),
			)
		);

		$this->add_control(
			'set_price',
			array(
				'label'       => __( '"Set from" price', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => __( 'Both pieces together, under each card (needs card prices on).', 'om-catalog' ),
				'condition'   => array( 'source' => 'set' ),
			)
		);

		$this->add_control(
			'set_inquiry',
			array(
				'label'       => __( '"Ask about this set" link', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => __( 'Opens the page\'s inquiry form with the subject "Bridal set" and both pieces in the email.', 'om-catalog' ),
				'condition'   => array( 'source' => 'set' ),
			)
		);

		$this->add_control(
			'line',
			array(
				'label'       => __( 'Product line', 'om-catalog' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'engagement-rings',
				'options'     => OM_Shortcodes::line_labels( is_admin() ),
				'description' => __( 'For hand-picked products, and for related products outside a product page.', 'om-catalog' ),
				'condition'   => array( 'source!' => 'recent' ),
			)
		);

		$this->add_control(
			'styles',
			array(
				'label'       => __( 'Style numbers', 'om-catalog' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 2,
				'placeholder' => '85121-2, 84842-2',
				'condition'   => array( 'source' => 'picked' ),
			)
		);

		$this->add_control(
			'count',
			array(
				'label'   => __( 'Number of products', 'om-catalog' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 12,
			)
		);

		$this->end_controls_section();

		/* ---------- Content: layout ---------- */

		$this->start_controls_section( 'section_layout', array( 'label' => __( 'Layout', 'om-catalog' ) ) );

		$this->add_control(
			'title',
			array(
				'label'       => __( 'Title', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'You might also like', 'om-catalog' ),
				'description' => __( 'Leave empty for the default; type a single space to hide the title.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'title_tag',
			array(
				'label'   => __( 'Title HTML tag', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => array( 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'p' => 'p' ),
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => __( 'Display', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => array(
					'grid'     => __( 'Grid', 'om-catalog' ),
					'carousel' => __( 'Carousel (swipe / arrows)', 'om-catalog' ),
				),
			)
		);

		$this->add_control(
			'card_layout',
			array(
				'label'   => __( 'Card design', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'classic',
				'options' => array(
					'classic'   => __( 'Classic (centered under image)', 'om-catalog' ),
					'editorial' => __( 'Editorial (left-aligned)', 'om-catalog' ),
					'boxed'     => __( 'Boxed (framed card)', 'om-catalog' ),
					'overlay'   => __( 'Overlay (title on image)', 'om-catalog' ),
				),
			)
		);

		$this->add_responsive_control(
			'columns',
			array(
				'label'          => __( 'Columns / cards in view', 'om-catalog' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '3',
				'mobile_default' => '2',
				'options'        => array( '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5', '6' => '6' ),
				'selectors'      => array( '{{WRAPPER}} .om-related' => '--om-related-columns: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'show_arrows',
			array(
				'label'     => __( 'Arrows', 'om-catalog' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array( 'layout' => 'carousel' ),
			)
		);

		$this->add_control(
			'autoplay',
			array(
				'label'       => __( 'Autoplay every (seconds)', 'om-catalog' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'min'         => 0,
				'max'         => 30,
				'description' => __( '0 = off. Pauses while hovered or touched, and for visitors who prefer reduced motion.', 'om-catalog' ),
				'condition'   => array( 'layout' => 'carousel' ),
			)
		);

		$this->add_control(
			'show_variant',
			array(
				'label'     => __( 'Carat / variant line', 'om-catalog' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'show_prices',
			array(
				'label'       => __( '"From $X" prices', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => '',
				'description' => __( 'Only once a markup is set.', 'om-catalog' ),
				'condition'   => array( 'source!' => 'recent' ),
			)
		);

		$this->add_control(
			'hover_image',
			array(
				'label'                => __( 'Second photo on hover', 'om-catalog' ),
				'type'                 => Controls_Manager::SWITCHER,
				'default'              => 'yes',
				'selectors_dictionary' => array( 'yes' => '', '' => 'display: none;' ),
				'selectors'            => array( '{{WRAPPER}} .om-card-hover' => '{{VALUE}}' ),
			)
		);

		$this->end_controls_section();

		/* ---------- Style: section & title ---------- */

		$this->register_quick_view_content( '' );
		$this->register_card_video_content();

		$this->start_controls_section( 'section_style_head', array( 'label' => __( 'Section & Title', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );

		$this->dimensions( 'section_margin', __( 'Section margin', 'om-catalog' ), '{{WRAPPER}} .om-related', 'margin' );
		$this->dimensions( 'section_padding', __( 'Section padding', 'om-catalog' ), '{{WRAPPER}} .om-related', 'padding' );
		$this->color( 'section_bg', __( 'Section background', 'om-catalog' ), array( '{{WRAPPER}} .om-related' => 'background-color: {{VALUE}};' ) );

		$this->color( 'title_color', __( 'Title color', 'om-catalog' ), array( '{{WRAPPER}} .om-related-title' => 'color: {{VALUE}};' ), array( 'separator' => 'before' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'title_typography', 'label' => __( 'Title typography', 'om-catalog' ), 'selector' => '{{WRAPPER}} .om-related-title' ) );
		$this->add_responsive_control(
			'title_align',
			array(
				'label'     => __( 'Title alignment', 'om-catalog' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array( 'title' => __( 'Left', 'om-catalog' ), 'icon' => 'eicon-text-align-left' ),
					'center' => array( 'title' => __( 'Center', 'om-catalog' ), 'icon' => 'eicon-text-align-center' ),
					'right'  => array( 'title' => __( 'Right', 'om-catalog' ), 'icon' => 'eicon-text-align-right' ),
				),
				'selectors_dictionary' => array(
					'left'   => 'justify-content: space-between; text-align: left;',
					'center' => 'justify-content: center; text-align: center;',
					'right'  => 'justify-content: flex-end; text-align: right;',
				),
				'selectors' => array( '{{WRAPPER}} .om-related-head' => '{{VALUE}}' ),
			)
		);
		$this->slider( 'title_spacing', __( 'Space below title', 'om-catalog' ), array( '{{WRAPPER}} .om-related-head' => 'margin-bottom: {{SIZE}}{{UNIT}};' ), 100 );

		$this->end_controls_section();

		/* ---------- Style: grid / carousel ---------- */

		$this->start_controls_section( 'section_style_grid', array( 'label' => __( 'Grid & Carousel', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );

		$this->slider( 'gap', __( 'Gap between cards', 'om-catalog' ), array( '{{WRAPPER}} .om-related' => '--om-related-gap: {{SIZE}}{{UNIT}};' ), 80 );
		$this->slider( 'row_gap', __( 'Row gap (grid)', 'om-catalog' ), array( '{{WRAPPER}} .om-related-track' => 'row-gap: {{SIZE}}{{UNIT}};' ), 120, array( 'px' ), true, array( 'condition' => array( 'layout' => 'grid' ) ) );
		$this->add_control(
			'peek',
			array(
				'label'       => __( 'Peek of next card (carousel)', 'om-catalog' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => array( '%' ),
				'range'       => array( '%' => array( 'min' => 0, 'max' => 40 ) ),
				'description' => __( 'Shows part of the next card so visitors see the row scrolls.', 'om-catalog' ),
				'selectors'   => array( '{{WRAPPER}} .om-related--carousel .om-related-track' => 'padding-right: {{SIZE}}%; scroll-padding-right: {{SIZE}}%;' ),
				'condition'   => array( 'layout' => 'carousel' ),
			)
		);

		$this->end_controls_section();

		/* ---------- Style: cards ---------- */

		$this->start_controls_section( 'section_style_card', array( 'label' => __( 'Cards', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );

		$this->color( 'card_bg', __( 'Background', 'om-catalog' ), array( '{{WRAPPER}} .om-card' => 'background-color: {{VALUE}};' ) );
		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array( 'name' => 'card_border', 'selector' => '{{WRAPPER}} .om-card' ) );
		$this->slider( 'card_radius', __( 'Corner radius', 'om-catalog' ), array( '{{WRAPPER}} .om-card, {{WRAPPER}} .om-card-image' => 'border-radius: {{SIZE}}{{UNIT}};' ), 40 );
		$this->dimensions( 'card_padding', __( 'Padding', 'om-catalog' ), '{{WRAPPER}} .om-card', 'padding' );
		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array( 'name' => 'card_shadow', 'selector' => '{{WRAPPER}} .om-card' ) );
		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array( 'name' => 'card_shadow_hover', 'label' => __( 'Hover shadow', 'om-catalog' ), 'selector' => '{{WRAPPER}} .om-card:hover' ) );
		$this->add_responsive_control(
			'card_align',
			array(
				'label'     => __( 'Text alignment', 'om-catalog' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array( 'title' => __( 'Left', 'om-catalog' ), 'icon' => 'eicon-text-align-left' ),
					'center' => array( 'title' => __( 'Center', 'om-catalog' ), 'icon' => 'eicon-text-align-center' ),
					'right'  => array( 'title' => __( 'Right', 'om-catalog' ), 'icon' => 'eicon-text-align-right' ),
				),
				'selectors' => array( '{{WRAPPER}} .om-card-body' => 'text-align: {{VALUE}};' ),
			)
		);

		$this->end_controls_section();

		/* ---------- Style: image ---------- */

		$this->start_controls_section( 'section_style_image', array( 'label' => __( 'Image', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );

		$this->add_control(
			'image_ratio',
			array(
				'label'     => __( 'Aspect ratio', 'om-catalog' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => array(
					''    => __( 'Square (default)', 'om-catalog' ),
					'4/5' => __( 'Portrait 4:5', 'om-catalog' ),
					'3/4' => __( 'Portrait 3:4', 'om-catalog' ),
					'4/3' => __( 'Landscape 4:3', 'om-catalog' ),
				),
				'selectors' => array( '{{WRAPPER}} .om-card-image' => 'aspect-ratio: {{VALUE}};' ),
			)
		);
		$this->add_control(
			'image_fit',
			array(
				'label'     => __( 'Image fit', 'om-catalog' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => array(
					''        => __( 'Fill (crop)', 'om-catalog' ),
					'contain' => __( 'Fit whole image', 'om-catalog' ),
				),
				'selectors' => array( '{{WRAPPER}} .om-card-image img' => 'object-fit: {{VALUE}};' ),
			)
		);
		$this->color( 'image_bg', __( 'Background', 'om-catalog' ), array( '{{WRAPPER}} .om-card-image' => 'background-color: {{VALUE}};' ) );
		$this->slider( 'image_spacing', __( 'Space below image', 'om-catalog' ), array( '{{WRAPPER}} .om-card-image' => 'margin-bottom: {{SIZE}}{{UNIT}};' ), 60 );
		$this->add_control(
			'image_zoom',
			array(
				'label'     => __( 'Hover zoom', 'om-catalog' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => array(
					''      => __( 'Subtle (default)', 'om-catalog' ),
					'1'     => __( 'None', 'om-catalog' ),
					'1.08'  => __( 'Medium', 'om-catalog' ),
					'1.15'  => __( 'Strong', 'om-catalog' ),
				),
				'selectors' => array( '{{WRAPPER}} .om-card:hover .om-card-image img' => 'transform: scale({{VALUE}});' ),
			)
		);

		$this->end_controls_section();

		/* ---------- Style: text ---------- */

		$this->start_controls_section( 'section_style_text', array( 'label' => __( 'Product Name, Carat & Price', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );

		$this->color( 'card_title_color', __( 'Name color', 'om-catalog' ), array( '{{WRAPPER}} .om-card-title' => 'color: {{VALUE}};' ) );
		$this->color( 'card_title_hover', __( 'Name hover color', 'om-catalog' ), array( '{{WRAPPER}} .om-card:hover .om-card-title' => 'color: {{VALUE}};' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'card_title_typography', 'label' => __( 'Name typography', 'om-catalog' ), 'selector' => '{{WRAPPER}} .om-card-title' ) );
		$this->slider( 'card_title_spacing', __( 'Space below name', 'om-catalog' ), array( '{{WRAPPER}} .om-card-title' => 'margin-bottom: {{SIZE}}{{UNIT}};' ), 40 );

		$this->color( 'variant_color', __( 'Carat line color', 'om-catalog' ), array( '{{WRAPPER}} .om-card-variant' => 'color: {{VALUE}};' ), array( 'separator' => 'before' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'variant_typography', 'label' => __( 'Carat line typography', 'om-catalog' ), 'selector' => '{{WRAPPER}} .om-card-variant' ) );

		$this->color( 'price_color', __( 'Price color', 'om-catalog' ), array( '{{WRAPPER}} .om-card-price' => 'color: {{VALUE}};' ), array( 'separator' => 'before' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'price_typography', 'label' => __( 'Price typography', 'om-catalog' ), 'selector' => '{{WRAPPER}} .om-card-price' ) );

		$this->end_controls_section();

		/* ---------- Style: arrows ---------- */

		$this->register_card_extras_style();
		$this->register_card_look_style();

		$this->start_controls_section(
			'section_style_arrows',
			array(
				'label'     => __( 'Arrows', 'om-catalog' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( 'layout' => 'carousel', 'show_arrows' => 'yes' ),
			)
		);

		$this->slider( 'arrow_size', __( 'Button size', 'om-catalog' ), array( '{{WRAPPER}} .om-related-nav button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ), 80 );
		$this->slider( 'arrow_icon_size', __( 'Icon size', 'om-catalog' ), array( '{{WRAPPER}} .om-related-nav button' => 'font-size: {{SIZE}}{{UNIT}};' ), 48 );
		$this->slider( 'arrow_radius', __( 'Corner radius', 'om-catalog' ), array( '{{WRAPPER}} .om-related-nav button' => 'border-radius: {{SIZE}}{{UNIT}};' ), 50, array( 'px', '%' ) );

		$this->start_controls_tabs( 'arrow_tabs' );
		foreach ( array( 'normal' => __( 'Normal', 'om-catalog' ), 'hover' => __( 'Hover', 'om-catalog' ) ) as $state => $state_label ) {
			$this->start_controls_tab( 'arrow_tab_' . $state, array( 'label' => $state_label ) );
			$sel = '{{WRAPPER}} .om-related-nav button' . ( 'hover' === $state ? ':hover' : '' );
			$this->color( 'arrow_color_' . $state, __( 'Icon', 'om-catalog' ), array( $sel => 'color: {{VALUE}};' ) );
			$this->color( 'arrow_bg_' . $state, __( 'Background', 'om-catalog' ), array( $sel => 'background-color: {{VALUE}};' ) );
			$this->color( 'arrow_border_' . $state, __( 'Border', 'om-catalog' ), array( $sel => 'border-color: {{VALUE}};' ) );
			$this->end_controls_tab();
		}
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$title = (string) $s['title'];
		$html  = OM_Related::instance()->render(
			array(
				'source'       => (string) $s['source'],
				'title'        => ( '' !== $title && '' === trim( $title ) ) ? ' ' : $title,
				'line'         => (string) ( $s['line'] ?? '' ),
				'styles'       => (string) ( $s['styles'] ?? '' ),
				'count'        => (int) $s['count'],
				'layout'       => (string) $s['layout'],
				'card_layout'  => (string) ( $s['card_layout'] ?? 'classic' ),
				'show_variant' => (string) ( $s['show_variant'] ?? 'yes' ),
				'show_arrows'  => (string) ( $s['show_arrows'] ?? 'yes' ),
				'autoplay'     => (int) ( $s['autoplay'] ?? 0 ),
				'show_prices'  => (string) ( $s['show_prices'] ?? '' ),
				'set_line'     => (string) ( $s['set_line'] ?? '' ),
				'subtitle'     => ( '' !== (string) ( $s['subtitle'] ?? '' ) && '' === trim( (string) $s['subtitle'] ) ) ? ' ' : (string) ( $s['subtitle'] ?? '' ),
				'set_price'    => 'yes' === ( $s['set_price'] ?? 'yes' ) ? 'yes' : '',
				'set_inquiry'  => 'yes' === ( $s['set_inquiry'] ?? 'yes' ) ? 'yes' : '',
			) + $this->card_extras_atts( $s )
		);
		// Title tag.
		$tag = in_array( $s['title_tag'] ?? 'h2', array( 'h2', 'h3', 'h4', 'p' ), true ) ? $s['title_tag'] : 'h2';
		if ( 'h2' !== $tag ) {
			$html = preg_replace( '#<h2 class="om-related-title">(.*?)</h2>#s', '<' . $tag . ' class="om-related-title">$1</' . $tag . '>', $html, 1 );
		}
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the renderer.
	}
}

/** "OM Search" widget: one search box for every product line, e.g. in a header. */
class OM_Elementor_Search_Widget extends Widget_Base {

	public function get_name() {
		return 'om_search_widget';
	}

	public function get_title() {
		return __( 'OM Search', 'om-catalog' );
	}

	public function get_icon() {
		return 'eicon-search';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'search', 'jewelry', 'rings', 'overnight', 'catalog' );
	}

	public function get_style_depends() {
		return array( 'om-catalog-css' );
	}

	public function get_script_depends() {
		return array( 'om-catalog-js' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array( 'label' => __( 'Search', 'om-catalog' ) ) );

		$this->add_control(
			'lines',
			array(
				'label'       => __( 'Search these lines', 'om-catalog' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'label_block' => true,
				'options'     => OM_Shortcodes::line_labels( is_admin() ),
				'default'     => array(),
				'description' => __( 'Leave empty to search every product line. Suggestions are grouped by line.', 'om-catalog' ),
			)
		);

		$pages = array( '' => __( 'From Settings > OM Catalog > Search', 'om-catalog' ) );
		if ( is_admin() ) {
			foreach ( get_pages( array( 'number' => 200 ) ) as $page ) {
				$pages[ (string) $page->ID ] = $page->post_title;
			}
		}
		$this->add_control(
			'results_page',
			array(
				'label'       => __( 'Results page', 'om-catalog' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => $pages,
				'description' => __( 'A page with an OM Product Catalog widget showing these lines. "See all" and Enter go there.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'placeholder',
			array(
				'label'       => __( 'Placeholder', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Search rings, bands, style numbers…', 'om-catalog' ),
			)
		);

		$this->add_control(
			'button',
			array(
				'label'   => __( 'Search button', 'om-catalog' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'suggest_prices',
			array(
				'label'       => __( 'Prices in suggestions', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => __( 'Once a markup is set.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'suggest_viewed',
			array(
				'label'       => __( 'Recently viewed in search', 'om-catalog' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 4,
				'min'         => 0,
				'max'         => 8,
				'description' => __( 'When the box is clicked (and when a search finds nothing), show the last designs this visitor looked at. 0 = off.', 'om-catalog' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section( 'section_style_box', array( 'label' => __( 'Search Box', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );

		$this->add_responsive_control(
			'box_width',
			array(
				'label'      => __( 'Width', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array( 'px' => array( 'min' => 180, 'max' => 900 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-search-standalone' => 'max-width: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'box_height',
			array(
				'label'      => __( 'Height', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 32, 'max' => 72 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-search-input, {{WRAPPER}} .om-search-submit' => 'height: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'box_typography',
				'selector' => '{{WRAPPER}} .om-search-input',
			)
		);

		$this->add_control( 'box_bg', array( 'label' => __( 'Background', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-search-input' => 'background-color: {{VALUE}};' ) ) );
		$this->add_control( 'box_text', array( 'label' => __( 'Text', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-search-input, {{WRAPPER}} .om-search-icon' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'box_border', array( 'label' => __( 'Border', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-search-input' => 'border-color: {{VALUE}};' ) ) );
		$this->add_control(
			'box_radius',
			array(
				'label'      => __( 'Corner radius', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .om-search-input'                => 'border-radius: {{SIZE}}{{UNIT}} 0 0 {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .om-search--no-button .om-search-input' => 'border-radius: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .om-search-submit'               => 'border-radius: 0 {{SIZE}}{{UNIT}} {{SIZE}}{{UNIT}} 0;',
				),
			)
		);
		$this->add_control( 'btn_bg', array( 'label' => __( 'Button background', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'separator' => 'before', 'selectors' => array( '{{WRAPPER}} .om-search-submit' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ) ) );
		$this->add_control( 'btn_text', array( 'label' => __( 'Button text', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-search-submit' => 'color: {{VALUE}};' ) ) );

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo OM_Search::render_box( // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the renderer.
			array(
				'lines'          => implode( ',', (array) ( $s['lines'] ?? array() ) ),
				'results_page'   => (string) ( $s['results_page'] ?? '' ),
				'placeholder'    => (string) ( $s['placeholder'] ?? '' ),
				'suggest_prices' => 'yes' === ( $s['suggest_prices'] ?? 'yes' ) ? 'yes' : 'no',
				'suggest_viewed' => max( 0, min( 8, (int) ( $s['suggest_viewed'] ?? 4 ) ) ),
				'button'         => 'yes' === ( $s['button'] ?? 'yes' ) ? 'yes' : 'no',
			)
		);
	}
}

/** "OM Story Reels" widget: video stories of designs, Instagram-style. */
class OM_Elementor_Reels_Widget extends Widget_Base {

	public function get_name() {
		return 'om_reels_widget';
	}

	public function get_title() {
		return __( 'OM Story Reels', 'om-catalog' );
	}

	public function get_icon() {
		return 'eicon-video-playlist';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'stories', 'reels', 'video', 'jewelry', 'rings', 'overnight' );
	}

	public function get_style_depends() {
		return array( 'om-catalog-css' );
	}

	public function get_script_depends() {
		return array( 'om-catalog-js' );
	}

	protected function register_controls() {

		/* ---------- Content: stories ---------- */

		$this->start_controls_section( 'section_stories', array( 'label' => __( 'Stories', 'om-catalog' ) ) );

		$this->add_control(
			'source',
			array(
				'label'       => __( 'Designs', 'om-catalog' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'line',
				'options'     => array(
					'line'    => __( 'From a product line', 'om-catalog' ),
					'popular' => __( 'Most viewed', 'om-catalog' ),
					'picked'  => __( 'Hand-picked style numbers', 'om-catalog' ),
				),
				'description' => __( 'Only designs with a video are shown.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'line',
			array(
				'label'   => __( 'Product line', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'engagement-rings',
				'options' => OM_Shortcodes::line_labels( is_admin() ),
			)
		);

		$this->add_control(
			'style',
			array(
				'label'       => __( 'Collection / style (optional)', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => 'Halo',
				'condition'   => array( 'source' => 'line' ),
			)
		);

		$this->add_control(
			'shape',
			array(
				'label'       => __( 'Centre shape (optional)', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => 'Oval',
				'condition'   => array( 'source' => 'line' ),
			)
		);

		$this->add_control(
			'styles',
			array(
				'label'       => __( 'Style numbers', 'om-catalog' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 2,
				'placeholder' => '85121-2, 84842-2',
				'condition'   => array( 'source' => 'picked' ),
			)
		);

		$this->add_control(
			'count',
			array(
				'label'   => __( 'Number of stories', 'om-catalog' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 8,
				'min'     => 1,
				'max'     => 16,
			)
		);

		$this->end_controls_section();

		/* ---------- Content: row ---------- */

		$this->start_controls_section( 'section_row', array( 'label' => __( 'Bubbles', 'om-catalog' ) ) );

		$this->add_control(
			'heading',
			array(
				'label'       => __( 'Heading (optional)', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'See them move', 'om-catalog' ),
			)
		);

		$this->add_control(
			'bubble',
			array(
				'label'   => __( 'Bubble shape', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'circle',
				'options' => array(
					'circle' => __( 'Circles (like stories)', 'om-catalog' ),
					'card'   => __( 'Tall cards (like reels)', 'om-catalog' ),
				),
			)
		);

		$this->add_control(
			'label',
			array(
				'label'   => __( 'Label under each', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'title',
				'options' => array(
					'title'   => __( 'Design name (short)', 'om-catalog' ),
					'shape'   => __( 'Centre shape', 'om-catalog' ),
					'variant' => __( 'Carat / variant', 'om-catalog' ),
					'none'    => __( 'None', 'om-catalog' ),
				),
			)
		);

		$this->add_control(
			'show_on',
			array(
				'label'   => __( 'Show on', 'om-catalog' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => array(
					'all'     => __( 'All devices', 'om-catalog' ),
					'mobile'  => __( 'Phones only', 'om-catalog' ),
					'desktop' => __( 'Tablets & desktops only', 'om-catalog' ),
				),
			)
		);

		$this->add_responsive_control(
			'row_align',
			array(
				'label'     => __( 'Alignment', 'om-catalog' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array( 'title' => __( 'Left', 'om-catalog' ), 'icon' => 'eicon-text-align-left' ),
					'center'     => array( 'title' => __( 'Center', 'om-catalog' ), 'icon' => 'eicon-text-align-center' ),
				),
				'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-reels-justify: {{VALUE}};' ),
			)
		);

		$this->end_controls_section();

		/* ---------- Content: player ---------- */

		$this->start_controls_section( 'section_player', array( 'label' => __( 'Player', 'om-catalog' ) ) );

		$this->add_control(
			'button_text',
			array(
				'label'       => __( 'Button text', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'View this design', 'om-catalog' ),
			)
		);

		$this->add_control( 'show_price', array( 'label' => __( '"From" price', 'om-catalog' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
		$this->add_control( 'show_style', array( 'label' => __( 'Style number', 'om-catalog' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
		$this->add_control( 'auto_next', array( 'label' => __( 'Go to the next story by itself', 'om-catalog' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
		$this->add_control( 'sound', array( 'label' => __( 'Start with sound on', 'om-catalog' ), 'type' => Controls_Manager::SWITCHER, 'default' => '', 'description' => __( 'Off: stories start muted with a sound button (recommended).', 'om-catalog' ) ) );

		$this->add_control(
			'max_length',
			array(
				'label'       => __( 'Longest a video plays (seconds)', 'om-catalog' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 15,
				'min'         => 5,
				'max'         => 60,
			)
		);

		$this->add_control(
			'duration',
			array(
				'label'       => __( 'Embedded video length (seconds)', 'om-catalog' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 8,
				'min'         => 3,
				'max'         => 30,
				'description' => __( 'For YouTube / Vimeo / 360° players, which can\'t report their own length.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'colors',
			array(
				'label'       => __( 'Metal colour dots', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'separator'   => 'before',
				'description' => __( 'Yellow / White / Rose dots that switch the story to that metal (its video, or its photo) where a design has them, and open the design in that metal.', 'om-catalog' ),
			)
		);

		$this->end_controls_section();

		/* ---------- Content: end screen ---------- */

		$this->start_controls_section( 'section_end', array( 'label' => __( 'After the last story', 'om-catalog' ) ) );

		$this->add_control(
			'end_screen',
			array(
				'label'       => __( '"More like this" screen', 'om-catalog' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => __( 'Instead of closing, the player ends with 4 more designs, Watch again and Browse all.', 'om-catalog' ),
			)
		);

		$this->add_control(
			'more_title',
			array(
				'label'       => __( 'Title', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'More like this', 'om-catalog' ),
				'condition'   => array( 'end_screen' => 'yes' ),
			)
		);

		$this->add_control(
			'browse_text',
			array(
				'label'       => __( '"Browse all" text', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Browse all', 'om-catalog' ),
				'condition'   => array( 'end_screen' => 'yes' ),
			)
		);

		$this->add_control(
			'browse_url',
			array(
				'label'       => __( '"Browse all" link', 'om-catalog' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => home_url( '/engagement-rings/' ),
				'description' => __( 'Empty: the search results page for this line (Settings > OM Catalog > Search), if one is set; otherwise the button is left out.', 'om-catalog' ),
				'condition'   => array( 'end_screen' => 'yes' ),
			)
		);

		$this->end_controls_section();

		/* ---------- Style: bubbles ---------- */

		$this->start_controls_section( 'section_style_bubbles', array( 'label' => __( 'Bubbles', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );

		$this->add_responsive_control(
			'size',
			array(
				'label'      => __( 'Circle size', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 44, 'max' => 160 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-reels' => '--om-reel-size: {{SIZE}}px;' ),
				'condition'  => array( 'bubble' => 'circle' ),
			)
		);

		$this->add_responsive_control(
			'card_w',
			array(
				'label'      => __( 'Card width', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 70, 'max' => 260 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-reels' => '--om-reel-card-w: {{SIZE}}px;' ),
				'condition'  => array( 'bubble' => 'card' ),
			)
		);

		$this->add_responsive_control(
			'gap',
			array(
				'label'      => __( 'Space between', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 4, 'max' => 48 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-reels' => '--om-reel-gap: {{SIZE}}px;' ),
			)
		);

		$this->add_control( 'ring_a', array( 'label' => __( 'Ring colour 1', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'separator' => 'before', 'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-reel-ring-a: {{VALUE}};' ) ) );
		$this->add_control( 'ring_b', array( 'label' => __( 'Ring colour 2', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-reel-ring-b: {{VALUE}};' ) ) );
		$this->add_control( 'ring_seen', array( 'label' => __( 'Ring once watched', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-reel-seen: {{VALUE}};' ) ) );
		$this->add_control(
			'ring_w',
			array(
				'label'      => __( 'Ring thickness', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 6, 'step' => 0.5 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-reels' => '--om-reel-ring-w: {{SIZE}}px;' ),
			)
		);
		$this->add_control( 'label_color', array( 'label' => __( 'Label colour', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'separator' => 'before', 'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-reel-label: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'label_typo', 'label' => __( 'Label typography', 'om-catalog' ), 'selector' => '{{WRAPPER}} .om-reel-label' ) );
		$this->add_control( 'heading_color', array( 'label' => __( 'Heading colour', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'separator' => 'before', 'selectors' => array( '{{WRAPPER}} .om-reels-heading' => 'color: {{VALUE}};' ) ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'heading_typo', 'label' => __( 'Heading typography', 'om-catalog' ), 'selector' => '{{WRAPPER}} .om-reels-heading' ) );

		$this->end_controls_section();

		/* ---------- Style: player ---------- */

		$this->start_controls_section( 'section_style_player', array( 'label' => __( 'Player', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );

		$this->add_control( 'backdrop', array( 'label' => __( 'Backdrop (desktop)', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-rv-backdrop: {{VALUE}};' ) ) );
		$this->add_control( 'cta_bg', array( 'label' => __( 'Button background', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-rv-cta-bg: {{VALUE}};' ) ) );
		$this->add_control( 'cta_bg_hover', array( 'label' => __( 'Button background (hover)', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-rv-cta-bg-hover: {{VALUE}};' ) ) );
		$this->add_control( 'cta_fg', array( 'label' => __( 'Button text', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-reels' => '--om-rv-cta-fg: {{VALUE}};' ) ) );
		$this->add_control(
			'cta_radius',
			array(
				'label'      => __( 'Button corner radius', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-reels' => '--om-rv-cta-radius: {{SIZE}}px;' ),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo OM_Reels::instance()->render( // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the renderer.
			array(
				'source'      => (string) ( $s['source'] ?? 'line' ),
				'line'        => (string) ( $s['line'] ?? 'engagement-rings' ),
				'style'       => (string) ( $s['style'] ?? '' ),
				'shape'       => (string) ( $s['shape'] ?? '' ),
				'styles'      => (string) ( $s['styles'] ?? '' ),
				'count'       => (int) ( $s['count'] ?? 8 ),
				'bubble'      => (string) ( $s['bubble'] ?? 'circle' ),
				'label'       => (string) ( $s['label'] ?? 'title' ),
				'show_on'     => (string) ( $s['show_on'] ?? 'all' ),
				'heading'     => (string) ( $s['heading'] ?? '' ),
				'show_price'  => 'yes' === ( $s['show_price'] ?? 'yes' ) ? 'yes' : '',
				'show_style'  => 'yes' === ( $s['show_style'] ?? 'yes' ) ? 'yes' : '',
				'button_text' => (string) ( $s['button_text'] ?? '' ),
				'duration'    => (int) ( $s['duration'] ?? 8 ),
				'max_length'  => (int) ( $s['max_length'] ?? 15 ),
				'sound'       => 'yes' === ( $s['sound'] ?? '' ) ? 'yes' : '',
				'auto_next'   => 'yes' === ( $s['auto_next'] ?? 'yes' ) ? 'yes' : '',
				'colors'      => 'yes' === ( $s['colors'] ?? 'yes' ) ? 'yes' : '',
				'end_screen'  => 'yes' === ( $s['end_screen'] ?? 'yes' ) ? 'yes' : '',
				'more_title'  => (string) ( $s['more_title'] ?? '' ),
				'browse_text' => (string) ( $s['browse_text'] ?? '' ),
				'browse_url'  => (string) ( $s['browse_url']['url'] ?? '' ),
			)
		);
	}
}

/**
 * OM Saved Designs: a heart with the count of saved designs, for a header.
 * Opens the Saved panel (compare, share, email the list).
 */
class OM_Elementor_Saved_Widget extends Widget_Base {

	public function get_name() {
		return 'om_saved_widget';
	}

	public function get_title() {
		return __( 'OM Saved Designs', 'om-catalog' );
	}

	public function get_icon() {
		return 'eicon-heart-o';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'saved', 'wishlist', 'favourites', 'favorites', 'heart', 'jewelry' );
	}

	public function get_style_depends() {
		return array( 'om-catalog-css' );
	}

	public function get_script_depends() {
		return array( 'om-catalog-js' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array( 'label' => __( 'Saved designs', 'om-catalog' ) ) );
		$this->add_control(
			'text',
			array(
				'label'       => __( 'Text', 'om-catalog' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Saved', 'om-catalog' ),
				'description' => __( 'Opens the Saved panel. Any link to #om-saved (e.g. in a menu) does the same. Turn the whole feature on or off in Settings > OM Catalog > Look & feel.', 'om-catalog' ),
			)
		);
		$this->add_control( 'show_text', array( 'label' => __( 'Show the text', 'om-catalog' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
		$this->add_control( 'show_count', array( 'label' => __( 'Show the count', 'om-catalog' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
		$this->add_responsive_control(
			'align',
			array(
				'label'     => __( 'Alignment', 'om-catalog' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array( 'title' => __( 'Left', 'om-catalog' ), 'icon' => 'eicon-text-align-left' ),
					'center'     => array( 'title' => __( 'Center', 'om-catalog' ), 'icon' => 'eicon-text-align-center' ),
					'flex-end'   => array( 'title' => __( 'Right', 'om-catalog' ), 'icon' => 'eicon-text-align-right' ),
				),
				'selectors' => array( '{{WRAPPER}} .om-saved-open-wrap' => 'justify-content: {{VALUE}};' ),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section( 'section_style', array( 'label' => __( 'Button', 'om-catalog' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'color', array( 'label' => __( 'Colour', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-saved-open.om-saved-open' => 'color: {{VALUE}};', '{{WRAPPER}} .om-saved-open .om-save-icon' => 'background-color: {{VALUE}};' ) ) );
		$this->add_control( 'count_bg', array( 'label' => __( 'Count background', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-saved-count' => 'background-color: {{VALUE}};' ) ) );
		$this->add_control( 'count_color', array( 'label' => __( 'Count text', 'om-catalog' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .om-saved-count' => 'color: {{VALUE}};' ) ) );
		$this->add_responsive_control(
			'icon_size',
			array(
				'label'      => __( 'Heart size', 'om-catalog' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 12, 'max' => 40 ) ),
				'selectors'  => array( '{{WRAPPER}} .om-saved-open .om-save-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'typo', 'selector' => '{{WRAPPER}} .om-saved-open-text' ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$html = OM_Saved::render_button(
			array(
				'text'       => (string) ( $s['text'] ?? '' ),
				'show_text'  => 'yes' === ( $s['show_text'] ?? 'yes' ) ? 'yes' : 'no',
				'show_count' => 'yes' === ( $s['show_count'] ?? 'yes' ) ? 'yes' : 'no',
			)
		);
		if ( '' === $html && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			$html = '<p>' . esc_html__( 'Saved designs is off in Settings > OM Catalog > Look & feel.', 'om-catalog' ) . '</p>';
		}
		echo '<div class="om-saved-open-wrap">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the renderer.
	}
}
