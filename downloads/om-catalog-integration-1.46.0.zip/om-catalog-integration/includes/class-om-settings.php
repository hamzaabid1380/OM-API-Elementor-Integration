<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OM_Settings {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_notices', array( $this, 'maybe_show_markup_notice' ) );
		add_action( 'admin_notices', array( $this, 'maybe_show_api_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// New credentials take effect immediately: drop the cached token and
		// any remembered login failure.
		foreach ( array( 'om_client_id', 'om_client_secret' ) as $option ) {
			add_action( 'add_option_' . $option, array( 'OM_API_Client', 'clear_auth_cache' ) );
			add_action( 'update_option_' . $option, array( 'OM_API_Client', 'clear_auth_cache' ) );
		}
	}

	public function add_settings_page() {
		add_options_page(
			'OM Catalog Settings',
			'OM Catalog',
			'manage_options',
			'om-catalog-settings',
			array( $this, 'render_settings_page' )
		);
	}

	public function register_settings() {
		// Credentials.
		register_setting( 'om_catalog_settings', 'om_client_id', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_client_secret', array( 'sanitize_callback' => array( $this, 'sanitize_secret' ) ) );

		// Pricing markup.
		register_setting( 'om_catalog_settings', 'om_markup_type', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_markup_value', array( 'sanitize_callback' => array( $this, 'sanitize_float' ) ) );

		// What shows instead of a price (built-in template, and the widget's default).
		register_setting( 'om_catalog_settings', 'om_price_placeholder', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_price_link', array( 'sanitize_callback' => array( $this, 'sanitize_link' ) ) );

		// Caching.
		register_setting( 'om_catalog_settings', 'om_listing_cache_minutes', array( 'sanitize_callback' => 'absint' ) );

		// Product page layout (0 = built-in template, else an Elementor page ID).
		register_setting( 'om_catalog_settings', 'om_product_layout_page', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'om_catalog_settings', 'om_show_related', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_show_recent', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_show_set', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_back_link', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_set_pairs', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		register_setting( 'om_catalog_settings', 'om_options_style', array( 'sanitize_callback' => array( $this, 'sanitize_options_style' ) ) );
		register_setting( 'om_catalog_settings', 'om_details_style', array( 'sanitize_callback' => array( $this, 'sanitize_details_style' ) ) );
		register_setting( 'om_catalog_settings', 'om_video_mode', array( 'sanitize_callback' => array( $this, 'sanitize_video_mode' ) ) );
		register_setting( 'om_catalog_settings', 'om_media_follow', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_size_lines', array( 'sanitize_callback' => array( $this, 'sanitize_lines' ) ) );
		register_setting( 'om_catalog_settings', 'om_size_guide_note', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		register_setting( 'om_catalog_settings', 'om_warm_cache', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );

		// Loose diamonds: own markup (falls back to the jewelry markup).
		register_setting( 'om_catalog_settings', 'om_diamond_markup_type', array( 'sanitize_callback' => 'sanitize_key' ) );
		register_setting( 'om_catalog_settings', 'om_diamond_markup_value', array( 'sanitize_callback' => array( $this, 'sanitize_float' ) ) );

		// Ring builder.
		// A page ID; 0 = find the page with the builder on it; -1 = builder off.
		register_setting( 'om_catalog_settings', 'om_builder_page', array( 'sanitize_callback' => static function ( $v ) { return (int) $v < 0 ? -1 : absint( $v ); } ) );
		register_setting( 'om_catalog_settings', 'om_true_size', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_true_size_check', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_builder_lines', array( 'sanitize_callback' => array( $this, 'sanitize_lines' ) ) );

		// Inquiries.
		register_setting( 'om_catalog_settings', 'om_inquiry_email', array( 'sanitize_callback' => 'sanitize_email' ) );
		register_setting( 'om_catalog_settings', 'om_inquiry_success', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_inquiry_subjects', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		register_setting( 'om_catalog_settings', 'om_inquiry_subject_field', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_inquiry_subject_tpl', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_inquiry_fields', array( 'sanitize_callback' => array( 'OM_Inquiry', 'normalize_fields' ) ) );
		register_setting( 'om_catalog_settings', 'om_inquiry_autoreply', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_inquiry_autoreply_text', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );

		// Inquiry form or booking calendar (SimplyBook.me).
		register_setting( 'om_catalog_settings', 'om_booking_default', array( 'sanitize_callback' => static function ( $v ) { return in_array( $v, OM_Booking::MODES, true ) ? $v : 'form'; } ) );
		register_setting( 'om_catalog_settings', 'om_booking_places', array( 'sanitize_callback' => array( 'OM_Booking', 'sanitize_places' ) ) );
		register_setting( 'om_catalog_settings', 'om_booking_code', array( 'sanitize_callback' => array( $this, 'sanitize_booking_code' ) ) );
		register_setting( 'om_catalog_settings', 'om_booking_first', array( 'sanitize_callback' => static function ( $v ) { return 'form' === $v ? 'form' : 'booking'; } ) );
		foreach ( array( 'om_booking_tab_book', 'om_booking_tab_form' ) as $booking_label ) {
			register_setting( 'om_catalog_settings', $booking_label, array( 'sanitize_callback' => static function ( $v ) { return mb_substr( sanitize_text_field( (string) $v ), 0, 40 ); } ) );
		}
		register_setting( 'om_catalog_settings', 'om_booking_intro', array( 'sanitize_callback' => static function ( $v ) { return mb_substr( sanitize_text_field( (string) $v ), 0, 200 ); } ) );
		register_setting( 'om_catalog_settings', 'om_product_inquiry_position', array( 'sanitize_callback' => static function ( $v ) { return 'end' === $v ? 'end' : 'buttons'; } ) );

		// Brand colors / fonts.
		register_setting( 'om_catalog_settings', 'om_style_source', array( 'sanitize_callback' => array( $this, 'sanitize_style_source' ) ) );
		register_setting( 'om_catalog_settings', 'om_color_primary', array( 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'om_catalog_settings', 'om_color_accent', array( 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'om_catalog_settings', 'om_color_background', array( 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'om_catalog_settings', 'om_color_text', array( 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'om_catalog_settings', 'om_font_heading', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_font_body', array( 'sanitize_callback' => 'sanitize_text_field' ) );

		// Look & feel (1.11): one set of corners, spacing, hover and phone
		// type sizes for every widget.
		foreach ( array( 'om_radius', 'om_radius_lg', 'om_m_title', 'om_m_card_title', 'om_m_body' ) as $opt ) {
			register_setting( 'om_catalog_settings', $opt, array( 'sanitize_callback' => array( $this, 'sanitize_px' ) ) );
		}
		register_setting( 'om_catalog_settings', 'om_spacing', array( 'sanitize_callback' => array( $this, 'sanitize_spacing' ) ) );
		register_setting( 'om_catalog_settings', 'om_card_hover', array( 'sanitize_callback' => array( $this, 'sanitize_card_hover' ) ) );
		register_setting( 'om_catalog_settings', 'om_design', array( 'sanitize_callback' => static function ( $v ) { return in_array( $v, array( 'refined', 'modern', 'classic' ), true ) ? $v : 'refined'; } ) );
		register_setting( 'om_catalog_settings', 'om_button_shape', array( 'sanitize_callback' => static function ( $v ) { return in_array( $v, array( 'pill', 'soft', 'square' ), true ) ? $v : 'pill'; } ) );
		register_setting( 'om_catalog_settings', 'om_color_gold', array( 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'om_catalog_settings', 'om_color_gold_light', array( 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'om_catalog_settings', 'om_photo_tone', array( 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'om_catalog_settings', 'om_photo_blend', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_page_transitions', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_saved', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_saved_email', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_saved_float', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		// Drop a hint (1.39).
		register_setting( 'om_catalog_settings', 'om_hint', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_hint_label', array( 'sanitize_callback' => static function ( $v ) { return mb_substr( sanitize_text_field( (string) $v ), 0, 40 ); } ) );
		register_setting( 'om_catalog_settings', 'om_hint_promise', array( 'sanitize_callback' => static function ( $v ) { return mb_substr( sanitize_text_field( (string) $v ), 0, 160 ); } ) );
		// CRM (1.36).
		register_setting( 'om_catalog_settings', 'om_crm_mode', array( 'sanitize_callback' => static function ( $v ) { return in_array( $v, array( 'off', 'ghl', 'webhook', 'both' ), true ) ? $v : 'off'; } ) );
		register_setting( 'om_catalog_settings', 'om_crm_ghl_token', array( 'sanitize_callback' => static function ( $v ) { $v = trim( (string) $v ); return '' === $v ? (string) get_option( 'om_crm_ghl_token', '' ) : $v; } ) );
		foreach ( array( 'om_crm_ghl_location', 'om_crm_ghl_pipeline', 'om_crm_ghl_stage', 'om_crm_tags', 'om_crm_source', 'om_crm_webhook_secret' ) as $crm_opt ) {
			register_setting( 'om_catalog_settings', $crm_opt, array( 'sanitize_callback' => 'sanitize_text_field' ) );
		}
		register_setting( 'om_catalog_settings', 'om_crm_webhook', array( 'sanitize_callback' => 'esc_url_raw' ) );
		foreach ( array( 'inquiry', 'saved', 'design', 'hint' ) as $crm_ev ) {
			register_setting( 'om_catalog_settings', 'om_crm_ev_' . $crm_ev, array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		}
		register_setting( 'om_catalog_settings', 'om_crm_ghl_fields_on', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_menu_selector', array( 'sanitize_callback' => static function ( $v ) { return mb_substr( trim( wp_strip_all_tags( (string) $v ) ), 0, 300 ); } ) );
		register_setting( 'om_catalog_settings', 'om_analytics', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		// Emails.
		foreach ( array_keys( OM_Emails::notifications() ) as $email_id ) {
			register_setting( 'om_catalog_settings', 'om_email_' . $email_id, array( 'sanitize_callback' => array( 'OM_Emails', 'sanitize_email_settings' ) ) );
		}
		register_setting( 'om_catalog_settings', OM_Emails::DESIGN, array( 'sanitize_callback' => array( 'OM_Emails', 'sanitize_design' ) ) );
		// AI assistant.
		register_setting( 'om_catalog_settings', 'om_ai_enabled', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_ai_provider', array( 'sanitize_callback' => static function ( $v ) { return in_array( $v, array( 'openrouter', 'gemini', 'claude' ), true ) ? $v : 'openrouter'; } ) );
		foreach ( array( 'openrouter', 'gemini', 'claude' ) as $ai ) {
			// Keys are never printed back: an empty field keeps the saved one.
			register_setting( 'om_catalog_settings', 'om_ai_key_' . $ai, array( 'sanitize_callback' => static function ( $v ) use ( $ai ) { $v = trim( sanitize_text_field( (string) $v ) ); return '' === $v ? (string) get_option( 'om_ai_key_' . $ai, '' ) : ( '-' === $v ? '' : $v ); } ) );
		}
		register_setting( 'om_catalog_settings', 'om_ai_models_openrouter', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_model_gemini', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_model_claude', array( 'sanitize_callback' => static function ( $v ) { return isset( OM_Assistant::CLAUDE_MODELS[ $v ] ) ? $v : 'claude-opus-5-5'; } ) );
		register_setting( 'om_catalog_settings', 'om_ai_name', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_launcher', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_greeting', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_chips', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_about', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_show', array( 'sanitize_callback' => static function ( $v ) { return in_array( $v, array( 'all', 'home' ), true ) ? $v : 'catalog'; } ) );
		register_setting( 'om_catalog_settings', 'om_ai_starter', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_starter_delay', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'om_catalog_settings', 'om_ai_side', array( 'sanitize_callback' => static function ( $v ) { return 'left' === $v ? 'left' : 'right'; } ) );
		register_setting( 'om_catalog_settings', 'om_ai_offset_x', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'om_catalog_settings', 'om_ai_offset_y', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'om_catalog_settings', 'om_ai_mini', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		// 1.35: branding and what the assistant knows.
		register_setting( 'om_catalog_settings', 'om_ai_logo', array( 'sanitize_callback' => 'esc_url_raw' ) );
		register_setting( 'om_catalog_settings', 'om_ai_color', array( 'sanitize_callback' => static function ( $v ) { return (string) sanitize_hex_color( (string) $v ); } ) );
		register_setting( 'om_catalog_settings', 'om_ai_accent', array( 'sanitize_callback' => static function ( $v ) { return (string) sanitize_hex_color( (string) $v ); } ) );
		register_setting( 'om_catalog_settings', 'om_ai_subtitle', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_ai_launcher_icon', array( 'sanitize_callback' => static function ( $v ) { return 'logo' === $v ? 'logo' : 'spark'; } ) );
		foreach ( array( 'om_ai_src_details', 'om_ai_src_diamonds', 'om_ai_src_site', 'om_ai_prices' ) as $flag ) {
			register_setting( 'om_catalog_settings', $flag, array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		}
		register_setting( 'om_catalog_settings', 'om_ai_site_types', array( 'sanitize_callback' => static function ( $v ) { return implode( ',', array_intersect( array_map( 'sanitize_key', (array) $v ), array( 'page', 'post' ) ) ); } ) );
		register_setting( 'om_catalog_settings', 'om_ai_site_exclude', array( 'sanitize_callback' => static function ( $v ) { return implode( ',', array_filter( array_map( 'absint', preg_split( '/[\s,]+/', (string) $v ) ) ) ); } ) );
		register_setting( 'om_catalog_settings', 'om_ai_hourly', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'om_catalog_settings', 'om_ai_daily', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'om_catalog_settings', 'om_analytics_meta', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_trust_line', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_popular_searches', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'om_catalog_settings', 'om_track_searches', array( 'sanitize_callback' => array( $this, 'sanitize_flag' ) ) );
		register_setting( 'om_catalog_settings', 'om_search_results_page', array( 'sanitize_callback' => 'absint' ) );
	}

	/**
	 * The SimplyBook widget code. The page shows the calendar that is set up
	 * rather than the code (so saving never resends script tags, which some
	 * firewalls block): an empty box keeps the current one, "Remove" clears
	 * it, and code that isn't a SimplyBook widget is refused.
	 */
	public function sanitize_booking_code( $value ) {
		$current = (string) get_option( 'om_booking_code', OM_Booking::DEFAULT_CODE );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- options.php has checked the settings nonce.
		if ( ! empty( $_POST['om_booking_code_remove'] ) ) {
			return '';
		}
		$value = mb_substr( trim( str_replace( "\0", '', (string) $value ) ), 0, 8000 );
		if ( '' === $value ) {
			return $current;
		}
		if ( ! OM_Booking::parse( $value ) ) {
			add_settings_error( 'om_booking_code', 'om_booking_code', __( 'That isn’t a SimplyBook widget code or address, so the booking calendar was left as it was. Paste the code SimplyBook gives for its calendar widget, or just your SimplyBook address (https://yourname.simplybook.me).', 'om-catalog' ) );
			return $current;
		}
		return $value;
	}

	/**
	 * The secret is stored exactly as entered (only surrounding whitespace
	 * trimmed): sanitize_text_field() would silently drop "%xx" sequences
	 * and anything between < and >, corrupting a valid secret. It is never
	 * printed back into the page, so an empty submission means "keep the
	 * saved one".
	 */
	public function sanitize_secret( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return (string) get_option( 'om_client_secret', '' );
		}
		return $value;
	}

	/** Allow tel:, mailto: and normal URLs (esc_url_raw keeps those protocols). */
	public function sanitize_link( $value ) {
		return esc_url_raw( trim( (string) $value ) );
	}

	public function sanitize_options_style( $value ) {
		return in_array( $value, array( 'swatches', 'pills', 'dropdowns' ), true ) ? $value : 'swatches';
	}

	/** A pixel size 0–60, or '' for the default. */
	public function sanitize_px( $value ) {
		return '' === trim( (string) $value ) ? '' : (string) max( 0, min( 60, (int) $value ) );
	}

	public function sanitize_spacing( $value ) {
		return in_array( $value, array( 'compact', 'comfortable', 'airy' ), true ) ? $value : 'comfortable';
	}

	public function sanitize_card_hover( $value ) {
		return in_array( $value, array( 'lift', 'zoom', 'none' ), true ) ? $value : 'lift';
	}

	public function sanitize_video_mode( $value ) {
		return 'thumb' === $value ? 'thumb' : 'first';
	}

	public function sanitize_details_style( $value ) {
		return 'open' === $value ? 'open' : 'accordion';
	}

	public function sanitize_flag( $value ) {
		return $value ? '1' : '0';
	}

	public function sanitize_lines( $value ) {
		return implode( ',', array_filter( array_map( 'sanitize_title', explode( ',', (string) $value ) ) ) );
	}

	public function sanitize_style_source( $value ) {
		return 'custom' === $value ? 'custom' : 'kit';
	}

	/** Published pages, for the page pickers. */
	private function page_options( $name, $selected, $only_elementor = false ) {
		$args = array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);
		if ( $only_elementor ) {
			$args['meta_key']   = '_elementor_edit_mode'; // phpcs:ignore WordPress.DB.SlowDBQuery
			$args['meta_value'] = 'builder'; // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		foreach ( get_posts( $args ) as $page ) {
			printf( '<option value="%d" %s>%s</option>', (int) $page->ID, selected( (int) $selected, (int) $page->ID, false ), esc_html( $page->post_title ) );
		}
	}

	public function sanitize_float( $value ) {
		return is_numeric( $value ) ? floatval( $value ) : 0;
	}

	/** Warn admins in wp-admin if no markup has been configured yet (price would show as raw wholesale). */
	public function maybe_show_markup_notice() {
		$value = get_option( 'om_markup_value', null );
		if ( null === $value || '' === $value || 0 == $value ) {
			echo '<div class="notice notice-warning"><p><strong>OM Catalog:</strong> No pricing markup is configured yet. Prices from the API are wholesale — go to <a href="' . esc_url( admin_url( 'options-general.php?page=om-catalog-settings' ) ) . '">Settings &gt; OM Catalog</a> and set a markup before showing prices to customers.</p></div>';
		}
	}

	/**
	 * Calls to Overnight Mountings are failing right now: say so to admins
	 * (the site keeps showing its last saved copies meanwhile).
	 */
	public function maybe_show_api_notice() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'OM_API_Client' ) ) {
			return;
		}
		$st = OM_API_Client::status();
		if ( ! $st['failing'] || time() - $st['err_at'] > DAY_IN_SECONDS ) {
			return;
		}
		echo '<div class="notice notice-error"><p><strong>OM Catalog:</strong> calls to Overnight Mountings are failing (' . esc_html( human_time_diff( $st['err_at'] ) ) . ' ago): ' . esc_html( $st['err_msg'] ?? '' ) . '</p><p>Pages already visited keep showing their last saved copy (up to a week old); prices and diamonds can\'t load until it\'s fixed. <a href="' . esc_url( admin_url( 'options-general.php?page=om-catalog-settings#tools' ) ) . '">Test the connection</a></p></div>';
	}

	/** The settings screen's own look (tabs, cards, switches) and script. */
	public function enqueue_assets( $hook ) {
		if ( 'settings_page_om-catalog-settings' !== $hook ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'om-admin', OM_CATALOG_URL . 'assets/css/om-admin.css', array(), OM_CATALOG_VERSION );
		wp_enqueue_script( 'om-admin', OM_CATALOG_URL . 'assets/js/om-admin.js', array(), OM_CATALOG_VERSION, true );
	}

	/**
	 * At-a-glance status for the top of the settings screen: each item is
	 * [ state (ok|warn|off), label, detail, tab or URL ].
	 */
	private function status_items() {
		$items = array();
		if ( ! get_option( 'om_client_id' ) || ! get_option( 'om_client_secret' ) ) {
			$items[] = array( 'warn', __( 'Overnight Mountings', 'om-catalog' ), __( 'Add your API details', 'om-catalog' ), '#connection' );
		} elseif ( get_transient( OM_API_Client::AUTH_FAIL_TRANSIENT ) ) {
			$items[] = array( 'warn', __( 'Overnight Mountings', 'om-catalog' ), __( 'Sign-in failed — see Tools', 'om-catalog' ), '#tools' );
		} elseif ( OM_API_Client::status()['failing'] ) {
			$items[] = array( 'warn', __( 'Overnight Mountings', 'om-catalog' ), __( 'Calls failing — see Tools', 'om-catalog' ), '#tools' );
		} elseif ( get_transient( OM_API_Client::TOKEN_TRANSIENT ) ) {
			$items[] = array( 'ok', __( 'Overnight Mountings', 'om-catalog' ), __( 'Connected', 'om-catalog' ), '#connection' );
		} else {
			$items[] = array( 'off', __( 'Overnight Mountings', 'om-catalog' ), __( 'Set up — not used yet', 'om-catalog' ), '#tools' );
		}
		$priced  = function_exists( 'om_markup_is_configured' ) && om_markup_is_configured();
		$items[] = $priced ? array( 'ok', __( 'Prices', 'om-catalog' ), __( 'Shown with your markup', 'om-catalog' ), '#pricing' ) : array( 'off', __( 'Prices', 'om-catalog' ), __( 'Hidden — "call for pricing"', 'om-catalog' ), '#pricing' );
		$builder = om_builder_page_id();
		$items[] = $builder ? array( 'ok', __( 'Ring builder', 'om-catalog' ), get_the_title( $builder ), '#builder' ) : array( 'off', __( 'Ring builder', 'om-catalog' ), (int) get_option( 'om_builder_page', 0 ) < 0 ? __( 'Turned off', 'om-catalog' ) : __( 'No builder page yet', 'om-catalog' ), '#builder' );
		$week    = new WP_Query(
			array(
				'post_type'      => 'om_inquiry',
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
				'date_query'     => array( array( 'after' => '7 days ago' ) ),
			)
		);
		/* translators: %d: number of inquiries. */
		$items[] = array( $week->found_posts ? 'ok' : 'off', __( 'Inquiries', 'om-catalog' ), sprintf( _n( '%d this week', '%d this week', $week->found_posts, 'om-catalog' ), $week->found_posts ), admin_url( 'edit.php?post_type=om_inquiry' ) );
		$ai_today = OM_Assistant::usage_today();
		/* translators: %d: answers. */
		$items[]  = OM_Assistant::enabled() ? array( OM_Assistant::key() ? 'ok' : 'warn', __( 'AI assistant', 'om-catalog' ), OM_Assistant::key() ? sprintf( _n( 'On · %d answer today', 'On · %d answers today', $ai_today['n'], 'om-catalog' ), $ai_today['n'] ) : __( 'On — add an API key', 'om-catalog' ), '#assistant' ) : array( 'off', __( 'AI assistant', 'om-catalog' ), __( 'Off', 'om-catalog' ), '#assistant' );
		$items[] = '0' !== get_option( 'om_analytics', '1' ) ? array( 'ok', __( 'Analytics events', 'om-catalog' ), __( 'On', 'om-catalog' ), '#search' ) : array( 'off', __( 'Analytics events', 'om-catalog' ), __( 'Off', 'om-catalog' ), '#search' );
		return $items;
	}

	/** Settings > OM Catalog > Inquiries: the inquiry form, the SimplyBook calendar, or both. */
	private function render_booking_section() {
		$setup   = OM_Booking::setup();
		$default = OM_Booking::default_mode();
		$places  = OM_Booking::place_modes();
		$modes   = array(
			'form'    => array( __( 'Inquiry form', 'om-catalog' ), __( 'The form you have now. It sends you the piece they were looking at, and saves it under Inquiries.', 'om-catalog' ) ),
			'booking' => array( __( 'Booking calendar', 'om-catalog' ), __( 'Your SimplyBook.me calendar, so they pick a day and time themselves.', 'om-catalog' ) ),
			'both'    => array( __( 'Both, as two tabs', 'om-catalog' ), __( '“Book an appointment” and “Send a message”, side by side.', 'om-catalog' ) ),
		);
		$host    = $setup ? (string) wp_parse_url( $setup['page'], PHP_URL_HOST ) : '';
		?>
		<p class="description"><?php esc_html_e( 'What visitors see wherever the site offers to get in touch. Every place can follow the choice below or have its own. Without a calendar set up, every place shows the inquiry form.', 'om-catalog' ); ?></p>
		<table class="form-table om-booking-settings">
			<tr>
				<th><?php esc_html_e( 'Show visitors', 'om-catalog' ); ?></th>
				<td>
					<fieldset>
						<?php foreach ( $modes as $key => $mode ) : ?>
							<label class="om-booking-mode"><input type="radio" name="om_booking_default" value="<?php echo esc_attr( $key ); ?>" <?php checked( $default, $key ); ?> /> <strong><?php echo esc_html( $mode[0] ); ?></strong> <span class="description"><?php echo esc_html( $mode[1] ); ?></span></label><br />
						<?php endforeach; ?>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Place by place', 'om-catalog' ); ?></th>
				<td>
					<table class="widefat striped om-booking-places">
						<tbody>
							<?php foreach ( OM_Booking::places() as $place => $label ) : ?>
								<tr>
									<td><label for="om-booking-place-<?php echo esc_attr( $place ); ?>"><?php echo esc_html( $label ); ?></label></td>
									<td>
										<select id="om-booking-place-<?php echo esc_attr( $place ); ?>" name="om_booking_places[<?php echo esc_attr( $place ); ?>]">
											<option value="" <?php selected( $places[ $place ], '' ); ?>><?php esc_html_e( 'Same as above', 'om-catalog' ); ?></option>
											<?php foreach ( $modes as $key => $mode ) : ?>
												<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $places[ $place ], $key ); ?>><?php echo esc_html( $mode[0] ); ?></option>
											<?php endforeach; ?>
										</select>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<p class="description"><?php esc_html_e( 'The ring builder and the assistant send you what the customer designed or asked. The calendar alone can’t, so “Both” suits them best. An OM Single Product widget can also choose for its own page.', 'om-catalog' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'On product pages', 'om-catalog' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text"><?php esc_html_e( 'Where the form or calendar goes on product pages', 'om-catalog' ); ?></legend>
						<label><input type="radio" name="om_product_inquiry_position" value="buttons" <?php checked( OM_Booking::product_position(), 'buttons' ); ?> /> <?php esc_html_e( 'Right under the buttons (such as “Call us”)', 'om-catalog' ); ?></label><br />
						<label><input type="radio" name="om_product_inquiry_position" value="end" <?php checked( OM_Booking::product_position(), 'end' ); ?> /> <?php esc_html_e( 'At the end of the product details', 'om-catalog' ); ?></label>
					</fieldset>
					<p class="description"><?php esc_html_e( 'Where the form or calendar box sits. An OM Single Product widget can also choose (Ring Builder & Inquiry › Where on the page).', 'om-catalog' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="om_booking_code"><?php esc_html_e( 'SimplyBook calendar', 'om-catalog' ); ?></label></th>
				<td><div data-om-live="booking-calendar">
					<?php if ( $setup ) : ?>
						<p class="om-booking-status is-ok"><span class="om-admin-dot" aria-hidden="true"></span>
							<?php
							/* translators: %s: SimplyBook address, e.g. yourname.simplybook.me. */
							echo esc_html( sprintf( __( 'Calendar set up: %s', 'om-catalog' ), $host ) );
							?>
							· <a href="<?php echo esc_url( $setup['page'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open the booking page', 'om-catalog' ); ?></a></p>
					<?php else : ?>
						<p class="om-booking-status is-off"><span class="om-admin-dot" aria-hidden="true"></span><?php esc_html_e( 'No calendar yet: every place shows the inquiry form.', 'om-catalog' ); ?></p>
					<?php endif; ?>
					<details class="om-booking-change"<?php echo $setup ? '' : ' open'; ?>>
						<summary><?php echo $setup ? esc_html__( 'Change the calendar', 'om-catalog' ) : esc_html__( 'Add a calendar', 'om-catalog' ); ?></summary>
						<textarea id="om_booking_code" name="om_booking_code" rows="5" class="large-text code" placeholder="<?php esc_attr_e( 'Paste the widget code from SimplyBook, or just your SimplyBook address, e.g. https://yourname.simplybook.me', 'om-catalog' ); ?>"></textarea>
						<p class="description"><?php esc_html_e( 'In SimplyBook, open the widgets for your booking website and copy the code of the calendar (iframe) widget. Only its settings are used: your address, colours and calendar layout. The calendar loads from SimplyBook when it comes into view. Leave the box empty to keep the current calendar.', 'om-catalog' ); ?></p>
						<?php if ( $setup ) : ?>
							<label><input type="checkbox" name="om_booking_code_remove" value="1" /> <?php esc_html_e( 'Remove the calendar (every place goes back to the inquiry form)', 'om-catalog' ); ?></label>
						<?php endif; ?>
					</details>
				</div></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'With both', 'om-catalog' ); ?></th>
				<td>
					<p><label><?php esc_html_e( 'Calendar tab', 'om-catalog' ); ?> <input type="text" name="om_booking_tab_book" value="<?php echo esc_attr( get_option( 'om_booking_tab_book', '' ) ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'Book an appointment', 'om-catalog' ); ?>" /></label></p>
					<p><label><?php esc_html_e( 'Form tab', 'om-catalog' ); ?> <input type="text" name="om_booking_tab_form" value="<?php echo esc_attr( get_option( 'om_booking_tab_form', '' ) ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'Send a message', 'om-catalog' ); ?>" /></label></p>
					<fieldset><legend class="screen-reader-text"><?php esc_html_e( 'Open first', 'om-catalog' ); ?></legend>
						<?php esc_html_e( 'Open first:', 'om-catalog' ); ?>
						<label><input type="radio" name="om_booking_first" value="booking" <?php checked( OM_Booking::first(), 'booking' ); ?> /> <?php esc_html_e( 'the calendar', 'om-catalog' ); ?></label>
						<label><input type="radio" name="om_booking_first" value="form" <?php checked( OM_Booking::first(), 'form' ); ?> /> <?php esc_html_e( 'the form', 'om-catalog' ); ?></label>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th><label for="om_booking_intro"><?php esc_html_e( 'Line above the calendar', 'om-catalog' ); ?></label></th>
				<td><input type="text" id="om_booking_intro" name="om_booking_intro" value="<?php echo esc_attr( OM_Booking::intro() ); ?>" class="large-text" />
				<p class="description"><?php esc_html_e( 'Empty: no line. Under it, product pages add the style number to mention when booking. The calendar can also go on any page with the shortcode [om_booking_calendar].', 'om-catalog' ); ?></p></td>
			</tr>
		</table>
		<?php
	}

	public function render_settings_page() {
		?>
		<div class="wrap om-admin">
			<header class="om-admin-head">
				<div class="om-admin-brand">
					<span class="om-admin-mark" aria-hidden="true"></span>
					<div>
						<h1>OM Catalog</h1>
						<p><?php echo esc_html( sprintf( /* translators: %s: version. */ __( 'Overnight Mountings for your site · version %s', 'om-catalog' ), OM_CATALOG_VERSION ) ); ?></p>
					</div>
				</div>
				<div class="om-admin-head-links">
					<a class="om-admin-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=om-insights' ) ); ?>"><?php esc_html_e( 'Insights', 'om-catalog' ); ?></a>
					<a class="om-admin-btn" href="<?php echo esc_url( admin_url( 'edit.php?post_type=om_inquiry' ) ); ?>"><?php esc_html_e( 'Inquiries', 'om-catalog' ); ?></a>
				</div>
			</header>
			<hr class="wp-header-end" />
			<ul class="om-admin-status" data-om-live="status" aria-label="<?php esc_attr_e( 'Status', 'om-catalog' ); ?>">
				<?php foreach ( $this->status_items() as $item ) : ?>
					<li class="is-<?php echo esc_attr( $item[0] ); ?>"><a href="<?php echo esc_url( $item[3] ); ?>"<?php echo 0 === strpos( $item[3], '#' ) ? ' data-om-go="' . esc_attr( substr( $item[3], 1 ) ) . '"' : ''; ?>><span class="om-admin-dot" aria-hidden="true"></span><span class="om-admin-status-label"><?php echo esc_html( $item[1] ); ?></span><span class="om-admin-status-detail"><?php echo esc_html( $item[2] ); ?></span></a></li>
				<?php endforeach; ?>
			</ul>
			<form method="post" action="options.php" class="om-admin-form">
				<?php settings_fields( 'om_catalog_settings' ); ?>

				<h2 class="om-sec" data-om-tab="connection">API Credentials</h2>
				<table class="form-table">
					<tr>
						<th><label for="om_client_id">Client ID (account number)</label></th>
						<td><input type="text" id="om_client_id" name="om_client_id" value="<?php echo esc_attr( get_option( 'om_client_id' ) ); ?>" class="regular-text" placeholder="e.g. R01203" /></td>
					</tr>
					<tr>
						<th><label for="om_client_secret">Client Secret</label></th>
						<td><input type="password" id="om_client_secret" name="om_client_secret" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo get_option( 'om_client_secret' ) ? esc_attr__( 'Saved — leave blank to keep it', 'om-catalog' ) : ''; ?>" />
						<?php $om_secret = (string) get_option( 'om_client_secret', '' ); ?>
						<div data-om-live="secret">
						<?php if ( '' !== $om_secret ) : ?>
							<p class="om-cred-saved" style="margin:6px 0 0;color:#008a20">&#10004; <?php echo esc_html( sprintf( 'Secret saved (%d characters, ending in …%s). This box stays empty on purpose so the secret is never shown on the page.', strlen( $om_secret ), substr( $om_secret, -4 ) ) ); ?></p>
						<?php else : ?>
							<p class="om-cred-saved" style="margin:6px 0 0;color:#b32d2e">&#10008; No secret saved yet.</p>
						<?php endif; ?>
						</div>
						<p class="description">Provided by Overnight Mountings. Type a new one only to replace it; leave it empty to keep the saved one. After saving, run <strong>Tools › Test connection</strong>.</p>
						<p class="description">If Overnight Mountings needs to allow your server, use <strong>Tools › Find my server's IP</strong> — it shows the public address their firewall sees. (The address the server reports about itself is often an internal one, such as 127.0.0.1, which is no use to them.)</p></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="pricing">Pricing Markup</h2>
				<p class="description">The API returns <strong>wholesale</strong> prices. This markup is applied before any price is shown on the site.</p>
				<table class="form-table">
					<tr>
						<th><label for="om_markup_type">Markup Type</label></th>
						<td>
							<select id="om_markup_type" name="om_markup_type">
								<?php $type = get_option( 'om_markup_type', 'percentage' ); ?>
								<option value="percentage" <?php selected( $type, 'percentage' ); ?>>Percentage on top of wholesale</option>
								<option value="multiplier" <?php selected( $type, 'multiplier' ); ?>>Multiplier (e.g. 2.2x wholesale)</option>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="om_markup_value">Markup Value</label></th>
						<td>
							<input type="number" step="0.01" id="om_markup_value" name="om_markup_value" value="<?php echo esc_attr( get_option( 'om_markup_value', '' ) ); ?>" class="small-text" />
							<p class="description">Percentage example: <code>120</code> means retail = wholesale &times; 2.2. Multiplier example: <code>2.2</code> means the same thing directly.</p>
						</td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="pricing">Loose Diamonds</h2>
				<p class="description">Markup for loose diamonds (diamond search and ring builder). Leave the value empty to use the jewelry markup above.</p>
				<table class="form-table">
					<tr>
						<th><label for="om_diamond_markup_type">Markup type</label></th>
						<td>
							<?php $dtype = get_option( 'om_diamond_markup_type', 'multiplier' ); ?>
							<select id="om_diamond_markup_type" name="om_diamond_markup_type">
								<option value="percentage" <?php selected( $dtype, 'percentage' ); ?>>Percentage on top of wholesale</option>
								<option value="multiplier" <?php selected( $dtype, 'multiplier' ); ?>>Multiplier</option>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="om_diamond_markup_value">Markup value</label></th>
						<td><input type="number" step="0.01" id="om_diamond_markup_value" name="om_diamond_markup_value" value="<?php echo esc_attr( get_option( 'om_diamond_markup_value', '' ) ); ?>" class="small-text" /></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="builder">Ring Builder</h2>
				<table class="form-table">
					<tr>
						<th><label for="om_builder_page">Builder page</label></th>
						<td>
							<?php
							$builder_chosen = (int) get_option( 'om_builder_page', 0 );
							$builder_found  = $builder_chosen < 0 ? 0 : om_builder_page_id();
							?>
							<select id="om_builder_page" name="om_builder_page">
								<option value="0" <?php selected( $builder_chosen, 0 ); ?>><?php esc_html_e( 'Find it automatically', 'om-catalog' ); ?></option>
								<option value="-1" <?php selected( $builder_chosen < 0 ); ?>><?php esc_html_e( 'Off (no builder buttons)', 'om-catalog' ); ?></option>
								<?php $this->page_options( 'om_builder_page', $builder_chosen ); ?>
							</select>
							<p class="description">A page containing the <strong>OM Ring Builder</strong> widget or <code>[om_ring_builder]</code>. Product pages of the lines below then show a "Select this setting" button and the diamond search a "Select this diamond" button. "Find it automatically" uses the published page that has the builder on it (one at /ring-builder/ first), so a rebuilt or copied site keeps the buttons.</p>
							<?php if ( $builder_chosen >= 0 ) : ?>
								<p class="description">
									<?php
									if ( $builder_found ) {
										/* translators: %s: page title. */
										echo esc_html( sprintf( __( 'In use: “%s”.', 'om-catalog' ), get_the_title( $builder_found ) ) ) . ' <a href="' . esc_url( get_permalink( $builder_found ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'View', 'om-catalog' ) . '</a>';
									} else {
										esc_html_e( 'No published page has the ring builder yet, so the builder buttons are hidden.', 'om-catalog' );
									}
									?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th><label for="om_builder_lines">Setting product lines</label></th>
						<td><input type="text" id="om_builder_lines" name="om_builder_lines" value="<?php echo esc_attr( get_option( 'om_builder_lines', 'engagement-rings' ) ); ?>" class="regular-text" />
						<p class="description">Comma-separated line codes whose products can be chosen as the setting.</p></td>
					</tr>
					<tr>
						<th>True size</th>
						<td>
							<input type="hidden" name="om_true_size" value="0" />
							<label><input type="checkbox" name="om_true_size" value="1" <?php checked( get_option( 'om_true_size', '1' ), '1' ); ?> /> "See true size" on diamonds (the stone drawn at its real size on a finger)</label><br />
							<input type="hidden" name="om_true_size_check" value="0" />
							<label><input type="checkbox" name="om_true_size_check" value="1" <?php checked( get_option( 'om_true_size_check', '1' ), '1' ); ?> /> Screen check and the "About real size" note</label>
							<p class="description">Screens differ, so until a visitor does the one-time bank-card check the size is an estimate, labelled "About real size". Untick to hide the note and the check; the stone is then simply shown to scale. Each OM Diamond Search / OM Ring Builder widget can also switch "True size" off for its own page.</p>
						</td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="inquiries">Inquiry form or booking calendar</h2>
				<?php $this->render_booking_section(); ?>

				<h2 class="om-sec" data-om-tab="inquiries">Inquiries</h2>
				<table class="form-table">
					<tr>
						<th><label for="om_inquiry_email">Send inquiries to</label></th>
						<td><input type="email" id="om_inquiry_email" name="om_inquiry_email" value="<?php echo esc_attr( get_option( 'om_inquiry_email', '' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" />
						<p class="description">Every inquiry is also saved under <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=om_inquiry' ) ); ?>">Inquiries</a>, so none are lost if email fails.</p></td>
					</tr>
					<tr>
						<th><label for="om_inquiry_success">Thank-you message</label></th>
						<td><input type="text" id="om_inquiry_success" name="om_inquiry_success" value="<?php echo esc_attr( get_option( 'om_inquiry_success', '' ) ); ?>" class="large-text" placeholder="Thank you! Your inquiry has been sent. We will be in touch soon." /></td>
					</tr>
					<tr>
						<th><label for="om_inquiry_subjects">Subjects</label></th>
						<td><textarea id="om_inquiry_subjects" name="om_inquiry_subjects" rows="5" class="large-text"><?php echo esc_textarea( get_option( 'om_inquiry_subjects', "General question\nPrice request\nBook a viewing\nBridal set\nCustom design\nRing sizing" ) ); ?></textarea>
						<p class="description">One per line. Visitors pick one at the top of the form; it heads the email and its subject line. Any button can preselect one by linking to <code>#om-inquiry?subject=Book a viewing</code> (e.g. a "Book an appointment" button).</p>
						<input type="hidden" name="om_inquiry_subject_field" value="0" /><label><input type="checkbox" name="om_inquiry_subject_field" value="1" <?php checked( get_option( 'om_inquiry_subject_field', '1' ), '1' ); ?> /> Show the subject choice on the form (off: the first subject, or the one a button preselects, is used)</label></td>
					</tr>
					<tr>
						<th><label for="om_inquiry_subject_tpl">Email subject line</label></th>
						<td><input type="text" id="om_inquiry_subject_tpl" name="om_inquiry_subject_tpl" value="<?php echo esc_attr( get_option( 'om_inquiry_subject_tpl', '' ) ); ?>" class="large-text" placeholder="{subject}: {piece} — {name}" />
						<p class="description">Tokens: <code>{subject}</code> <code>{piece}</code> (title + style number) <code>{title}</code> <code>{style}</code> <code>{name}</code> <code>{email}</code> <code>{phone}</code> <code>{price}</code> <code>{site}</code>. Empty = <code>{subject}: {piece} — {name}</code>, e.g. "Book a viewing: Halo Ring (Style 80285-04) — Jane".</p></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="inquiries">Inquiry form fields</h2>
				<p class="description">The built-in inquiry form used on product pages, the diamond search and the ring builder. Add, remove and reorder fields; the first email field is used to reply to the customer. An OM Single Product widget can also use its own field list.</p>
				<?php $this->render_field_editor(); ?>
				<table class="form-table">
					<tr>
						<th>Emails</th>
						<td><p class="description" style="margin-top:0">The inquiry email you receive and the customer's confirmation (on/off, recipients, wording, design) are set up under <a href="#emails" data-om-go="emails">Emails</a>.</p></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="pricing">When no price is shown</h2>
				<p class="description">Used by the built-in product page, and by the OM Single Product widget unless its own text/link is set. The widget can also show fully custom buttons instead.</p>
				<table class="form-table">
					<tr>
						<th><label for="om_price_placeholder">Text</label></th>
						<td><input type="text" id="om_price_placeholder" name="om_price_placeholder" value="<?php echo esc_attr( get_option( 'om_price_placeholder', '' ) ); ?>" class="regular-text" placeholder="Call for pricing" /></td>
					</tr>
					<tr>
						<th><label for="om_price_link">Link (optional)</label></th>
						<td><input type="text" id="om_price_link" name="om_price_link" value="<?php echo esc_attr( get_option( 'om_price_link', '' ) ); ?>" class="regular-text" placeholder="tel:+12195550100 or /contact/" /></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="connection">Caching</h2>
				<table class="form-table">
					<tr>
						<th>Background refresh</th>
						<td>
							<input type="hidden" name="om_warm_cache" value="0" />
							<label><input type="checkbox" name="om_warm_cache" value="1" <?php checked( get_option( 'om_warm_cache', '1' ), '1' ); ?> /> Keep catalog pages, search and filters refreshed in the background, so visitors never wait on Overnight Mountings' API</label>
							<p class="description"><?php echo esc_html( OM_Warmer::status_text() ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="om_listing_cache_minutes">Listing cache (minutes)</label></th>
						<td><input type="number" id="om_listing_cache_minutes" name="om_listing_cache_minutes" value="<?php echo esc_attr( get_option( 'om_listing_cache_minutes', 15 ) ); ?>" class="small-text" />
						<p class="description">How long to cache product listing pages before re-fetching from the API. Live price quotes are never cached.</p></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="product">Product Page Layout</h2>
				<table class="form-table">
					<tr>
						<th><label for="om_product_layout_page">Layout</label></th>
						<td>
							<select id="om_product_layout_page" name="om_product_layout_page">
								<option value="0" <?php selected( (int) get_option( 'om_product_layout_page', 0 ), 0 ); ?>>Built-in template (default)</option>
								<?php
								$elementor_pages = get_posts(
									array(
										'post_type'      => 'page',
										'post_status'    => 'publish',
										'posts_per_page' => 100,
										'orderby'        => 'title',
										'order'          => 'ASC',
										'meta_key'       => '_elementor_edit_mode',
										'meta_value'     => 'builder',
									)
								);
								foreach ( $elementor_pages as $layout_page ) :
									?>
									<option value="<?php echo esc_attr( $layout_page->ID ); ?>" <?php selected( (int) get_option( 'om_product_layout_page', 0 ), $layout_page->ID ); ?>><?php echo esc_html( $layout_page->post_title ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description">To design product pages visually: create a page in Elementor, drop in the <strong>OM Single Product</strong> widget (plus anything else you want around it), then pick that page here. Every <code>/catalog/...</code> product URL renders through it. The layout page itself is never linked publicly.</p>
						</td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="product">Product page</h2>
				<p class="description">Defaults for the built-in product page and the quick view. An OM Single Product widget has its own settings.</p>
				<table class="form-table">
					<tr>
						<th><label for="om_options_style">Options display</label></th>
						<td><select id="om_options_style" name="om_options_style">
							<?php $ostyle = get_option( 'om_options_style', 'swatches' ); ?>
							<option value="swatches" <?php selected( $ostyle, 'swatches' ); ?>>Swatches (colour circles) + pills</option>
							<option value="pills" <?php selected( $ostyle, 'pills' ); ?>>Pills</option>
							<option value="dropdowns" <?php selected( $ostyle, 'dropdowns' ); ?>>Dropdowns</option>
						</select></td>
					</tr>
					<tr>
						<th><label for="om_video_mode">Product videos</label></th>
						<td><select id="om_video_mode" name="om_video_mode">
							<?php $vmode = get_option( 'om_video_mode', 'first' ); ?>
							<option value="first" <?php selected( $vmode, 'first' ); ?>>Video first: plays silently on a loop as the main view</option>
							<option value="thumb" <?php selected( $vmode, 'thumb' ); ?>>Photos first, with a "Watch video" button</option>
						</select></td>
					</tr>
					<tr>
						<th>Photos follow metal colour</th>
						<td><input type="hidden" name="om_media_follow" value="0" /><label><input type="checkbox" name="om_media_follow" value="1" <?php checked( get_option( 'om_media_follow', '1' ), '1' ); ?> /> When a visitor picks a metal colour, show that colour's photos and videos</label>
						<p class="description">Works when Overnight Mountings' photos are told apart by colour (a colour on the image, or file names like …-YG-1.jpg). Settings &gt; OM Catalog &gt; Tools &gt; Test connection shows whether they are. Otherwise the gallery simply stays as it is.</p></td>
					</tr>
					<tr>
						<th><label for="om_details_style">Description &amp; details</label></th>
						<td><select id="om_details_style" name="om_details_style">
							<?php $dstyle = get_option( 'om_details_style', 'accordion' ); ?>
							<option value="accordion" <?php selected( $dstyle, 'accordion' ); ?>>Collapsible sections</option>
							<option value="open" <?php selected( $dstyle, 'open' ); ?>>Always open</option>
						</select></td>
					</tr>
					<tr>
						<th><label for="om_size_lines">Ring size picker on</label></th>
						<td><input type="text" id="om_size_lines" name="om_size_lines" value="<?php echo esc_attr( get_option( 'om_size_lines', 'engagement-rings,wedding-bands,fashion-rings' ) ); ?>" class="regular-text" />
						<p class="description">Comma-separated product lines that get a ring size picker (with size guide); the chosen size is priced and sent with inquiries.</p></td>
					</tr>
					<tr>
						<th><label for="om_size_guide_note">Size guide note</label></th>
						<td><textarea id="om_size_guide_note" name="om_size_guide_note" rows="2" class="large-text" placeholder="Not sure? We offer free resizing within 60 days, or visit us for a free professional sizing."><?php echo esc_textarea( get_option( 'om_size_guide_note', '' ) ); ?></textarea></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="product">Built-in product page rows</h2>
				<p class="description">Rows shown below the product on the built-in product page. With an Elementor product layout, add the <strong>OM Related Products</strong> widget where you want them instead.</p>
				<table class="form-table">
					<tr>
						<th>Show</th>
						<td>
							<input type="hidden" name="om_show_related" value="0" />
							<label><input type="checkbox" name="om_show_related" value="1" <?php checked( get_option( 'om_show_related', '1' ), '1' ); ?> /> "You might also like"</label><br />
							<input type="hidden" name="om_show_recent" value="0" />
							<label><input type="checkbox" name="om_show_recent" value="1" <?php checked( get_option( 'om_show_recent', '1' ), '1' ); ?> /> "Recently viewed"</label><br />
							<input type="hidden" name="om_show_set" value="0" />
							<label><input type="checkbox" name="om_show_set" value="1" <?php checked( get_option( 'om_show_set', '1' ), '1' ); ?> /> "Complete the set" (matching bands on ring pages, rings on band pages)</label><br />
							<input type="hidden" name="om_back_link" value="0" />
							<label><input type="checkbox" name="om_back_link" value="1" <?php checked( get_option( 'om_back_link', '1' ), '1' ); ?> /> "← Back to results" link above the product (returns to the same spot in the listing)</label>
						</td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="product">Complete the set</h2>
				<p class="description">Overnight Mountings doesn't say which band matches which ring, so the "Complete the set" row picks bands of the same design family (style number), then the same style (Halo, Solitaire…) in the metal chosen, then the most viewed bands. List exact matches here to put them first. Used by the built-in product page and the <strong>OM Related Products</strong> widget (Show: Complete the set).</p>
				<table class="form-table">
					<tr>
						<th><label for="om_set_pairs">Matching pairs</label></th>
						<td><textarea id="om_set_pairs" name="om_set_pairs" rows="5" class="large-text code" placeholder="80285-04 = 12345-01, 12345-02"><?php echo esc_textarea( get_option( 'om_set_pairs', '' ) ); ?></textarea>
						<p class="description">One per line: ring style number = matching band style numbers (comma-separated). Works both ways: the band's page then suggests the ring.</p></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="look">Brand Colors &amp; Fonts</h2>
				<table class="form-table">
					<tr>
						<th><label for="om_style_source">Style source</label></th>
						<td>
							<?php $source = get_option( 'om_style_source', 'kit' ); ?>
							<select id="om_style_source" name="om_style_source">
								<option value="kit" <?php selected( $source, 'kit' ); ?>>Follow the Elementor kit (Site Settings &gt; Global Colors &amp; Fonts)</option>
								<option value="custom" <?php selected( $source, 'custom' ); ?>>Use the values below</option>
							</select>
							<p class="description">With the kit, the catalog uses its Primary, Accent and Text colours and its Primary (headings) and Text (body) fonts, and changes whenever the site's kit does. Anything the kit doesn't set, or still has at Elementor's starting values (blue #6EC1E4 and Roboto), uses the values below, or the Wulf Elementor Kit's colours and fonts when that plugin is active.</p>
						</td>
					</tr>
				</table>
				<p class="description">Used to style the catalog grid and single product pages. Defaults match the live wulfdiamondjewelers.com Elementor kit (Arapey headings, Inter body, #00111C primary). Adjust here if the site's branding changes.</p>
				<table class="form-table">
					<tr>
						<th><label for="om_color_primary">Primary color</label></th>
						<td><input type="text" id="om_color_primary" name="om_color_primary" value="<?php echo esc_attr( get_option( 'om_color_primary', '#00111C' ) ); ?>" class="regular-text om-color-field" /></td>
					</tr>
					<tr>
						<th><label for="om_color_accent">Accent color (buttons, price)</label></th>
						<td><input type="text" id="om_color_accent" name="om_color_accent" value="<?php echo esc_attr( get_option( 'om_color_accent', '#000000' ) ); ?>" class="regular-text om-color-field" /></td>
					</tr>
					<tr>
						<th><label for="om_color_background">Background color</label></th>
						<td><input type="text" id="om_color_background" name="om_color_background" value="<?php echo esc_attr( get_option( 'om_color_background', '#ffffff' ) ); ?>" class="regular-text om-color-field" /></td>
					</tr>
					<tr>
						<th><label for="om_color_text">Body text color</label></th>
						<td><input type="text" id="om_color_text" name="om_color_text" value="<?php echo esc_attr( get_option( 'om_color_text', '#464646' ) ); ?>" class="regular-text om-color-field" /></td>
					</tr>
					<tr>
						<th><label for="om_font_heading">Heading font (CSS font-family)</label></th>
						<td><input type="text" id="om_font_heading" name="om_font_heading" value="<?php echo esc_attr( get_option( 'om_font_heading', 'Arapey, Georgia, serif' ) ); ?>" class="regular-text" /></td>
					</tr>
					<tr>
						<th><label for="om_font_body">Body font (CSS font-family)</label></th>
						<td><input type="text" id="om_font_body" name="om_font_body" value="<?php echo esc_attr( get_option( 'om_font_body', 'Inter, Helvetica, Arial, sans-serif' ) ); ?>" class="regular-text" /></td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="look">Look &amp; feel: site defaults</h2>
				<p class="description">Each OM widget has these options itself (Style tab: <em>Card Hover, Corners &amp; Spacing</em> / <em>Corners &amp; Spacing</em>; the trust line under <em>Price &amp; Buttons</em>) — configure them there. The values here are only the starting point for widgets left on "Site default", and for the built-in product page (no Elementor layout).</p>
				<table class="form-table">
					<tr>
						<th><label for="om_design">Design</label></th>
						<td><select id="om_design" name="om_design">
							<?php $design = get_option( 'om_design', 'refined' ); ?>
							<option value="refined" <?php selected( $design, 'refined' ); ?>>Refined — calm cards, one button family, gold accents (recommended)</option>
							<option value="modern" <?php selected( $design, 'modern' ); ?>>Modern</option>
							<option value="classic" <?php selected( $design, 'classic' ); ?>>Classic</option>
						</select>
						<p class="description">For the built-in product page, related rows, reels, quick view and compare. Catalog and product widgets choose their own (Page design).</p></td>
					</tr>
					<tr>
						<th><label for="om_button_shape">Button shape</label></th>
						<td><select id="om_button_shape" name="om_button_shape">
							<?php $shape = get_option( 'om_button_shape', 'pill' ); ?>
							<option value="pill" <?php selected( $shape, 'pill' ); ?>>Pill (fully rounded)</option>
							<option value="soft" <?php selected( $shape, 'soft' ); ?>>Soft (slightly rounded)</option>
							<option value="square" <?php selected( $shape, 'square' ); ?>>Square</option>
						</select> <span class="description">Refined design: every button, field and chip uses it.</span></td>
					</tr>
					<tr>
						<th><label for="om_color_gold_light">Gold</label></th>
						<td><input type="text" id="om_color_gold_light" name="om_color_gold_light" value="<?php echo esc_attr( get_option( 'om_color_gold_light', '#F4DC9C' ) ); ?>" class="om-color-field" /> fills (gold buttons, highlights) &nbsp;
						<input type="text" id="om_color_gold" name="om_color_gold" value="<?php echo esc_attr( get_option( 'om_color_gold', '#B8925A' ) ); ?>" class="om-color-field" /> lines &amp; rings (reels, progress, dividers)</td>
					</tr>
					<tr>
						<th><label for="om_photo_tone">Photo background</label></th>
						<td><input type="text" id="om_photo_tone" name="om_photo_tone" value="<?php echo esc_attr( get_option( 'om_photo_tone', '#FFFFFF' ) ); ?>" class="om-color-field" />
						<input type="hidden" name="om_photo_blend" value="0" />
						<label><input type="checkbox" name="om_photo_blend" value="1" <?php checked( get_option( 'om_photo_blend', '1' ), '1' ); ?> /> Blend photos' white backgrounds into this tone, so every card looks like one photoshoot</label></td>
					</tr>
					<tr>
						<th><label for="om_radius">Corner radius: buttons, pills, fields</label></th>
						<td><input type="number" min="0" max="60" id="om_radius" name="om_radius" value="<?php echo esc_attr( get_option( 'om_radius', '' ) ); ?>" class="small-text" /> px <span class="description">0 = square (default). 4–8 = soft. 30+ = fully rounded pills.</span></td>
					</tr>
					<tr>
						<th><label for="om_radius_lg">Corner radius: photos, cards, pop-ups</label></th>
						<td><input type="number" min="0" max="60" id="om_radius_lg" name="om_radius_lg" value="<?php echo esc_attr( get_option( 'om_radius_lg', '' ) ); ?>" class="small-text" /> px</td>
					</tr>
					<tr>
						<th><label for="om_spacing">Spacing</label></th>
						<td><select id="om_spacing" name="om_spacing">
							<?php $spacing = get_option( 'om_spacing', 'comfortable' ); ?>
							<option value="compact" <?php selected( $spacing, 'compact' ); ?>>Compact</option>
							<option value="comfortable" <?php selected( $spacing, 'comfortable' ); ?>>Comfortable (default)</option>
							<option value="airy" <?php selected( $spacing, 'airy' ); ?>>Airy</option>
						</select> <span class="description">Space between groups on the product page, filters and sections.</span></td>
					</tr>
					<tr>
						<th><label for="om_card_hover">Card hover</label></th>
						<td><select id="om_card_hover" name="om_card_hover">
							<?php $hover = get_option( 'om_card_hover', 'lift' ); ?>
							<option value="lift" <?php selected( $hover, 'lift' ); ?>>Lift: card rises with a soft shadow, name underlined (default)</option>
							<option value="zoom" <?php selected( $hover, 'zoom' ); ?>>Zoom: photo zooms slowly</option>
							<option value="none" <?php selected( $hover, 'none' ); ?>>None</option>
						</select></td>
					</tr>
					<tr>
						<th>Page transitions</th>
						<td><input type="hidden" name="om_page_transitions" value="0" /><label><input type="checkbox" name="om_page_transitions" value="1" <?php checked( get_option( 'om_page_transitions', '1' ), '1' ); ?> /> Smooth transitions between listing and product pages: the clicked photo glides into the product page (Chrome, Edge, Safari 18+; other browsers simply open the page)</label></td>
					</tr>
					<tr>
						<th>Saved designs</th>
						<td>
							<input type="hidden" name="om_saved" value="0" />
							<label><input type="checkbox" name="om_saved" value="1" <?php checked( get_option( 'om_saved', '1' ), '1' ); ?> /> A "Save" heart on cards, product pages and the quick view; a Saved panel lists them (kept on the visitor's device, no account)</label><br />
							<input type="hidden" name="om_saved_email" value="0" />
							<label><input type="checkbox" name="om_saved_email" value="1" <?php checked( get_option( 'om_saved_email', '1' ), '1' ); ?> /> "Email me my list" in the Saved panel — you get a copy, saved under Inquiries</label><br />
							<input type="hidden" name="om_saved_float" value="0" />
							<label><input type="checkbox" name="om_saved_float" value="1" <?php checked( get_option( 'om_saved_float', '1' ), '1' ); ?> /> A floating "Saved" button (bottom left) once something is saved — only on pages where no Saved button of your own is visible</label>
							<p class="description">Visitors reach their list from the "View saved" message after saving, the heart in the catalog's slim toolbar, and the floating button. To open it from your header too, add the <strong>OM Saved Designs</strong> widget (heart with a count), the <code>[om_saved_button]</code> shortcode, or any menu link to <code>#om-saved</code>. Each widget can hide the heart on its cards.</p>
						</td>
					</tr>
					<tr>
						<th>Drop a hint</th>
						<td>
							<input type="hidden" name="om_hint" value="0" />
							<label><input type="checkbox" name="om_hint" value="1" <?php checked( get_option( 'om_hint', '1' ), '1' ); ?> /> A "Drop a hint" link on product pages, in the quick view and in the Saved panel: visitors send a design to a partner or friend, who gets a branded email and a private page to see it and book a viewing</label>
							<p><label for="om_hint_label">Link text</label><br /><input type="text" id="om_hint_label" name="om_hint_label" value="<?php echo esc_attr( get_option( 'om_hint_label', '' ) ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'Drop a hint', 'om-catalog' ); ?>" /></p>
							<p><label for="om_hint_promise">Promise under the buttons on the hint page</label><br /><input type="text" id="om_hint_promise" name="om_hint_promise" value="<?php echo esc_attr( (string) get_option( 'om_hint_promise', __( 'Free, no obligation, and we will keep it between us.', 'om-catalog' ) ) ); ?>" class="large-text" /></p>
							<p class="description">You get a copy of every hint (saved under Inquiries) and a short email the first time it is opened. Only the sender goes to your CRM; the person they send it to gets this one email and is not added anywhere. The emails are under Emails.</p>
						</td>
					</tr>
					<tr>
						<th><label for="om_menu_selector">Your site's menu</label></th>
						<td>
							<input type="text" id="om_menu_selector" name="om_menu_selector" value="<?php echo esc_attr( get_option( 'om_menu_selector', '' ) ); ?>" class="regular-text" placeholder=".my-header .menu-panel.is-open" />
							<p class="description">While your site's menu (or a pop-up) is open, the catalog's floating pieces — the slim Filters/Search bar, the chat button, the Saved button — step aside so they never cover it. Elementor menus and pop-ups and most themes are detected by themselves; if yours isn't, enter a CSS selector that matches the menu <em>while it is open</em>.</p>
						</td>
					</tr>
					<tr>
						<th><label for="om_trust_line">Trust line under the price</label></th>
						<td><input type="text" id="om_trust_line" name="om_trust_line" value="<?php echo esc_attr( get_option( 'om_trust_line', '' ) ); ?>" class="large-text" placeholder="Free resizing | Certified diamonds | Made to order" />
						<p class="description">Short promises, separated by <code>|</code>. Shown under the price on product pages and in quick view. Leave empty to hide. Only list what you really offer.</p></td>
					</tr>
					<tr>
						<th>Text sizes on phones</th>
						<td>
							<label>Product name <input type="number" min="0" max="60" name="om_m_title" value="<?php echo esc_attr( get_option( 'om_m_title', '' ) ); ?>" class="small-text" placeholder="26" /> px</label> &nbsp;
							<label>Card names <input type="number" min="0" max="60" name="om_m_card_title" value="<?php echo esc_attr( get_option( 'om_m_card_title', '' ) ); ?>" class="small-text" placeholder="15" /> px</label> &nbsp;
							<label>Body text <input type="number" min="0" max="60" name="om_m_body" value="<?php echo esc_attr( get_option( 'om_m_body', '' ) ); ?>" class="small-text" placeholder="14" /> px</label>
							<p class="description">Screens up to 600px wide. Leave empty for the defaults shown. Long names are balanced over two lines instead of leaving one word alone.</p>
						</td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="emails">Email design</h2>
				<p class="description">The look of every email the plugin sends: your logo, colours, sender and footer. Each email's wording is below.</p>
				<?php $email_design = OM_Emails::design(); $email_saved_design = get_option( OM_Emails::DESIGN, array() ); ?>
				<table class="form-table">
					<tr>
						<th><label for="om_email_logo">Logo</label></th>
						<td><input type="url" id="om_email_logo" name="om_email_design[logo]" value="<?php echo esc_attr( $email_design['logo'] ); ?>" class="regular-text" placeholder="https://…/logo.png" />
						<button type="button" class="button" data-om-media="#om_email_logo">Choose image</button>
						<label style="margin-left:8px">Width <input type="number" min="60" max="400" name="om_email_design[logo_width]" value="<?php echo esc_attr( $email_design['logo_width'] ); ?>" class="small-text" /> px</label>
						<p class="description">Empty = your site name in the heading font. A PNG with a transparent or white background works best.</p></td>
					</tr>
					<tr>
						<th>Colours</th>
						<td>
							<label>Brand (headings, buttons) <input type="text" name="om_email_design[brand]" value="<?php echo esc_attr( $email_saved_design['brand'] ?? '' ); ?>" class="om-color-field" placeholder="<?php echo esc_attr( $email_design['brand'] ); ?>" style="width:110px" /></label><br />
							<label>Accent (top line, quotes) <input type="text" name="om_email_design[accent]" value="<?php echo esc_attr( $email_saved_design['accent'] ?? '' ); ?>" class="om-color-field" placeholder="#B8925A" style="width:110px" /></label><br />
							<label>Background <input type="text" name="om_email_design[background]" value="<?php echo esc_attr( $email_saved_design['background'] ?? '' ); ?>" class="om-color-field" placeholder="#F4F3F1" style="width:110px" /></label>
						</td>
					</tr>
					<tr>
						<th>Sender</th>
						<td><input type="text" name="om_email_design[from_name]" value="<?php echo esc_attr( $email_design['from_name'] ); ?>" class="regular-text" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" aria-label="From name" />
						<input type="email" name="om_email_design[from_email]" value="<?php echo esc_attr( $email_design['from_email'] ); ?>" class="regular-text" placeholder="hello@yourdomain.com" aria-label="From email" style="margin-top:6px" />
						<p class="description">Who the emails come from. Use an address on your own domain (and an SMTP plugin) so they don't land in spam. Empty = WordPress's default.</p></td>
					</tr>
					<tr>
						<th>Footer</th>
						<td><?php
						wp_editor(
							(string) ( $email_saved_design['footer'] ?? '' ),
							'omemaildesignfooter',
							array(
								'textarea_name' => 'om_email_design[footer]',
								'editor_height' => 110,
								'media_buttons' => false,
								'teeny'         => true,
								'quicktags'     => true,
							)
						);
						?>
						<p class="description">Address, phone, opening hours, social links… Empty = your site name and address. Placeholders work here too.</p></td>
					</tr>
				</table>

				<?php foreach ( OM_Emails::notifications() as $email_id => $email_def ) : ?>
					<?php $em = OM_Emails::get( $email_id ); $em_name = 'om_email_' . $email_id; ?>
					<h2 class="om-sec" data-om-tab="emails"><?php echo esc_html( $email_def['label'] ); ?> <span class="om-email-aud"><?php echo esc_html( array( 'shop' => 'to you', 'partner' => 'to the person they hint' )[ $email_def['audience'] ] ?? 'to the customer' ); ?></span></h2>
					<p class="description"><?php echo esc_html( $email_def['when'] ); ?></p>
					<table class="form-table om-email-table" data-om-email="<?php echo esc_attr( $email_id ); ?>">
						<?php if ( $email_def['toggle'] ) : ?>
							<tr>
								<th>Send</th>
								<td><input type="hidden" name="<?php echo esc_attr( $em_name ); ?>[enabled]" value="0" /><label><input type="checkbox" name="<?php echo esc_attr( $em_name ); ?>[enabled]" value="1" <?php checked( $em['enabled'], '1' ); ?> /> Send this email</label></td>
							</tr>
						<?php else : ?>
							<input type="hidden" name="<?php echo esc_attr( $em_name ); ?>[enabled]" value="1" />
						<?php endif; ?>
						<?php if ( ! empty( $email_def['days'] ) ) : ?>
							<tr>
								<th><label for="<?php echo esc_attr( $em_name ); ?>_days">When</label></th>
								<td><input type="number" min="1" max="30" id="<?php echo esc_attr( $em_name ); ?>_days" name="<?php echo esc_attr( $em_name ); ?>[days]" value="<?php echo esc_attr( $em['days'] ?? '3' ); ?>" class="small-text" /> days after they emailed themselves the design — only if no request has come from that address since, and at most once a month per address.</td>
							</tr>
						<?php endif; ?>
						<?php if ( 'shop' === $email_def['audience'] ) : ?>
							<tr>
								<th>Recipients</th>
								<td><input type="text" name="<?php echo esc_attr( $em_name ); ?>[to]" value="<?php echo esc_attr( $em['to'] ); ?>" class="regular-text" placeholder="<?php echo esc_attr( OM_Emails::shop_address() ); ?>" aria-label="To" />
								<input type="text" name="<?php echo esc_attr( $em_name ); ?>[cc]" value="<?php echo esc_attr( $em['cc'] ); ?>" class="regular-text" placeholder="Cc (optional)" aria-label="Cc" style="margin-top:6px" />
								<input type="text" name="<?php echo esc_attr( $em_name ); ?>[bcc]" value="<?php echo esc_attr( $em['bcc'] ); ?>" class="regular-text" placeholder="Bcc (optional)" aria-label="Bcc" style="margin-top:6px" />
								<p class="description">Several addresses: separate with commas. Empty "To" = the address under Inquiries.</p></td>
							</tr>
						<?php endif; ?>
						<tr>
							<th><label for="<?php echo esc_attr( $em_name ); ?>_subject">Subject</label></th>
							<td><input type="text" id="<?php echo esc_attr( $em_name ); ?>_subject" name="<?php echo esc_attr( $em_name ); ?>[subject]" value="<?php echo esc_attr( $em['subject'] ); ?>" class="large-text" data-om-token-target /></td>
						</tr>
						<tr>
							<th><label for="<?php echo esc_attr( $em_name ); ?>_heading">Heading</label></th>
							<td><input type="text" id="<?php echo esc_attr( $em_name ); ?>_heading" name="<?php echo esc_attr( $em_name ); ?>[heading]" value="<?php echo esc_attr( $em['heading'] ); ?>" class="large-text" data-om-token-target /></td>
						</tr>
						<tr>
							<th>Message</th>
							<td><?php
							wp_editor(
								(string) $em['body'],
								'omemail' . str_replace( '_', '', $email_id ),
								array(
									'textarea_name' => $em_name . '[body]',
									'editor_height' => 220,
									'media_buttons' => true,
									'teeny'         => false,
									'quicktags'     => true,
									'tinymce'       => array(
										'toolbar1' => 'formatselect,bold,italic,underline,forecolor,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,hr,removeformat,undo,redo',
										'toolbar2' => '',
									),
								)
							);
							?>
							<div class="om-email-tokens"><span>Placeholders — click to insert:</span>
								<?php foreach ( array_merge( array( 'site_name' ), $email_def['tokens'] ) as $tok ) : ?>
									<button type="button" class="om-email-token" data-om-token="{<?php echo esc_attr( $tok ); ?>}" title="<?php echo esc_attr( OM_Emails::token_help()[ $tok ] ?? '' ); ?>">{<?php echo esc_html( $tok ); ?>}</button>
								<?php endforeach; ?>
							</div>
							<p class="description"><code>{details}</code> is the automatic block (<?php echo 0 === strpos( $email_id, 'inquiry' ) ? 'the piece with its options and price' . ( 'inquiry_shop' === $email_id ? ', and their message' : '' ) : ( 0 === strpos( $email_id, 'saved' ) ? 'the saved designs with photos' : ( 0 === strpos( $email_id, 'hint' ) ? 'their note, the designs with photos and the ring size' : 'nothing extra for this one' ) ); ?>); without it, the block follows your text.</p></td>
						</tr>
						<tr>
							<th><label for="<?php echo esc_attr( $em_name ); ?>_button">Button</label></th>
							<td><input type="text" id="<?php echo esc_attr( $em_name ); ?>_button" name="<?php echo esc_attr( $em_name ); ?>[button]" value="<?php echo esc_attr( $em['button'] ); ?>" class="regular-text" data-om-token-target />
							<p class="description">Links to the piece, the list or the design. Empty = no button.</p></td>
						</tr>
						<tr>
							<th>Check it</th>
							<td><button type="button" class="button" data-om-email-preview="<?php echo esc_attr( $email_id ); ?>">Preview</button>
							<button type="button" class="button" data-om-email-test="<?php echo esc_attr( $email_id ); ?>">Send a test to <?php echo esc_html( wp_get_current_user()->user_email ); ?></button>
							<span class="om-email-status" aria-live="polite"></span>
							<p class="description">Both use what's on screen now (even before saving), with example details.</p></td>
						</tr>
					</table>
				<?php endforeach; ?>
				<input type="hidden" id="om-email-nonce" value="<?php echo esc_attr( wp_create_nonce( 'om_email_admin' ) ); ?>" />

				<h2 class="om-sec" data-om-tab="assistant">AI assistant</h2>
				<p class="description">"Ask our jeweller": a friendly chat that answers questions and suggests real designs from your catalog, then hands over to your team (the chat comes with the inquiry). The plugin picks the matching designs itself; the AI only writes the reply, so it can't invent pieces or prices.</p>
				<table class="form-table">
					<tr>
						<th>Assistant</th>
						<td>
							<input type="hidden" name="om_ai_enabled" value="0" />
							<label><input type="checkbox" name="om_ai_enabled" value="1" <?php checked( get_option( 'om_ai_enabled', '0' ), '1' ); ?> /> Show the chat on the site</label>
							<?php $ai_usage = OM_Assistant::usage_today(); ?>
							<p class="description">Today: <?php echo (int) $ai_usage['n']; ?> answered by the AI<?php echo $ai_usage['f'] ? ', ' . (int) $ai_usage['f'] . ' not answered (visitors were asked to try again)' : ''; ?>.</p>
							<?php $ai_err = get_option( 'om_ai_last_error' ); ?>
							<?php if ( is_array( $ai_err ) && ! empty( $ai_err['m'] ) ) : ?>
								<p class="description" style="color:#b4540a">Last problem (<?php echo esc_html( human_time_diff( (int) $ai_err['t'] ) ); ?> ago): <?php echo esc_html( $ai_err['m'] ); ?></p>
							<?php endif; ?>
							<p class="description">While logged in as an admin, the chat itself also shows why an answer failed.</p>
						</td>
					</tr>
					<tr>
						<th><label for="om_ai_provider">AI provider</label></th>
						<td>
							<?php $ai_p = OM_Assistant::provider(); ?>
							<select id="om_ai_provider" name="om_ai_provider" data-om-ai-provider>
								<option value="openrouter" <?php selected( $ai_p, 'openrouter' ); ?>>OpenRouter (free models available)</option>
								<option value="gemini" <?php selected( $ai_p, 'gemini' ); ?>>Google Gemini</option>
								<option value="claude" <?php selected( $ai_p, 'claude' ); ?>>Anthropic Claude</option>
							</select>
							<p class="description">Keys are kept on your server and never shown again after saving; leave a key field empty to keep it, or type <code>-</code> to remove it.</p>
						</td>
					</tr>
					<tr data-om-ai-for="openrouter">
						<th><label for="om_ai_key_openrouter">OpenRouter API key</label></th>
						<td><input type="password" id="om_ai_key_openrouter" name="om_ai_key_openrouter" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo OM_Assistant::key( 'openrouter' ) ? esc_attr__( 'Saved — leave blank to keep it', 'om-catalog' ) : 'sk-or-…'; ?>" />
						<p class="description">From <a href="https://openrouter.ai/keys" target="_blank" rel="noopener">openrouter.ai/keys</a>. Free models allow a small number of requests a day; buying $10 of credit once raises the free allowance a lot (free models don't use the credit).</p>
						<label for="om_ai_models_openrouter" style="display:block;margin-top:10px;font-weight:600">Models, in order</label>
						<input type="text" id="om_ai_models_openrouter" name="om_ai_models_openrouter" value="<?php echo esc_attr( get_option( 'om_ai_models_openrouter', '' ) ); ?>" class="large-text" placeholder="<?php echo esc_attr( implode( ', ', OM_Assistant::openrouter_models() ) ); ?>" />
						<p class="description">Comma-separated model IDs; if one is busy or gone, the next is tried, then OpenRouter's current free models (looked up automatically, so a retired name can't stop the chat). Free ones end in <code>:free</code> — see <a href="https://openrouter.ai/models?q=free" target="_blank" rel="noopener">openrouter.ai/models</a>. Empty = the defaults shown.</p></td>
					</tr>
					<tr data-om-ai-for="gemini">
						<th><label for="om_ai_key_gemini">Gemini API key</label></th>
						<td><input type="password" id="om_ai_key_gemini" name="om_ai_key_gemini" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo OM_Assistant::key( 'gemini' ) ? esc_attr__( 'Saved — leave blank to keep it', 'om-catalog' ) : 'AIza…'; ?>" />
						<p class="description">From <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a>.</p>
						<label for="om_ai_model_gemini" style="display:block;margin-top:10px;font-weight:600">Model</label>
						<input type="text" id="om_ai_model_gemini" name="om_ai_model_gemini" value="<?php echo esc_attr( get_option( 'om_ai_model_gemini', '' ) ); ?>" class="regular-text" placeholder="gemini-2.5-flash" /></td>
					</tr>
					<tr data-om-ai-for="claude">
						<th><label for="om_ai_key_claude">Claude API key</label></th>
						<td><input type="password" id="om_ai_key_claude" name="om_ai_key_claude" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo OM_Assistant::key( 'claude' ) ? esc_attr__( 'Saved — leave blank to keep it', 'om-catalog' ) : 'sk-ant-…'; ?>" />
						<p class="description">From <a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener">the Claude Console</a> (paid per use).</p>
						<label for="om_ai_model_claude" style="display:block;margin-top:10px;font-weight:600">Model</label>
						<?php $ai_cm = get_option( 'om_ai_model_claude', 'claude-opus-5-5' ); ?>
						<select id="om_ai_model_claude" name="om_ai_model_claude">
							<?php foreach ( OM_Assistant::CLAUDE_MODELS as $id => $label ) : ?>
								<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $ai_cm, $id ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select></td>
					</tr>
					<tr>
						<th>Test</th>
						<td><button type="button" class="button" data-om-ai-test data-nonce="<?php echo esc_attr( wp_create_nonce( 'om_assistant_test' ) ); ?>">Ask a test question</button>
						<p class="description">Uses the <strong>saved</strong> settings (save first), with a sample question about oval engagement rings.</p>
						<div class="om-ai-test-result" aria-live="polite"></div></td>
					</tr>
					<tr>
						<th><label for="om_ai_about">About your shop</label></th>
						<td><textarea id="om_ai_about" name="om_ai_about" rows="7" class="large-text" placeholder="Address, opening hours, phone&#10;What you offer: custom design, resizing, repairs, engraving, financing…&#10;Lab-grown and natural diamonds; certificates (GIA / IGI)&#10;How viewings work, how long orders usually take"><?php echo esc_textarea( get_option( 'om_ai_about', '' ) ); ?></textarea>
						<p class="description">The only shop facts the assistant uses. Anything not here, it passes to your team. Short lines are best.</p></td>
					</tr>
					<tr>
						<th>What it knows</th>
						<td>
							<p style="margin:0 0 6px"><label><input type="checkbox" checked disabled /> Your catalog — finds real designs and shows them as photo cards (always on)</label></p>
							<input type="hidden" name="om_ai_src_details" value="0" />
							<p style="margin:0 0 6px"><label><input type="checkbox" name="om_ai_src_details" value="1" <?php checked( get_option( 'om_ai_src_details', '1' ), '1' ); ?> /> Product details from Overnight Mountings — metals, colours, carat sizes and stones of the designs it suggests</label></p>
							<input type="hidden" name="om_ai_src_diamonds" value="0" />
							<p style="margin:0 0 6px"><label><input type="checkbox" name="om_ai_src_diamonds" value="1" <?php checked( get_option( 'om_ai_src_diamonds', '1' ), '1' ); ?> /> Live diamonds — when visitors ask about stones, it looks up real diamonds (shape, carat, lab-grown or natural) and can show them, linked to the ring builder</label></p>
							<input type="hidden" name="om_ai_src_site" value="0" />
							<p style="margin:0 0 6px"><label><input type="checkbox" name="om_ai_src_site" value="1" <?php checked( get_option( 'om_ai_src_site', '1' ), '1' ); ?> /> Your website's pages — reads your own pages to answer about the shop (services, policies, FAQs, the story…) and links the page</label></p>
							<?php $om_types = explode( ',', (string) get_option( 'om_ai_site_types', 'page,post' ) ); ?>
							<p style="margin:0 0 6px 24px">From:
								<label><input type="checkbox" name="om_ai_site_types[]" value="page" <?php checked( in_array( 'page', $om_types, true ) ); ?> /> Pages</label>
								<label style="margin-left:10px"><input type="checkbox" name="om_ai_site_types[]" value="post" <?php checked( in_array( 'post', $om_types, true ) ); ?> /> Blog posts</label>
								<label style="margin-left:14px">Leave out page IDs <input type="text" name="om_ai_site_exclude" value="<?php echo esc_attr( get_option( 'om_ai_site_exclude', '' ) ); ?>" class="regular-text" style="width:160px" placeholder="12, 48" /></label>
							</p>
							<input type="hidden" name="om_ai_prices" value="0" />
							<p style="margin:0 0 6px"><label><input type="checkbox" name="om_ai_prices" value="1" <?php checked( get_option( 'om_ai_prices', '1' ), '1' ); ?> /> It may mention prices — the same prices your site shows ("from $1,188", diamond prices), never wholesale; only while prices are on (Pricing)</label></p>
							<p class="description">Everything it is given comes from your own site, your catalog and Overnight Mountings — "About your shop" above still comes first for shop facts. Only published, public pages are read; password-protected and private ones never are.</p>
						</td>
					</tr>
					<tr>
						<th><label for="om_ai_logo">Look</label></th>
						<td>
							<input type="url" id="om_ai_logo" name="om_ai_logo" value="<?php echo esc_attr( get_option( 'om_ai_logo', '' ) ); ?>" class="regular-text" placeholder="https://…/logo-mark.png" />
							<button type="button" class="button" data-om-media="#om_ai_logo">Choose image</button>
							<p class="description">Your logo or monogram, shown round in the chat header (a square image works best). Empty = a sparkle.</p>
							<p style="margin:10px 0 0"><label>Main colour <input type="text" name="om_ai_color" value="<?php echo esc_attr( get_option( 'om_ai_color', '' ) ); ?>" class="om-color-field" placeholder="<?php echo esc_attr( get_option( 'om_color_primary', '#00111C' ) ); ?>" /></label>
							<label style="margin-left:14px">Accent <input type="text" name="om_ai_accent" value="<?php echo esc_attr( get_option( 'om_ai_accent', '' ) ); ?>" class="om-color-field" placeholder="#E8CF98" /></label></p>
							<p class="description">Main = the header, the button and the visitor's messages (empty = your site colour). Accent = the sparkle and small details.</p>
							<p style="margin:10px 0 0"><label>Button icon <select name="om_ai_launcher_icon">
								<option value="spark" <?php selected( get_option( 'om_ai_launcher_icon', 'spark' ), 'spark' ); ?>>Sparkle</option>
								<option value="logo" <?php selected( get_option( 'om_ai_launcher_icon', 'spark' ), 'logo' ); ?>>Your logo</option>
							</select></label>
							<label style="margin-left:14px">Line under the name <input type="text" name="om_ai_subtitle" value="<?php echo esc_attr( get_option( 'om_ai_subtitle', '' ) ); ?>" class="regular-text" style="width:240px" placeholder="Usually replies in seconds" /></label></p>
						</td>
					</tr>
					<tr>
						<th><label for="om_ai_name">Name &amp; texts</label></th>
						<td>
							<input type="text" id="om_ai_name" name="om_ai_name" value="<?php echo esc_attr( get_option( 'om_ai_name', '' ) ); ?>" class="regular-text" placeholder="Jewellery assistant" />
							<p class="description">Its name in the chat.</p>
							<input type="text" name="om_ai_launcher" value="<?php echo esc_attr( get_option( 'om_ai_launcher', '' ) ); ?>" class="regular-text" placeholder="Ask our jeweller" aria-label="Button text" style="margin-top:8px" />
							<p class="description">The button that opens the chat.</p>
							<textarea name="om_ai_greeting" rows="3" class="large-text" aria-label="Greeting" style="margin-top:8px" placeholder="<?php echo esc_attr( OM_Assistant::front_config() ? OM_Assistant::front_config()['greeting'] : 'Hi! I’m here to help you find the perfect piece…' ); ?>"><?php echo esc_textarea( get_option( 'om_ai_greeting', '' ) ); ?></textarea>
							<p class="description">The first message. Empty = the text shown.</p>
							<textarea name="om_ai_chips" rows="4" class="large-text" aria-label="Suggested questions" style="margin-top:8px" placeholder="Help me find an engagement ring&#10;Halo or hidden halo: what’s the difference?&#10;Lab-grown or natural diamond?&#10;How do I find her ring size?"><?php echo esc_textarea( get_option( 'om_ai_chips', '' ) ); ?></textarea>
							<p class="description">Suggested questions to tap, one per line (up to 6).</p>
						</td>
					</tr>
					<tr>
						<th><label for="om_ai_show">Show on</label></th>
						<td><select id="om_ai_show" name="om_ai_show">
							<option value="catalog" <?php selected( get_option( 'om_ai_show', 'catalog' ), 'catalog' ); ?>>Catalog, product, diamond and ring builder pages</option>
							<option value="home" <?php selected( get_option( 'om_ai_show', 'catalog' ), 'home' ); ?>>Catalog pages and the homepage</option>
							<option value="all" <?php selected( get_option( 'om_ai_show', 'catalog' ), 'all' ); ?>>Every page</option>
						</select></td>
					</tr>
					<tr>
						<th><label for="om_ai_starter">Starter question on the homepage</label></th>
						<td>
							<input type="text" id="om_ai_starter" name="om_ai_starter" value="<?php echo esc_attr( get_option( 'om_ai_starter', 'Looking for an engagement ring? I can suggest designs for your style and budget.' ) ); ?>" class="large-text" />
							<p><label>Show it after <input type="number" min="3" max="60" name="om_ai_starter_delay" value="<?php echo esc_attr( get_option( 'om_ai_starter_delay', 8 ) ); ?>" class="small-text" /> seconds</label>, or sooner once the visitor scrolls a third of the page.</p>
							<p class="description">A small speech bubble beside the button on the homepage, once per visit, with two of your suggested questions to tap. Leave it empty to turn it off.</p>
						</td>
					</tr>
					<tr>
						<th>Button position</th>
						<td>
							<select name="om_ai_side" aria-label="Side"><option value="right" <?php selected( get_option( 'om_ai_side', 'right' ), 'right' ); ?>>Bottom right</option><option value="left" <?php selected( get_option( 'om_ai_side', 'right' ), 'left' ); ?>>Bottom left</option></select>
							&nbsp;<label><input type="number" min="0" max="200" name="om_ai_offset_x" value="<?php echo esc_attr( get_option( 'om_ai_offset_x', 20 ) ); ?>" class="small-text" /> px from the side</label>
							&nbsp;<label><input type="number" min="0" max="300" name="om_ai_offset_y" value="<?php echo esc_attr( get_option( 'om_ai_offset_y', 20 ) ); ?>" class="small-text" /> px from the bottom</label>
							<p class="description">It moves up by itself only while something else sits under it (the compare tray, the phone's filter bar, the product page's bottom bar), then goes back. On ring builder steps it sits inside the "Your ring" bar instead (OM Ring Builder widget › "Your ring" bar).</p>
							<input type="hidden" name="om_ai_mini" value="0" />
							<p><label><input type="checkbox" name="om_ai_mini" value="1" <?php checked( get_option( 'om_ai_mini', '1' ), '1' ); ?> /> Shrink it to its icon once the visitor scrolls down, so it covers less of the page</label></p>
						</td>
					</tr>
					<tr>
						<th>Limits</th>
						<td>
							<label>Per visitor <input type="number" min="0" name="om_ai_hourly" value="<?php echo esc_attr( get_option( 'om_ai_hourly', 0 ) ); ?>" class="small-text" /> messages an hour</label> &nbsp;
							<label>Whole site <input type="number" min="0" name="om_ai_daily" value="<?php echo esc_attr( get_option( 'om_ai_daily', 0 ) ); ?>" class="small-text" /> AI answers a day</label>
							<p class="description">0 = no limit (the default). Set limits later if you want to cap costs or keep within a free allowance.</p>
						</td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="crm">CRM</h2>
				<p class="description">Send every lead to your CRM as it comes in: inquiries from any form (product pages, diamonds, ring builder, the AI chat's "talk to our team"), visitors who email themselves their saved designs or ring design, hints, and the Wulf Elementor Kit's visit requests, quiz and sign-ups. Each lead carries their details, the design, style number, options, price shown, page and photo, the diamond, ring builder design, "Help me choose" answers, their message, the chat, and the visit behind it (where they came from, visits so far, designs looked at). Emails and the Inquiries list work as before.</p>
				<?php $crm_mode = class_exists( 'OM_CRM' ) ? OM_CRM::mode() : 'off'; $crm_token = (string) get_option( 'om_crm_ghl_token', '' ); ?>
				<table class="form-table">
					<tr>
						<th><label for="om_crm_mode">Send leads to</label></th>
						<td><select id="om_crm_mode" name="om_crm_mode">
							<option value="off" <?php selected( $crm_mode, 'off' ); ?>>Nowhere (off)</option>
							<option value="ghl" <?php selected( $crm_mode, 'ghl' ); ?>>GoHighLevel (direct)</option>
							<option value="webhook" <?php selected( $crm_mode, 'webhook' ); ?>>A webhook (GHL workflow, Zapier, Make, any CRM)</option>
							<option value="both" <?php selected( $crm_mode, 'both' ); ?>>Both</option>
						</select>
						<p class="description">Leads are sent right after the visitor's page answers (they never wait), retried if your CRM doesn't answer, and listed below.</p></td>
					</tr>
					<tr data-om-crm="ghl">
						<th><label for="om_crm_ghl_token">GoHighLevel</label></th>
						<td>
							<input type="password" id="om_crm_ghl_token" name="om_crm_ghl_token" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo '' !== $crm_token ? 'Saved (leave blank to keep it)' : 'pit-…'; ?>" aria-label="Private integration token" />
							<div data-om-live="crm-token"><?php if ( '' !== $crm_token ) : ?><p class="om-cred-saved" style="margin:6px 0 0;color:#008a20">&#10004; Token saved (ending in …<?php echo esc_html( substr( $crm_token, -4 ) ); ?>)</p><?php endif; ?></div>
							<p class="description"><strong>Private integration token</strong>: in GoHighLevel, Settings › Private Integrations › Create new, with the scopes <em>View Contacts</em> and <em>Edit Contacts</em> (contacts.readonly, contacts.write), <em>View Custom Fields</em> and <em>Edit Custom Fields</em> (locations/customFields.readonly, locations/customFields.write) and, for opportunities, <em>Edit Opportunities</em> (opportunities.write). Already have a token? Edit that integration in GoHighLevel and tick the custom field scopes too.</p>
							<input type="text" name="om_crm_ghl_location" value="<?php echo esc_attr( get_option( 'om_crm_ghl_location', '' ) ); ?>" class="regular-text" placeholder="Location ID" aria-label="Location ID" style="margin-top:8px" />
							<p class="description"><strong>Location ID</strong>: Settings › Business Profile (or the long code in your GHL web address after /location/).</p>
							<p style="margin:10px 0 0"><input type="text" name="om_crm_ghl_pipeline" value="<?php echo esc_attr( get_option( 'om_crm_ghl_pipeline', '' ) ); ?>" class="regular-text" style="width:220px" placeholder="Pipeline ID (optional)" aria-label="Pipeline ID" />
							<input type="text" name="om_crm_ghl_stage" value="<?php echo esc_attr( get_option( 'om_crm_ghl_stage', '' ) ); ?>" class="regular-text" style="width:220px" placeholder="Stage ID (optional)" aria-label="Stage ID" /></p>
							<p class="description">With both set, every inquiry also opens an <strong>opportunity</strong> in that pipeline stage (named after the piece and the customer, valued at the price shown). Find the IDs in Opportunities › Pipelines (the pipeline's settings) or ask your GHL admin.</p>
							<p class="description">Each lead creates or updates the <strong>contact</strong> (matched by email or phone, so nothing is duplicated), fills in its <strong>contact fields</strong> (below), adds the <strong>tags</strong> below and attaches a <strong>note</strong> with every detail and their visit.</p>
						</td>
					</tr>
					<tr data-om-crm="ghl">
						<th>Contact fields</th>
						<td>
							<input type="hidden" name="om_crm_ghl_fields_on" value="0" />
							<label><input type="checkbox" name="om_crm_ghl_fields_on" value="1" <?php checked( get_option( 'om_crm_ghl_fields_on', '1' ), '1' ); ?> /> Put each lead's details in fields on the contact</label>
							<p class="description">So the design, price and page show right on the contact in GoHighLevel, in lists and filters, and can go in your workflows, emails and texts (for example <code>{{contact.website_design}}</code>). The plugin makes these fields in GoHighLevel the first time: <?php echo esc_html( implode( ', ', class_exists( 'OM_CRM' ) ? wp_list_pluck( OM_CRM::field_defs(), 0 ) : array() ) ); ?>. Each new lead fills them in with its own details; every lead is also kept in its own note.</p>
							<div data-om-live="crm-fields">
								<?php
								$crm_fields = class_exists( 'OM_CRM' ) ? OM_CRM::fields_status() : array( 'state' => 'off', 'text' => '' );
								$crm_color  = array( 'ok' => '#008a20', 'error' => '#d63638' );
								?>
								<p class="om-crm-fields-status" style="margin:8px 0 0;color:<?php echo esc_attr( $crm_color[ $crm_fields['state'] ] ?? '#50575e' ); ?>"><?php echo esc_html( ( 'ok' === $crm_fields['state'] ? '✔ ' : ( 'error' === $crm_fields['state'] ? '✘ ' : '' ) ) . $crm_fields['text'] ); ?></p>
							</div>
							<p style="margin:8px 0 0"><button type="button" class="button" data-om-crm-fields data-nonce="<?php echo esc_attr( wp_create_nonce( 'om_crm_fields' ) ); ?>">Set up the fields now</button></p>
							<div class="om-crm-fields-result" aria-live="polite"></div>
						</td>
					</tr>
					<tr data-om-crm="webhook">
						<th><label for="om_crm_webhook">Webhook</label></th>
						<td><input type="url" id="om_crm_webhook" name="om_crm_webhook" value="<?php echo esc_attr( get_option( 'om_crm_webhook', '' ) ); ?>" class="large-text" placeholder="https://services.leadconnectorhq.com/hooks/…" />
						<p class="description">Each lead is POSTed as JSON: <code>event</code>, <code>first_name</code>, <code>last_name</code>, <code>email</code>, <code>phone</code>, <code>subject</code>, <code>message</code>, <code>piece</code>, <code>style</code>, <code>price</code>, <code>diamond</code>, <code>summary</code>, <code>guide</code>, <code>options</code>, <code>page</code>, <code>image</code>, <code>fields</code>, <code>items</code>, <code>tags</code>, <code>source</code> (utm_…, gclid, fbclid, ref, landing), <code>visit</code> (their visit, line by line), <code>note</code> (everything as text), and the same details as simple keys ready to map: <code><?php echo implode( '</code>, <code>', array_map( static function ( $k ) { return esc_html( OM_CRM::field_key( $k ) ); }, array_keys( class_exists( 'OM_CRM' ) ? OM_CRM::field_defs() : array() ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- each key escaped. ?></code>. In GoHighLevel: Automation › Workflows › trigger <em>Inbound Webhook</em>, paste its URL here, click "Send a test lead", then in the workflow's <em>Create/Update Contact</em> step map each <code>website_…</code> key to a contact field.</p>
						<input type="text" name="om_crm_webhook_secret" value="<?php echo esc_attr( get_option( 'om_crm_webhook_secret', '' ) ); ?>" class="regular-text" placeholder="Signing secret (optional)" aria-label="Signing secret" style="margin-top:6px" />
						<p class="description">Optional: requests then carry <code>X-OM-Signature: sha256=…</code> (HMAC of the body) so your endpoint can check they're from your site.</p></td>
					</tr>
					<tr>
						<th>Which leads</th>
						<td>
							<?php foreach ( array( 'inquiry' => 'Inquiries from every form (incl. ring builder, diamonds, AI chat)', 'saved' => '"Email me my saved designs"', 'design' => '"Email my ring design"', 'hint' => '"Drop a hint" (the person who sends it; the one they send it to is never added)' ) as $crm_ev => $crm_label ) : ?>
								<input type="hidden" name="om_crm_ev_<?php echo esc_attr( $crm_ev ); ?>" value="0" />
								<label style="display:block;margin:0 0 4px"><input type="checkbox" name="om_crm_ev_<?php echo esc_attr( $crm_ev ); ?>" value="1" <?php checked( get_option( 'om_crm_ev_' . $crm_ev, '1' ), '1' ); ?> /> <?php echo esc_html( $crm_label ); ?></label>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th><label for="om_crm_tags">Tags &amp; source</label></th>
						<td><input type="text" id="om_crm_tags" name="om_crm_tags" value="<?php echo esc_attr( get_option( 'om_crm_tags', 'website lead' ) ); ?>" class="regular-text" placeholder="website lead" />
						<p class="description">Added to every lead (comma-separated). The plugin adds its own too: <em>website inquiry</em>, <em>saved designs</em>, <em>ring design saved</em>, <em>drop a hint</em>, <em>ring builder</em>, <em>diamond inquiry</em>, <em>ai assistant</em>, <em>book a viewing</em>. Handy for GHL workflows.</p>
						<input type="text" name="om_crm_source" value="<?php echo esc_attr( get_option( 'om_crm_source', 'Website' ) ); ?>" class="regular-text" style="width:220px;margin-top:6px" placeholder="Website" aria-label="Contact source" />
						<p class="description">The contact's "source" in GoHighLevel.</p></td>
					</tr>
					<tr>
						<th>Test</th>
						<td><button type="button" class="button" data-om-crm-test data-nonce="<?php echo esc_attr( wp_create_nonce( 'om_crm_test' ) ); ?>">Send a test lead</button>
						<p class="description">Uses the <strong>saved</strong> settings (save first). Sends "Test Lead" with your admin email and a sample design; delete it in the CRM afterwards.</p>
						<div class="om-crm-test-result" aria-live="polite"></div></td>
					</tr>
					<tr>
						<th>Recent deliveries</th>
						<td data-om-live="crm-log">
							<?php
							$crm_log = array_reverse( (array) get_option( 'om_crm_log', array() ) );
							if ( ! $crm_log ) :
								?>
								<p class="description">Nothing sent yet.</p>
							<?php else : ?>
								<table class="widefat striped om-crm-log" style="max-width:820px">
									<thead><tr><th>When</th><th>Lead</th><th>To</th><th>Result</th></tr></thead>
									<tbody>
									<?php foreach ( array_slice( $crm_log, 0, 15 ) as $row ) : ?>
										<tr>
											<td><?php echo esc_html( human_time_diff( (int) $row['t'] ) . ' ago' ); ?></td>
											<td><?php echo esc_html( ( ! empty( $row['x'] ) ? 'Test · ' : '' ) . ( array( 'inquiry' => 'Inquiry', 'saved' => 'Saved designs', 'design' => 'Ring design', 'hint' => 'Drop a hint' )[ $row['e'] ] ?? $row['e'] ) . ' · ' . $row['w'] ); ?></td>
											<td><?php echo esc_html( 'ghl' === $row['to'] ? 'GoHighLevel' : 'Webhook' ); ?></td>
											<td><?php echo $row['ok'] ? '<span style="color:#008a20">&#10004; Sent</span>' : '<span style="color:#d63638">&#10008; ' . esc_html( $row['m'] . ( (int) $row['a'] > 1 ? ' (try ' . (int) $row['a'] . ')' : '' ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped. ?></td>
										</tr>
									<?php endforeach; ?>
									</tbody>
								</table>
								<p class="description">Failed leads are tried again after 5 minutes, 30 minutes, 2 hours and 6 hours. Every lead is also kept under <strong>Inquiries</strong>.</p>
							<?php endif; ?>
						</td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="search">Analytics</h2>
				<table class="form-table">
					<tr>
						<th>Events</th>
						<td>
							<input type="hidden" name="om_analytics" value="0" />
							<label><input type="checkbox" name="om_analytics" value="1" <?php checked( get_option( 'om_analytics', '1' ), '1' ); ?> /> Send what visitors do to your Google Analytics 4 / Google Tag Manager</label><br />
							<input type="hidden" name="om_analytics_meta" value="0" />
							<label><input type="checkbox" name="om_analytics_meta" value="1" <?php checked( get_option( 'om_analytics_meta', '1' ), '1' ); ?> /> …and to your Meta (Facebook / Instagram) pixel</label>
							<p class="description">Uses the tracking already on your site (e.g. Site Kit, GTM4WP, PixelYourSite, or the code in your header) — nothing is added, and nothing is sent if none is installed. Events: <code>view_item</code> (product page, quick view), <code>add_to_wishlist</code> (heart), <code>compare_designs</code>, <code>share</code>, <code>search</code>, <code>generate_lead</code> (inquiries, "Email me my list", ring design emails), <code>ring_builder_step</code>, <code>diamond_guide</code>, <code>diamond_guide_choose</code>, <code>book_viewing_click</code>, <code>true_size</code>. Meta gets ViewContent, AddToWishlist, Search, Lead and Schedule, plus custom events for the rest.</p>
							<p class="description">To check it, open any catalog page with <code>?om_debug_events=1</code> while logged in as an admin: each event is listed in the browser console (F12 › Console), with where it was sent. In GA4, mark <strong>generate_lead</strong> as a key event to count inquiries as conversions.</p>
						</td>
					</tr>
				</table>

				<h2 class="om-sec" data-om-tab="search">Search</h2>
				<table class="form-table">
					<tr>
						<th><label for="om_search_results_page">Search results page</label></th>
						<td><?php
						wp_dropdown_pages(
							array(
								'name'              => 'om_search_results_page',
								'id'                => 'om_search_results_page',
								'selected'          => (int) get_option( 'om_search_results_page', 0 ),
								'show_option_none'  => '— None —',
								'option_none_value' => '0',
							)
						);
						?>
						<p class="description">For the stand-alone search box (<code>[om_search]</code> / OM Search widget, e.g. in your header): "See all" and Enter open this page. Use a page with an OM Product Catalog widget that includes the lines you search.</p></td>
					</tr>
					<tr>
						<th><label for="om_popular_searches">Popular searches</label></th>
						<td><input type="text" id="om_popular_searches" name="om_popular_searches" value="<?php echo esc_attr( get_option( 'om_popular_searches', '' ) ); ?>" class="large-text" placeholder="Oval halo, Solitaire, Men's bands, Yellow gold" />
						<p class="description">Comma-separated. Shown when a visitor clicks into an empty search box (with their own recent searches), and as suggestions when filters find nothing.</p></td>
					</tr>
					<tr>
						<th>Learn from visitors</th>
						<td><input type="hidden" name="om_track_searches" value="0" /><label><input type="checkbox" name="om_track_searches" value="1" <?php checked( get_option( 'om_track_searches', '1' ), '1' ); ?> /> Fill "Popular searches" with what visitors search most (when the list above is empty or short)</label>
						<?php $top = get_option( 'om_search_counts', array() ); ?>
						<?php if ( is_array( $top ) && $top ) : arsort( $top ); ?>
							<p class="description">Most searched: <?php echo esc_html( implode( ', ', array_map( function ( $q, $n ) { return $q . ' (' . $n . ')'; }, array_keys( array_slice( $top, 0, 10, true ) ), array_slice( $top, 0, 10, true ) ) ) ); ?></p>
						<?php endif; ?></td>
					</tr>
				</table>

				<div class="om-admin-savebar">
					<span class="om-admin-savebar-text" aria-live="polite"></span>
					<?php submit_button( 'Save Settings', 'primary', 'submit', false ); ?>
				</div>
			</form>

			<?php $this->render_tools(); ?>

			<h2 class="om-sec" data-om-tab="overview">Shortcuts</h2>
			<p>Catalog grid shortcode: <code>[om_catalog line="engagement-rings" columns="3" per_page="12"]</code> &mdash; add <code>show_filters="yes" filter_position="left"</code> for a filter sidebar.</p>
			<p>Product lines: <?php echo esc_html( implode( ', ', array_keys( OM_Shortcodes::line_labels( true ) ) ) ); ?>.</p>
			<p>Single product pages are generated automatically at: <code><?php echo esc_html( home_url( '/catalog/{product-line}/{style-number}/' ) ); ?></code></p>
		</div>
		<?php
	}

	/**
	 * "Test connection" and "Clear cache" tools. The test walks the same
	 * path a product page does (token, product lines, one product, one
	 * quote) and reports each step, so pricing problems can be diagnosed
	 * without reading logs. Wholesale figures are shown to admins only.
	 */
	private function render_tools() {
		$tool   = isset( $_GET['om_tool'] ) ? sanitize_key( wp_unslash( $_GET['om_tool'] ) ) : '';
		$line   = isset( $_GET['om_test_line'] ) ? sanitize_title( wp_unslash( $_GET['om_test_line'] ) ) : 'engagement-rings';
		$lines  = OM_Shortcodes::line_labels();
		$result = array();

		if ( $tool && check_admin_referer( 'om_catalog_tools' ) ) {
			if ( 'clear' === $tool ) {
				$count    = OM_API_Client::clear_all_caches();
				$result[] = array( true, sprintf( 'Cleared %d cached entries. The next page view fetches fresh data.', $count ) );
			} elseif ( 'test' === $tool ) {
				$result = $this->run_connection_test( $line );
				$lines  = OM_Shortcodes::line_labels();
			} elseif ( 'ip' === $tool ) {
				$ip       = self::outgoing_ip();
				$result[] = '' !== $ip
					? array( true, 'This website\'s server reaches the internet from IP address ' . $ip . ' — this is the address to give Overnight Mountings to allow.' )
					: array( false, 'Could not find the outgoing IP (the lookup services didn\'t answer). Your host can tell you, or try again in a minute.' );
			}
		}
		?>
		<h2 class="om-sec" data-om-tab="tools">Tools</h2>
		<form method="get" action="<?php echo esc_url( admin_url( 'options-general.php' ) ); ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
			<input type="hidden" name="page" value="om-catalog-settings" />
			<?php wp_nonce_field( 'om_catalog_tools', '_wpnonce', false ); ?>
			<label for="om_test_line">Product line</label>
			<select id="om_test_line" name="om_test_line">
				<?php foreach ( $lines as $code => $label ) : ?>
					<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $code, $line ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<button class="button button-primary" name="om_tool" value="test">Test connection &amp; pricing</button>
			<button class="button" name="om_tool" value="clear">Clear cache</button>
			<button class="button" name="om_tool" value="ip">Find my server's IP</button>
		</form>
		<?php
		$st  = OM_API_Client::status();
		$ago = static function ( $t ) {
			return $t ? sprintf( '%s ago (%s)', human_time_diff( $t ), wp_date( 'M j, H:i', $t ) ) : 'never';
		};
		?>
		<table class="widefat" style="max-width:900px;margin-top:12px">
			<tbody>
				<tr><td style="width:220px"><strong>API status</strong></td><td><?php echo $st['failing'] ? '<span style="color:#d63638">&#10008; Failing</span>' : ( $st['ok_at'] ? '<span style="color:#008a20">&#10004; Working</span>' : 'No calls yet' ); ?></td></tr>
				<tr><td>Last successful call</td><td><?php echo esc_html( $ago( $st['ok_at'] ) ); ?></td></tr>
				<tr><td>Last problem</td><td><?php echo $st['err_at'] ? esc_html( $ago( $st['err_at'] ) . ' — ' . ( $st['err_on'] ?? '' ) . ( ! empty( $st['err_code'] ) ? ' (HTTP ' . $st['err_code'] . ')' : '' ) . ': ' . ( $st['err_msg'] ?? '' ) ) : 'none'; ?></td></tr>
				<tr><td>While calls fail</td><td>Listings and product pages show their last saved copy (kept a week, and kept by "Clear cache"). Live prices and diamonds need the API.</td></tr>
			</tbody>
		</table>
		<?php if ( $result ) : ?>
			<table class="widefat striped" style="max-width:900px;margin-top:12px">
				<tbody>
				<?php foreach ( $result as $row ) : ?>
					<tr>
						<td style="width:28px"><?php echo $row[0] ? '<span style="color:#008a20">&#10004;</span>' : '<span style="color:#d63638">&#10008;</span>'; ?></td>
						<td><?php echo esc_html( $row[1] ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * The address this server uses to reach other servers (what OM's
	 * firewall sees), from public "what's my IP" services. Admin-only, on
	 * request; nothing else is sent.
	 */
	private static function outgoing_ip() {
		foreach ( array( 'https://api.ipify.org', 'https://icanhazip.com', 'https://ifconfig.me/ip' ) as $service ) {
			$response = wp_remote_get( $service, array( 'timeout' => 8 ) );
			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				continue;
			}
			$ip = trim( (string) wp_remote_retrieve_body( $response ) );
			if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				return $ip;
			}
		}
		return '';
	}

	/** @return array[] Rows of [ ok (bool), message ]. */
	private function run_connection_test( $line ) {
		$rows = array();

		OM_API_Client::clear_auth_cache();
		$token = OM_API_Client::get_token();
		if ( is_wp_error( $token ) ) {
			$rows[] = array( false, 'Login to Overnight Mountings failed: ' . $token->get_error_message() );
			if ( false !== strpos( $token->get_error_message(), 'HTTP 403' ) ) {
				$ip     = self::outgoing_ip();
				$rows[] = array( false, '' !== $ip ? 'Your server\'s outgoing IP address is ' . $ip . ' — give this to Overnight Mountings and ask them to allow it.' : 'Use "Find my server\'s IP" to get the address Overnight Mountings needs.' );
			}
			return $rows;
		}
		$rows[] = array( true, 'Logged in to Overnight Mountings (access token received). Plugin version ' . OM_CATALOG_VERSION . '.' );

		delete_transient( OM_API_Client::LINES_TRANSIENT );
		$lines = OM_API_Client::get_product_lines_map( true );
		$rows[] = $lines
			? array( true, 'Product lines from OM: ' . implode( ', ', array_keys( $lines ) ) )
			: array( false, 'Could not read the product-line list (GET /products/metadata).' );
		if ( $lines && ! isset( $lines[ $line ] ) ) {
			$rows[] = array( false, sprintf( '"%s" is not one of OM\'s product lines, so a widget set to it will show nothing.', $line ) );
		}

		$list = OM_API_Client::get_products( $line, array( 'limit' => 1 ) );
		if ( is_wp_error( $list ) || empty( $list['products'][0] ) ) {
			$rows[] = array( false, 'Listing "' . $line . '" failed: ' . ( is_wp_error( $list ) ? $list->get_error_message() : 'no products returned.' ) );
			return $rows;
		}
		$product = $list['products'][0];

		// Videos: the API guide lists a videos field on every product. Report
		// what the data actually holds, never skip silently.
		$sample = OM_API_Client::get_products( $line, array( 'limit' => 100 ) );
		if ( is_wp_error( $sample ) ) {
			$rows[] = array( false, 'Videos: could not check (' . $sample->get_error_message() . ').' );
		} elseif ( empty( $sample['products'] ) ) {
			$rows[] = array( false, 'Videos: could not check (the sample listing came back empty).' );
		} else {
			$items   = (array) $sample['products'];
			$with    = 0;
			$has_key = 0;
			$first   = '';
			foreach ( $items as $item ) {
				foreach ( om_video_keys() as $key ) {
					if ( array_key_exists( $key, (array) $item ) ) {
						$has_key++;
						break;
					}
				}
				$videos = om_product_videos( $item );
				if ( $videos ) {
					$with++;
					$first = $first ? $first : $videos[0];
				}
			}
			if ( $with ) {
				$rows[] = array( true, sprintf( 'Videos: %d of the first %d products have a video (played in the gallery and as card previews). Example: %s', $with, count( $items ), $first ) );
			} elseif ( $has_key ) {
				$raw    = null;
				foreach ( $items as $item ) {
					foreach ( om_video_keys() as $key ) {
						if ( ! empty( $item[ $key ] ) ) {
							$raw = $item[ $key ];
							break 2;
						}
					}
				}
				$rows[] = null === $raw
					? array( false, sprintf( 'Videos: the video field is present but empty on all of the first %d products — Overnight Mountings has no videos for these designs yet.', count( $items ) ) )
					: array( false, 'Videos: the field has data in a format the plugin does not recognise yet: ' . mb_substr( wp_json_encode( $raw ), 0, 300 ) );
			} else {
				$rows[] = array( false, sprintf( 'Videos: the products have no video field at all (checked the first %d).', count( $items ) ) );
			}
		}

		// Photos per metal colour: can the gallery switch with the colour?
		if ( ! is_wp_error( $sample ) && ! empty( $sample['products'] ) ) {
			require_once OM_CATALOG_DIR . 'includes/functions-product-render.php';
			$by_color = 0;
			$example  = '';
			foreach ( (array) $sample['products'] as $item ) {
				$media = om_product_media( $item );
				if ( $media['by_color'] ) {
					$by_color++;
					if ( '' === $example ) {
						$counts = array_count_values( array_filter( wp_list_pluck( $media['images'], 'color' ) ) );
						$parts  = array();
						foreach ( $counts as $color => $n ) {
							$parts[] = $color . ' ' . $n;
						}
						$example = sprintf( '%s: %s', $item['style_number'] ?? '?', implode( ', ', $parts ) );
					}
				}
			}
			$first_images = array_slice( (array) ( $product['images'] ?? array() ), 0, 3 );
			$names        = array();
			foreach ( $first_images as $img ) {
				$names[] = is_array( $img ) ? wp_json_encode( $img ) : basename( (string) wp_parse_url( (string) $img, PHP_URL_PATH ) );
			}
			$rows[] = $by_color
				? array( true, sprintf( 'Photos by metal colour: %d of the first %d products have photos told apart by colour, so the gallery switches with the colour picked (e.g. %s).', $by_color, count( $sample['products'] ), $example ) )
				: array( false, sprintf( 'Photos by metal colour: not detected on the first %d products — the gallery keeps the same photos whatever colour is picked. Image names look like: %s', count( $sample['products'] ), implode( ' | ', $names ) ) );
			if ( ! empty( $product['product_variants'][0] ) && is_array( $product['product_variants'][0] ) ) {
				$rows[] = array( true, 'Variant fields from OM: ' . implode( ', ', array_keys( $product['product_variants'][0] ) ) );
			}
		}

		// The fields each product actually carries, to diagnose data questions.
		$rows[] = array( true, 'Product fields from OM: ' . implode( ', ', array_keys( (array) $product ) ) );

		$rows[]  = array( true, sprintf( 'Listing "%s": %s products. First: %s (style %s).', $line, number_format_i18n( (int) ( $list['total_count'] ?? 0 ) ), $product['title'] ?? '?', $product['style_number'] ?? '?' ) );

		$quote = OM_API_Client::get_quotation(
			$line,
			array_filter(
				array(
					'styleNumber' => $product['style_number'] ?? '',
					'metal'       => $product['default_metal'] ?? '',
					'color'       => $product['default_color'] ?? '',
					'level'       => $product['default_level'] ?? '',
					'quality'     => $product['default_quality'] ?? '',
				)
			)
		);
		if ( is_wp_error( $quote ) || ! isset( $quote['price'] ) ) {
			$rows[] = array( false, 'Quote failed: ' . ( is_wp_error( $quote ) ? $quote->get_error_message() : 'no price in the response.' ) );
			return $rows;
		}
		$wholesale = floatval( $quote['price'] );
		$rows[]    = array( true, sprintf( 'Quote OK: wholesale %s (%s %s, %s).', om_format_price( $wholesale ), $quote['metal'] ?? '', $quote['color'] ?? '', $quote['level'] ?? '' ) );
		$rows[]    = om_markup_is_configured()
			? array( true, sprintf( 'Visitors see %s (markup applied). Prices are live on the site.', om_format_price( om_apply_markup( $wholesale ) ) ) )
			: array( false, 'No markup is set, so visitors see the "no price" text/buttons instead of prices. Set a markup above to show prices.' );

		return $rows;
	}

	/**
	 * Inquiry form field editor: a table of rows the admin can add, remove
	 * and reorder. Saved as the om_inquiry_fields option (the form's field
	 * list, in row order).
	 */
	private function render_field_editor() {
		$fields = OM_Inquiry::global_fields();
		$types  = array(
			'text'       => 'Text',
			'email'      => 'Email',
			'tel'        => 'Phone',
			'textarea'   => 'Paragraph',
			'select'     => 'Dropdown',
			'radio'      => 'Radio buttons',
			'checkboxes' => 'Checkboxes (several)',
			'checkbox'   => 'Single checkbox',
			'date'       => 'Date',
			'number'     => 'Number',
		);
		$row = function ( $i, $field ) use ( $types ) {
			$n = 'om_inquiry_fields[' . $i . ']';
			ob_start();
			?>
			<tr class="om-fe-row">
				<td class="om-fe-move"><button type="button" class="button-link om-fe-up" aria-label="Move up">&#9650;</button><button type="button" class="button-link om-fe-down" aria-label="Move down">&#9660;</button></td>
				<td><input type="text" name="<?php echo esc_attr( $n ); ?>[label]" value="<?php echo esc_attr( $field['label'] ?? '' ); ?>" placeholder="Label" class="regular-text" style="width:100%" />
					<input type="hidden" name="<?php echo esc_attr( $n ); ?>[key]" value="<?php echo esc_attr( $field['key'] ?? '' ); ?>" /></td>
				<td><select name="<?php echo esc_attr( $n ); ?>[type]" class="om-fe-type">
					<?php foreach ( $types as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $field['type'] ?? 'text', $value ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select></td>
				<td><input type="text" name="<?php echo esc_attr( $n ); ?>[placeholder]" value="<?php echo esc_attr( $field['placeholder'] ?? '' ); ?>" placeholder="Placeholder" style="width:100%" /></td>
				<td><textarea name="<?php echo esc_attr( $n ); ?>[options]" rows="2" placeholder="Choices, one per line" style="width:100%"><?php echo esc_textarea( implode( "\n", (array) ( $field['options'] ?? array() ) ) ); ?></textarea></td>
				<td><select name="<?php echo esc_attr( $n ); ?>[width]">
					<option value="full" <?php selected( $field['width'] ?? 'full', 'full' ); ?>>Full</option>
					<option value="half" <?php selected( $field['width'] ?? 'full', 'half' ); ?>>Half</option>
				</select></td>
				<td style="text-align:center"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[required]" value="1" <?php checked( ! empty( $field['required'] ) ); ?> /></td>
				<td><button type="button" class="button-link-delete om-fe-remove">Remove</button></td>
			</tr>
			<?php
			return ob_get_clean();
		};
		?>
		<table class="widefat striped om-field-editor" style="max-width:1100px">
			<thead><tr><th style="width:44px"></th><th>Label</th><th>Type</th><th>Placeholder</th><th>Choices <span class="description">(dropdown, radio, checkboxes)</span></th><th>Width</th><th>Required</th><th></th></tr></thead>
			<tbody>
				<?php
				foreach ( $fields as $i => $field ) {
					echo $row( $i, $field ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the row template.
				}
				?>
			</tbody>
		</table>
		<p>
			<button type="button" class="button om-fe-add">+ Add field</button>
			<button type="button" class="button-link om-fe-reset" style="margin-left:12px">Restore default fields</button>
		</p>
		<script type="text/template" id="om-fe-template"><?php echo $row( '__i__', array( 'label' => '', 'type' => 'text', 'width' => 'full' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in the row template. ?></script>
		<script>
		( function () {
			var table = document.querySelector( '.om-field-editor tbody' );
			var tpl = document.getElementById( 'om-fe-template' ).innerHTML;
			var n = Date.now();
			document.querySelector( '.om-fe-add' ).addEventListener( 'click', function () {
				table.insertAdjacentHTML( 'beforeend', tpl.split( '__i__' ).join( 'n' + ( n++ ) ) );
				table.lastElementChild.querySelector( 'input[type=text]' ).focus();
			} );
			document.querySelector( '.om-fe-reset' ).addEventListener( 'click', function () {
				if ( window.confirm( 'Replace the fields with the default form (Name, Email, Phone, Preferred contact, Message)? Save to apply.' ) ) {
					table.innerHTML = '';
					var input = document.createElement( 'input' );
					input.type = 'hidden'; input.name = 'om_inquiry_fields'; input.value = '';
					table.closest( 'form' ).appendChild( input );
				}
			} );
			table.addEventListener( 'click', function ( e ) {
				var row = e.target.closest( '.om-fe-row' );
				if ( ! row ) { return; }
				if ( e.target.classList.contains( 'om-fe-remove' ) ) { row.remove(); }
				if ( e.target.classList.contains( 'om-fe-up' ) && row.previousElementSibling ) { row.parentNode.insertBefore( row, row.previousElementSibling ); }
				if ( e.target.classList.contains( 'om-fe-down' ) && row.nextElementSibling ) { row.parentNode.insertBefore( row.nextElementSibling, row ); }
			} );
		} )();
		</script>
		<?php
	}
}
