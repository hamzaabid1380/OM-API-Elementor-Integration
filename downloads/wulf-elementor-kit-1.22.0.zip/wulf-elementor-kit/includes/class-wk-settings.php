<?php
/**
 * Site-wide kit settings: business details, opening hours, brand colors and fonts, site header/footer, reviews.
 * Widgets read these as their defaults, so a phone number or an hour changes everywhere at once.
 *
 * @package WulfKit
 */

defined( 'ABSPATH' ) || exit;

class WK_Settings {

	const OPTION = 'wk_settings';

	/** @var array|null */
	private static $cache = null;

	public static function defaults() {
		return array(
			'name'          => 'Wulf Diamond Jewelers',
			'phone'         => '(219) 247-7082',
			'phone2'        => '(219) 400-7817',
			'email'         => '',
			'address'       => '10460 Broadway, Crown Point, IN 46307',
			'address_note'  => 'Crown Village · serving all of Lake County',
			'maps_url'      => 'https://www.google.com/maps/search/?api=1&query=Wulf+Diamond+Jewelers+10460+Broadway+Crown+Point+IN+46307',
			// The map in the Visit sections (a section can choose its own in Elementor).
			'visit_map'     => 'google',
			'map_zoom'      => '16',
			'schema'        => '1',
			'geo'           => '',
			'price_range'   => '',
			'profiles'      => '',
			'store_img'     => '',
			'timezone'      => 'America/Chicago',
			'hours'         => array(
				0 => array( 'closed' => '1', 'open' => '10:00', 'close' => '16:00' ),
				1 => array( 'closed' => '', 'open' => '10:00', 'close' => '18:00' ),
				2 => array( 'closed' => '', 'open' => '10:00', 'close' => '18:00' ),
				3 => array( 'closed' => '', 'open' => '10:00', 'close' => '18:00' ),
				4 => array( 'closed' => '', 'open' => '10:00', 'close' => '18:00' ),
				5 => array( 'closed' => '', 'open' => '10:00', 'close' => '18:00' ),
				6 => array( 'closed' => '', 'open' => '10:00', 'close' => '17:00' ),
			),
			'c_bg'          => '#ffffff',
			'c_ivory'       => '#f7f5f1',
			'c_line'        => '#e7e4de',
			'c_ink'         => '#0f1217',
			'c_text'        => '#262a31',
			'c_sub'         => '#5a5f67',
			'c_night'       => '#0b0e14',
			'c_gold'        => '#d6b97f',
			'c_gold_deep'   => '#b8955a',
			'c_gold_ink'    => '#7a5b24',
			'font_serif'    => 'Fraunces',
			'font_sans'     => 'Manrope',
			'google_fonts'  => '1',
			'calm_all'      => '',
			'look'          => 'night',
			'corners'       => 'auto',
			'mark'          => 'WULF ◆ 1971',
			'turn_speed'    => '0.6',
			'radius'        => '10',
			'max_width'     => '1240',
			'tray'          => '1',
			'actbar'        => '1',
			'book_pill'     => '1',
			'assistant_home' => '1',
			'act_call'      => 'Call',
			'act_book'      => 'Book a free consultation',
			'act_dir'       => 'Directions',
			'book_url'      => '#visit',
			'book_panel'    => '1',
			'book_style'    => 'popup',
			'book_img'      => '',
			'book_points'   => "Free, no obligation\nGIA-certified jewelers\nIndependent since 1971",
			'book_title'    => 'Book your free consultation',
			'book_sub'      => 'Free, no obligation. We\'ll confirm by call or text.',
			'book_topics'   => "Engagement ring | Any inspiration photos you love\nWedding bands | Your engagement ring, so we can match it\nCustom design | Sketches, photos or a family stone\nRepair | The piece that needs work\nAppraisal | The piece and any grading reports\nSelling | The pieces you want to sell and a photo ID\nFinancing | A photo ID",
			'book_done'     => 'We\'ll confirm your visit on {day} ({time}) by {pref} within one business day.',
			'track'         => '1',
			'to_om_leads'   => '1',
			'header_tpl'    => '',
			'footer_tpl'    => '',
			// Another reviews plugin's shortcode: every Reviews section shows that plugin's widget.
			'reviews_shortcode' => '',
			'featurable_id' => '',
			'google_key'    => '',
			'google_place'  => '',
			'reviews_hours' => '12',
			'om_media'      => 'https://overnightmountings.s3.amazonaws.com/',
			// The full brand films with sound ("Watch the film"), from the Media Library or any link.
			'film_motion'   => '',
			'film_suitcase' => '',
		);
	}

	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = self::merge( self::defaults(), is_array( $saved ) ? $saved : array() );
		}
		return self::$cache;
	}

	public static function get( $key, $fallback = '' ) {
		$all = self::all();
		return isset( $all[ $key ] ) && '' !== $all[ $key ] ? $all[ $key ] : $fallback;
	}

	private static function merge( $def, $saved ) {
		foreach ( $saved as $k => $v ) {
			if ( isset( $def[ $k ] ) && is_array( $def[ $k ] ) && is_array( $v ) ) {
				$def[ $k ] = self::merge( $def[ $k ], $v );
			} elseif ( array_key_exists( $k, $def ) ) {
				$def[ $k ] = $v;
			}
		}
		return $def;
	}

	/** Booking topics from the settings textarea: [ [ topic, what to bring ], ... ]. */
	public static function book_topics() {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) self::get( 'book_topics' ) ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( '' !== $p[0] ) {
				$out[] = array( $p[0], $p[1] ?? '' );
			}
		}
		return $out;
	}

	/** "(219) 247-7082" -> "tel:+12192477082". */
	public static function tel( $phone = null ) {
		$d = preg_replace( '/\D+/', '', null === $phone ? self::get( 'phone' ) : $phone );
		if ( 10 === strlen( $d ) ) {
			$d = '1' . $d;
		}
		return $d ? 'tel:+' . $d : '';
	}

	/** Hours as [day => [openHour, closeHour]] (null when closed), for the script. */
	public static function hours_for_js() {
		$out = array();
		foreach ( self::get( 'hours' ) as $d => $h ) {
			if ( ! empty( $h['closed'] ) ) {
				$out[ (int) $d ] = null;
				continue;
			}
			$out[ (int) $d ] = array( self::to_hour( $h['open'] ), self::to_hour( $h['close'] ) );
		}
		ksort( $out );
		return array_values( $out + array_fill( 0, 7, null ) );
	}

	private static function to_hour( $hm ) {
		$p = explode( ':', (string) $hm );
		return round( (int) $p[0] + ( isset( $p[1] ) ? (int) $p[1] / 60 : 0 ), 3 );
	}

	/** "10 am", "5:30 pm". */
	public static function hfmt( $hm ) {
		$p = explode( ':', (string) $hm );
		$h = (int) $p[0];
		$m = isset( $p[1] ) ? (int) $p[1] : 0;
		$s = ( $h % 12 ? $h % 12 : 12 ) . ( $m ? ':' . str_pad( (string) $m, 2, '0', STR_PAD_LEFT ) : '' );
		return $s . ( $h >= 12 ? ' pm' : ' am' );
	}

	/** One-line summary like "Mon–Fri 10–6 · Sat 10–5". */
	public static function hours_summary() {
		$days  = array( 1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 0 => 'Sun' );
		$h     = self::get( 'hours' );
		$short = static function ( $hm ) {
			$p = explode( ':', (string) $hm );
			$x = (int) $p[0] % 12 ? (int) $p[0] % 12 : 12;
			return $x . ( ! empty( $p[1] ) && '00' !== $p[1] ? ':' . $p[1] : '' );
		};
		$groups = array();
		foreach ( $days as $d => $label ) {
			$key = empty( $h[ $d ]['closed'] ) ? $short( $h[ $d ]['open'] ) . '–' . $short( $h[ $d ]['close'] ) : '';
			if ( '' === $key ) {
				continue;
			}
			$last = count( $groups ) - 1;
			if ( $last >= 0 && $groups[ $last ]['key'] === $key && $groups[ $last ]['to'] === self::prev( $d ) ) {
				$groups[ $last ]['to'] = $d;
				$groups[ $last ]['to_l'] = $label;
			} else {
				$groups[] = array( 'key' => $key, 'from_l' => $label, 'to' => $d, 'to_l' => $label );
			}
		}
		$parts = array();
		foreach ( $groups as $g ) {
			$parts[] = ( $g['from_l'] === $g['to_l'] ? $g['from_l'] : $g['from_l'] . '–' . $g['to_l'] ) . ' ' . $g['key'];
		}
		return implode( ' · ', $parts );
	}

	private static function prev( $d ) {
		return 1 === $d ? -1 : ( 0 === $d ? 6 : $d - 1 );
	}

	/* ---------- Admin page ---------- */

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'init', array( __CLASS__, 'upgrade' ), 5 );
		add_action( 'add_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
		add_action( 'update_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
	}

	/** Forget the settings read so far (they were just saved). */
	public static function flush() {
		self::$cache = null;
	}

	/** One-time updates of saved settings when an old default wording was kept. */
	public static function upgrade() {
		$done = (string) get_option( 'wk_settings_rev', '' );
		if ( version_compare( $done ? $done : '0', '1.9.0', '>=' ) ) {
			return;
		}
		$saved = get_option( self::OPTION, array() );
		if ( is_array( $saved ) && isset( $saved['act_book'] ) && 'Book a visit' === $saved['act_book'] ) {
			$saved['act_book'] = 'Book a free consultation';
			update_option( self::OPTION, $saved );
			self::$cache = null;
		}
		update_option( 'wk_settings_rev', '1.9.0', false );
	}

	public static function menu() {
		add_menu_page( __( 'Wulf Kit', 'wulf-kit' ), __( 'Wulf Kit', 'wulf-kit' ), 'manage_options', 'wulf-kit', array( __CLASS__, 'page' ), 'dashicons-star-filled', 58 );
		add_submenu_page( 'wulf-kit', __( 'Kit settings', 'wulf-kit' ), __( 'Settings', 'wulf-kit' ), 'manage_options', 'wulf-kit', array( __CLASS__, 'page' ) );
	}

	public static function register() {
		register_setting( 'wk_settings', self::OPTION, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
	}

	public static function sanitize( $in ) {
		$def = self::defaults();
		$out = array();
		foreach ( $def as $k => $v ) {
			if ( 'hours' === $k ) {
				$out['hours'] = array();
				for ( $d = 0; $d < 7; $d++ ) {
					$row               = isset( $in['hours'][ $d ] ) ? (array) $in['hours'][ $d ] : array();
					$out['hours'][ $d ] = array(
						'closed' => empty( $row['closed'] ) ? '' : '1',
						'open'   => preg_match( '/^\d{1,2}:\d{2}$/', $row['open'] ?? '' ) ? $row['open'] : $v[ $d ]['open'],
						'close'  => preg_match( '/^\d{1,2}:\d{2}$/', $row['close'] ?? '' ) ? $row['close'] : $v[ $d ]['close'],
					);
				}
				continue;
			}
			$val = $in[ $k ] ?? '';
			if ( 0 === strpos( $k, 'c_' ) ) {
				$out[ $k ] = sanitize_hex_color( $val ) ? sanitize_hex_color( $val ) : $v;
			} elseif ( in_array( $k, array( 'maps_url', 'om_media', 'book_img', 'film_motion', 'film_suitcase', 'store_img' ), true ) ) {
				$out[ $k ] = esc_url_raw( $val );
			} elseif ( 'email' === $k ) {
				$out[ $k ] = sanitize_email( $val );
			} elseif ( 'turn_speed' === $k ) {
				$out[ $k ] = in_array( (string) $val, array( '0.5', '0.6', '0.75', '1' ), true ) ? (string) $val : $v;
			} elseif ( in_array( $k, array( 'google_fonts', 'tray', 'actbar', 'book_pill', 'assistant_home', 'to_om_leads', 'calm_all', 'book_panel', 'track', 'schema' ), true ) ) {
				$out[ $k ] = empty( $val ) ? '' : '1';
			} elseif ( 'visit_map' === $k ) {
				$out[ $k ] = in_array( (string) $val, array( 'google', 'drawn', 'none' ), true ) ? (string) $val : $v;
			} elseif ( 'map_zoom' === $k ) {
				$out[ $k ] = (string) max( 12, min( 19, (int) $val ? (int) $val : (int) $v ) );
			} elseif ( 'look' === $k ) {
				$out[ $k ] = in_array( (string) $val, array( 'night', 'day' ), true ) ? (string) $val : $v;
			} elseif ( 'corners' === $k ) {
				$out[ $k ] = in_array( (string) $val, array( 'auto', 'round', 'square', 'cut' ), true ) ? (string) $val : $v;
			} elseif ( 'book_style' === $k ) {
				$out[ $k ] = in_array( (string) $val, array( 'popup', 'drawer' ), true ) ? (string) $val : $v;
			} elseif ( in_array( $k, array( 'book_topics', 'book_points' ), true ) ) {
				$out[ $k ] = sanitize_textarea_field( $val );
			} elseif ( 'profiles' === $k ) {
				$out[ $k ] = implode( "\n", WK_Schema::profiles( is_scalar( $val ) ? (string) $val : '' ) );
			} elseif ( 'geo' === $k ) {
				$out[ $k ] = WK_Schema::geo( $val ) ? preg_replace( '/\s*,\s*/', ', ', trim( (string) $val ) ) : '';
			} elseif ( 'price_range' === $k ) {
				$out[ $k ] = mb_substr( sanitize_text_field( $val ), 0, 100 );
			} elseif ( 'featurable_id' === $k ) {
				$out[ $k ] = WK_Reviews::featurable_id( is_scalar( $val ) ? (string) $val : '' ); // Also from a pasted link or embed code.
			} elseif ( 'reviews_shortcode' === $k ) {
				$out[ $k ] = WK_Reviews::clean_shortcode( is_scalar( $val ) ? (string) $val : '' );
			} else {
				$out[ $k ] = sanitize_text_field( $val );
			}
		}
		// Saving fetches the reviews afresh on the next page view.
		WK_Reviews::forget();
		WK_Reviews::forget( $out );
		self::$cache = null;
		return $out;
	}

	private static function field( $key, $label, $type = 'text', $help = '', $opts = array() ) {
		$v    = self::get( $key );
		$name = self::OPTION . '[' . $key . ']';
		echo '<tr><th scope="row"><label for="wk-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'check' === $type ) {
			echo '<label><input type="checkbox" id="wk-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="1"' . checked( '1', self::all()[ $key ], false ) . '> ' . esc_html( $help ) . '</label>';
			$help = '';
		} elseif ( 'color' === $type ) {
			echo '<input type="text" class="wk-color" id="wk-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $v ) . '" data-default-color="' . esc_attr( self::defaults()[ $key ] ) . '">';
		} elseif ( 'speed' === $type ) {
			$opts = array( '0.5' => __( 'Slow', 'wulf-kit' ), '0.6' => __( 'Relaxed (recommended)', 'wulf-kit' ), '0.75' => __( 'A little slower than normal', 'wulf-kit' ), '1' => __( 'Normal (as filmed)', 'wulf-kit' ) );
			echo '<select id="wk-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( $opts as $ov => $ol ) {
				echo '<option value="' . esc_attr( $ov ) . '"' . selected( $ov, (string) self::all()[ $key ], false ) . '>' . esc_html( $ol ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'select' === $type ) {
			echo '<select id="wk-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( $opts as $ov => $ol ) {
				echo '<option value="' . esc_attr( $ov ) . '"' . selected( (string) $ov, (string) self::all()[ $key ], false ) . '>' . esc_html( $ol ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'textarea' === $type ) {
			echo '<textarea class="large-text" rows="' . (int) ( $opts['rows'] ?? 7 ) . '" id="wk-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '">' . esc_textarea( self::all()[ $key ] ) . '</textarea>';
		} elseif ( 'template' === $type ) {
			$posts = get_posts( array( 'post_type' => 'elementor_library', 'numberposts' => 100, 'post_status' => 'publish' ) );
			echo '<select id="wk-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '"><option value="">' . esc_html__( '— Use the theme\'s own —', 'wulf-kit' ) . '</option>';
			foreach ( $posts as $p ) {
				echo '<option value="' . (int) $p->ID . '"' . selected( (string) $p->ID, (string) self::all()[ $key ], false ) . '>' . esc_html( $p->post_title ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'video' === $type ) {
			// A link, with a button to pick (or upload) the video in the Media Library.
			echo '<div class="wk-media-row"><input type="url" class="regular-text code" id="wk-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( self::all()[ $key ] ) . '" placeholder="https://"> ';
			echo '<button type="button" class="button wk-media-pick" data-for="wk-' . esc_attr( $key ) . '" data-title="' . esc_attr( $label ) . '">' . esc_html__( 'Choose from Media Library', 'wulf-kit' ) . '</button> ';
			echo '<button type="button" class="button-link wk-media-clear" data-for="wk-' . esc_attr( $key ) . '"' . ( '' === (string) self::all()[ $key ] ? ' hidden' : '' ) . '>' . esc_html__( 'Remove', 'wulf-kit' ) . '</button></div>';
		} else {
			echo '<input type="' . esc_attr( $type ) . '" class="regular-text" id="wk-' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( self::all()[ $key ] ) . '">';
		}
		if ( $help ) {
			echo '<p class="description">' . wp_kses_post( $help ) . '</p>';
		}
		echo '</td></tr>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_media();
		$days = array( 1 => __( 'Monday', 'wulf-kit' ), 2 => __( 'Tuesday', 'wulf-kit' ), 3 => __( 'Wednesday', 'wulf-kit' ), 4 => __( 'Thursday', 'wulf-kit' ), 5 => __( 'Friday', 'wulf-kit' ), 6 => __( 'Saturday', 'wulf-kit' ), 0 => __( 'Sunday', 'wulf-kit' ) );
		$h    = self::get( 'hours' );
		?>
		<div class="wrap wk-admin">
			<h1><?php esc_html_e( 'Wulf Kit settings', 'wulf-kit' ); ?></h1>
			<p><?php esc_html_e( 'These are used by every Wulf widget, so a change here updates the whole site. Each widget can still override colors and text in Elementor.', 'wulf-kit' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'wk_settings' ); ?>
				<h2><?php esc_html_e( 'Your business', 'wulf-kit' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					self::field( 'name', __( 'Business name', 'wulf-kit' ) );
					self::field( 'phone', __( 'Main phone', 'wulf-kit' ) );
					self::field( 'phone2', __( 'Second phone', 'wulf-kit' ), 'text', __( 'Shown in the footer. Leave empty to hide.', 'wulf-kit' ) );
					self::field( 'address', __( 'Address', 'wulf-kit' ), 'text', __( 'Street, town, state and ZIP, with commas between them (10460 Broadway, Crown Point, IN 46307): Google reads the parts in that order.', 'wulf-kit' ) );
					self::field( 'address_note', __( 'Under the address', 'wulf-kit' ) );
					self::field( 'maps_url', __( 'Directions link', 'wulf-kit' ), 'url' );
					self::field( 'visit_map', __( 'Map in the Visit sections', 'wulf-kit' ), 'select', __( 'The live Google map shows the real streets and places around the shop, with your pin; visitors can move and zoom it. The drawn map is a simple illustration that opens Google Maps. A Visit section can still choose its own in Elementor (Showroom › Map).', 'wulf-kit' ), array( 'google' => __( 'Live Google map', 'wulf-kit' ), 'drawn' => __( 'Simple drawn map', 'wulf-kit' ), 'none' => __( 'No map', 'wulf-kit' ) ) );
					self::field( 'map_zoom', __( 'Map zoom', 'wulf-kit' ), 'number', __( 'For the live map, from 12 (more of the town) to 19 (closest). 16 shows the streets around the shop.', 'wulf-kit' ) );
					self::field( 'email', __( 'Visit requests go to', 'wulf-kit' ), 'email', __( 'Empty uses the site admin email.', 'wulf-kit' ) );
					self::field( 'to_om_leads', __( 'Send to your CRM', 'wulf-kit' ), 'check', __( 'Also pass visit requests and sign-ups to the OM Catalog plugin\'s lead sending (GoHighLevel / webhook), when that plugin is active.', 'wulf-kit' ) );
					?>
				</table>

				<h2><?php esc_html_e( 'Opening hours', 'wulf-kit' ); ?></h2>
				<p><?php esc_html_e( 'Drives "Open today until 6 pm", the day bar and the hours list.', 'wulf-kit' ); ?></p>
				<table class="form-table" role="presentation">
					<?php foreach ( $days as $d => $label ) : ?>
						<tr><th scope="row"><?php echo esc_html( $label ); ?></th><td>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[hours][<?php echo (int) $d; ?>][closed]" value="1" <?php checked( '1', $h[ $d ]['closed'] ); ?>> <?php esc_html_e( 'Closed', 'wulf-kit' ); ?></label>
							&nbsp; <input type="time" name="<?php echo esc_attr( self::OPTION ); ?>[hours][<?php echo (int) $d; ?>][open]" value="<?php echo esc_attr( $h[ $d ]['open'] ); ?>" aria-label="<?php echo esc_attr( $label . ' opens' ); ?>">
							– <input type="time" name="<?php echo esc_attr( self::OPTION ); ?>[hours][<?php echo (int) $d; ?>][close]" value="<?php echo esc_attr( $h[ $d ]['close'] ); ?>" aria-label="<?php echo esc_attr( $label . ' closes' ); ?>">
						</td></tr>
					<?php endforeach; ?>
					<?php self::field( 'timezone', __( 'Time zone', 'wulf-kit' ), 'text', __( 'For example America/Chicago.', 'wulf-kit' ) ); ?>
				</table>

				<h2 id="wk-google-business"><?php esc_html_e( 'Business details for Google', 'wulf-kit' ); ?></h2>
				<p><?php esc_html_e( 'Google uses these to match your site to your shop in search and on Maps: the name, address, main phone and opening hours above, plus anything you add here. They go into the homepage as structured data (a JewelryStore entry) that visitors don\'t see. The email for visit requests stays private.', 'wulf-kit' ); ?></p>
				<table class="form-table" role="presentation">
					<?php
					$other = WK_Schema::other();
					self::field( 'schema', __( 'Business details', 'wulf-kit' ), 'check', __( 'Add your business details to the homepage for Google', 'wulf-kit' ) );
					if ( $other ) {
						/* translators: %s: an SEO plugin's name */
						echo '<tr><th></th><td><p class="description">' . esc_html( sprintf( __( 'Left out for now: %s already publishes your business details, and Google should get only one version.', 'wulf-kit' ), $other ) ) . '</p></td></tr>';
					}
					self::field( 'geo', __( 'Map pin', 'wulf-kit' ), 'text', __( 'Optional. Latitude and longitude, like 41.41672, -87.36543. In Google Maps, right-click your pin: the numbers at the top of the menu copy them.', 'wulf-kit' ) );
					self::field( 'price_range', __( 'Price range', 'wulf-kit' ), 'text', __( 'Optional, like $$$ or $500 to $25,000.', 'wulf-kit' ) );
					self::field( 'profiles', __( 'Your profiles elsewhere', 'wulf-kit' ), 'textarea', __( 'Optional. One link per line: your Google Business Profile, Facebook, Instagram, Yelp, The Knot…', 'wulf-kit' ), array( 'rows' => 4 ) );
					self::field( 'store_img', __( 'Store photo', 'wulf-kit' ), 'url', __( 'Optional link to a photo of the showroom or the storefront. Empty uses the showroom photo that comes with the kit.', 'wulf-kit' ) );
					?>
					<tr><th scope="row"><?php esc_html_e( 'What Google gets', 'wulf-kit' ); ?></th><td>
						<details><summary><?php esc_html_e( 'Show', 'wulf-kit' ); ?></summary>
							<pre class="wk-schema-preview"><?php echo esc_html( wp_json_encode( WK_Schema::store(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ); ?></pre>
						</details>
						<p class="description">
							<?php
							/* translators: %s: link to Google's Rich Results Test for the homepage */
							echo wp_kses_post( sprintf( __( 'Once the site is live, %s checks it the way Google reads it.', 'wulf-kit' ), '<a href="' . esc_url( 'https://search.google.com/test/rich-results?url=' . rawurlencode( home_url( '/' ) ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Google\'s Rich Results Test', 'wulf-kit' ) . '</a>' ) );
							?>
						</p>
					</td></tr>
				</table>

				<h2><?php esc_html_e( 'Brand colors and fonts', 'wulf-kit' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					self::field( 'c_gold', __( 'Gold (accent)', 'wulf-kit' ), 'color' );
					self::field( 'c_gold_deep', __( 'Deep gold (lines, active)', 'wulf-kit' ), 'color' );
					self::field( 'c_gold_ink', __( 'Gold text on light', 'wulf-kit' ), 'color' );
					self::field( 'c_ink', __( 'Ink (headings, dark buttons)', 'wulf-kit' ), 'color' );
					self::field( 'c_text', __( 'Body text', 'wulf-kit' ), 'color' );
					self::field( 'c_sub', __( 'Secondary text', 'wulf-kit' ), 'color' );
					self::field( 'c_night', __( 'Dark sections', 'wulf-kit' ), 'color' );
					self::field( 'c_ivory', __( 'Ivory sections', 'wulf-kit' ), 'color' );
					self::field( 'c_line', __( 'Lines and borders', 'wulf-kit' ), 'color' );
					self::field( 'c_bg', __( 'Page background', 'wulf-kit' ), 'color' );
					self::field( 'font_serif', __( 'Heading font', 'wulf-kit' ) );
					self::field( 'font_sans', __( 'Body font', 'wulf-kit' ) );
					self::field( 'google_fonts', __( 'Load from Google Fonts', 'wulf-kit' ), 'check', __( 'Turn off if your theme or Elementor already loads these fonts.', 'wulf-kit' ) );
					self::field( 'calm_all', __( 'Calmer look everywhere', 'wulf-kit' ), 'check', __( 'Use the quieter style of "Home (simpler)" on every page: fewer boxes and small labels, gold italics only in the hero, slightly larger text.', 'wulf-kit' ) );
					self::field( 'look', __( 'Look', 'wulf-kit' ), 'select', __( 'Daylight: warm paper and white instead of the dark header, hero and footer, ink buttons, gold kept for small accents, a hallmark stamp in the hero and a fine line in white, yellow and rose gold under the big headlines. One page can choose its own look in Elementor (Page settings › Wulf look); "Home (daylight)" in the page library uses Daylight. To switch the whole site with its homepage in one go, use Wulf Kit › Design sets.', 'wulf-kit' ), array( 'night' => __( 'Night (dark header, hero and footer)', 'wulf-kit' ), 'day' => __( 'Daylight', 'wulf-kit' ) ) );
					self::field( 'corners', __( 'Corners', 'wulf-kit' ), 'select', __( 'The shape of buttons, cards, fields and frames. Cut corners are cut away like a step-cut diamond and go with the Daylight look (on Night pages they show square); dots, metal swatches and faces stay round either way. Automatic: rounded with the Night look, square with Daylight. Square and cut corners also reach the shop (OM Catalog): its buttons, fields and cards turn square, and with cut corners its product pictures and main buttons are cut too.', 'wulf-kit' ), array( 'auto' => __( 'Automatic', 'wulf-kit' ), 'round' => __( 'Rounded', 'wulf-kit' ), 'square' => __( 'Square', 'wulf-kit' ), 'cut' => __( 'Cut, like a step-cut diamond', 'wulf-kit' ) ) );
					self::field( 'mark', __( 'Hallmark stamp', 'wulf-kit' ), 'text', __( 'The small stamp before the hero\'s label in the Daylight look, like the mark inside a ring. Leave empty for none.', 'wulf-kit' ) );
					self::field( 'turn_speed', __( '360° videos turn', 'wulf-kit' ), 'speed', __( 'How fast the turning ring videos play everywhere on the site.', 'wulf-kit' ) );
					self::field( 'radius', __( 'Corner radius (px)', 'wulf-kit' ), 'number' );
					self::field( 'max_width', __( 'Content width (px)', 'wulf-kit' ), 'number' );
					?>
				</table>

				<h2><?php esc_html_e( 'Site-wide pieces', 'wulf-kit' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					self::field( 'header_tpl', __( 'Site header', 'wulf-kit' ), 'template', __( 'An Elementor template (Templates › Saved Templates) shown at the top of every page instead of the theme header. The importer creates "Wulf · Header" for you.', 'wulf-kit' ) );
					self::field( 'footer_tpl', __( 'Site footer', 'wulf-kit' ), 'template', __( 'Shown at the bottom of every page instead of the theme footer.', 'wulf-kit' ) );
					self::field( 'tray', __( 'Saved pieces tray', 'wulf-kit' ), 'check', __( 'Visitors can save pieces with the heart and bring them to their visit. With the OM Catalog plugin\'s Saved designs on (Settings › OM Catalog › Look & feel), the hearts save into its list, the same one as on catalog pages, and the header button opens its Saved panel.', 'wulf-kit' ) );
					self::field( 'actbar', __( 'Phone action bar', 'wulf-kit' ), 'check', __( 'Call / Book / Directions bar at the bottom of the screen on phones.', 'wulf-kit' ) );
					self::field( 'book_pill', __( 'Booking button on computers', 'wulf-kit' ), 'check', __( 'After the first screen, a slim bar at the bottom with today\'s hours, "Book a free consultation" and your phone number. It steps aside near the booking form and the footer, and visitors can close it.', 'wulf-kit' ) );
					self::field( 'assistant_home', __( 'Jeweller assistant on the homepage', 'wulf-kit' ), 'check', __( 'Shows the "Ask our jeweller" chat from the OM Catalog plugin on your homepage (and on homepage versions from the page library), with its starter question. The chat itself is switched on and set up in Settings › OM Catalog › AI assistant.', 'wulf-kit' ) );
					self::field( 'act_call', __( 'Action bar: call label', 'wulf-kit' ) );
					self::field( 'act_book', __( 'Action bar: book label', 'wulf-kit' ) );
					self::field( 'act_dir', __( 'Action bar: directions label', 'wulf-kit' ) );
					self::field( 'book_url', __( 'Booking link', 'wulf-kit' ), 'text', __( 'Where "Book a free consultation" buttons go. Leave it as #visit: buttons then jump to the visit form on the same page, or open the Free Consultation page\'s form when the page has none. Or paste any full link.', 'wulf-kit' ) );
					?>
				</table>

				<h2><?php esc_html_e( 'Booking & conversions', 'wulf-kit' ); ?></h2>
				<p><?php esc_html_e( 'Every "Book" button on the site can open one short booking panel: what it\'s about, a day and time, then name and phone. Requests arrive by email (and in your CRM when that is on), with the piece the visitor was looking at.', 'wulf-kit' ); ?></p>
				<?php if ( class_exists( 'OM_Booking' ) ) : ?>
					<p>
						<?php
						$cal = WK_Plugin::booking_calendar();
						echo esc_html( $cal ? ( 'both' === $cal['mode'] ? __( 'Your SimplyBook calendar is on: the panel and the visit form show it beside this booking form, as two tabs.', 'wulf-kit' ) : __( 'Your SimplyBook calendar is on: the panel and the visit form show it instead of this booking form.', 'wulf-kit' ) ) : __( 'To show your SimplyBook booking calendar instead of this form, or beside it as two tabs, choose it in the OM Catalog settings.', 'wulf-kit' ) );
						?>
						<a href="<?php echo esc_url( admin_url( 'options-general.php?page=om-catalog-settings#inquiries' ) ); ?>"><?php esc_html_e( 'Settings › OM Catalog › Inquiries', 'wulf-kit' ); ?></a>
					</p>
				<?php endif; ?>
				<table class="form-table" role="presentation">
					<?php
					self::field( 'book_panel', __( 'Booking panel', 'wulf-kit' ), 'check', __( '"Book" buttons open the booking panel on the same page (recommended). Untick to jump to the visit form instead.', 'wulf-kit' ) );
					self::field( 'book_style', __( 'How it opens', 'wulf-kit' ), 'select', __( 'The popup sits in the middle of the screen with a showroom picture beside the form on wide screens. The side panel slides in from the right.', 'wulf-kit' ), array( 'popup' => __( 'Popup in the middle of the screen (recommended)', 'wulf-kit' ), 'drawer' => __( 'Panel that slides in from the side', 'wulf-kit' ) ) );
					self::field( 'book_img', __( 'Popup picture', 'wulf-kit' ), 'url', __( 'Link to a picture shown beside the form in the popup (copy it from the Media Library). Leave empty for the showroom photo.', 'wulf-kit' ) );
					self::field( 'book_points', __( 'Popup reassurance points', 'wulf-kit' ), 'textarea', __( 'One per line, shown on the picture with a check mark. Keep them short and true.', 'wulf-kit' ) );
					self::field( 'book_title', __( 'Panel title', 'wulf-kit' ) );
					self::field( 'book_sub', __( 'Under the title', 'wulf-kit' ) );
					self::field( 'book_topics', __( 'Topics', 'wulf-kit' ), 'textarea', __( 'One per line. After a | you can add what to bring, shown on the thank-you screen. For example: <code>Repair | The piece that needs work</code>', 'wulf-kit' ) );
					self::field( 'book_done', __( 'Thank-you message', 'wulf-kit' ), 'text', __( '{name}, {day}, {time} and {pref} are filled in.', 'wulf-kit' ) );
					self::field( 'track', __( 'Measure clicks and bookings', 'wulf-kit' ), 'check', __( 'Send button clicks, booking steps and booking requests to the Google Analytics, Google Tag Manager or Meta pixel already on your site. Nothing is sent when none is installed. Add <code>?wk_debug_events=1</code> to any page address to see them in the browser console.', 'wulf-kit' ) );
					?>
				</table>

				<h2 id="wk-google-reviews"><?php esc_html_e( 'Google reviews', 'wulf-kit' ); ?></h2>
				<p><?php esc_html_e( 'Optional. Two ways to show your live Google reviews: a reviews plugin you already use, whose widget then appears in every Reviews section (paste its shortcode below), or the kit\'s own review cards filled from your Google Business Profile (set the Reviews widget\'s "Reviews come from" to "Google, live"). The live rating in the hero and "Why Wulf" comes from Featurable or the Google key; the easiest way is free: Featurable reads the reviews from your Business Profile.', 'wulf-kit' ); ?></p>
				<?php
				$wk_code = (string) self::get( 'reviews_shortcode' );
				if ( '' !== $wk_code ) {
					if ( WK_Reviews::shortcode_ready( $wk_code ) ) {
						/* translators: %s: a shortcode, e.g. [trustindex no-registration=google] */
						$wk_msg = sprintf( __( 'Every Reviews section on the site shows %s under its title, in place of the kit\'s review cards. If that plugin shows nothing yet (not connected to your Google profile), a section shows the kit\'s own reviews instead.', 'wulf-kit' ), $wk_code );
					} else {
						/* translators: %s: a shortcode's name, e.g. [trustindex] */
						$wk_msg = sprintf( __( 'The plugin behind [%s] isn\'t active, so the Reviews sections show the kit\'s own reviews for now.', 'wulf-kit' ), WK_Reviews::shortcode_tag( $wk_code ) );
					}
					echo '<div class="notice notice-' . ( WK_Reviews::shortcode_ready( $wk_code ) ? 'success' : 'warning' ) . ' inline"><p>' . esc_html( $wk_msg ) . '</p></div>';
				}
				$wk_status = WK_Reviews::status();
				if ( $wk_status ) {
					echo '<div class="notice notice-' . ( 'ok' === $wk_status['state'] ? 'success' : 'warning' ) . ' inline"><p>' . esc_html( $wk_status['text'] ) . '</p></div>';
				}
				?>
				<table class="form-table" role="presentation">
					<?php
					self::field( 'reviews_shortcode', __( 'Reviews plugin shortcode', 'wulf-kit' ), 'text', __( 'Paste a reviews plugin\'s shortcode, like <code>[trustindex no-registration=google]</code> from Widgets for Google Reviews by Trustindex. Every Wulf Reviews section on the site then shows that plugin\'s reviews under its title and "Read all reviews on Google" link, in place of the kit\'s rating and review cards. Choose the layout and colors in the plugin\'s own settings (a light style suits the Reviews sections, which are light). Empty keeps the kit\'s own reviews.', 'wulf-kit' ) );
					self::field( 'featurable_id', __( 'Featurable widget ID (free)', 'wulf-kit' ), 'text', __( 'No Google key or card needed. 1. Sign up free at <a href="https://featurable.com" target="_blank" rel="noopener">featurable.com</a> with the Google account that manages your Business Profile. 2. Create a Google reviews widget for the shop. 3. Click Embed, then API, and copy the widget ID here (pasting the whole embed code works too). Featurable checks Google for new reviews about every two days.', 'wulf-kit' ) );
					self::field( 'google_key', __( 'Or: Google Places API key', 'wulf-kit' ), 'password', __( 'Only if you don\'t use Featurable (Featurable is used when both are filled in). Needs a Google Cloud billing account; Google shares up to 5 reviews and picks them.', 'wulf-kit' ) );
					self::field( 'google_place', __( 'Google Place ID', 'wulf-kit' ), 'text', __( 'With the API key: find it with Google\'s Place ID Finder.', 'wulf-kit' ) );
					self::field( 'reviews_hours', __( 'Refresh every (hours)', 'wulf-kit' ), 'number', __( 'How often the site asks for new reviews. Visitors always get a saved copy, so this doesn\'t slow pages down. Saving these settings asks again straight away.', 'wulf-kit' ) );
					?>
				</table>

				<h2 id="wk-films"><?php esc_html_e( 'Brand films', 'wulf-kit' ); ?></h2>
				<p class="description" style="max-width: 820px;"><?php esc_html_e( 'The short silent parts of your two films come with the kit and play in the "Brand film" and "Film chapters" sections. The full films with sound play when a visitor clicks "Watch the film": upload them once in Media › Add New, then choose them here. Until a film is chosen, its "Watch the film" buttons stay hidden.', 'wulf-kit' ); ?></p>
				<table class="form-table" role="presentation">
					<?php
					self::field( 'film_motion', __( 'Wulf Diamond Jewelers (1:15)', 'wulf-kit' ), 'video', __( 'The brand film: shapes, ring styles, fine jewelry, the ring builder and custom design. An MP4 file.', 'wulf-kit' ) );
					self::field( 'film_suitcase', __( 'The Suitcase (0:39)', 'wulf-kit' ), 'video', __( 'Your story since 1971. An MP4 file.', 'wulf-kit' ) );
					?>
				</table>

				<h2><?php esc_html_e( 'OM catalog media', 'wulf-kit' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php self::field( 'om_media', __( 'OM media address', 'wulf-kit' ), 'url', __( 'Product widgets set to "OM style number" load photos and 360° videos from here.', 'wulf-kit' ) ); ?>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<style>.wk-admin .wk-schema-preview { max-width: 760px; max-height: 360px; overflow: auto; margin: 8px 0 0; padding: 12px 14px; border: 1px solid #dcdcde; background: #fff; font-size: 12px; line-height: 1.5; white-space: pre-wrap; }</style>
		<script>
		jQuery( function ( $ ) {
			$( '.wk-color' ).wpColorPicker();
			// Brand films: pick (or upload) a video in the Media Library and keep its address.
			$( '.wk-media-pick' ).on( 'click', function ( e ) {
				e.preventDefault();
				var btn = $( this ), input = $( '#' + btn.data( 'for' ) );
				if ( ! window.wp || ! wp.media ) { input.trigger( 'focus' ); return; }
				var frame = wp.media( { title: btn.data( 'title' ), library: { type: 'video' }, button: { text: <?php echo wp_json_encode( __( 'Use this video', 'wulf-kit' ) ); ?> }, multiple: false } );
				frame.on( 'select', function () {
					var file = frame.state().get( 'selection' ).first().toJSON();
					input.val( file.url ).trigger( 'change' );
				} );
				frame.open();
			} );
			$( '.wk-media-clear' ).on( 'click', function () { $( '#' + $( this ).data( 'for' ) ).val( '' ).trigger( 'change' ); } );
			$( '.wk-media-row input' ).on( 'change input', function () { $( this ).siblings( '.wk-media-clear' ).prop( 'hidden', ! this.value ); } );
		} );
		</script>
		<?php
	}
}
